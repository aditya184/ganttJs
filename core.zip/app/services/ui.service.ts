import { Injectable } from '@angular/core';
import { HelpersService } from './helpers.service';
import { EventableService } from './eventable.service';
import { ConstantService } from './constant.service';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class UiService {
  eventHandlers = {
    "click": {},
    "doubleclick": {},
    "contextMenu": {}
  };
  constructor(private helperService: HelpersService, private eventableService: EventableService,
    private constantService: ConstantService, private commonService: CommonService) { }

  uiApi: any = function () {

    // tslint:disable-next-line: one-variable-per-declaration
    var uiFactory = this.uiFactoryJs,
      mouseEvents = this.mouseEventsJs,
      createLayers = this.createLayerJs,
      Cell = this.cellJs,
      Layout = this.layoutJs,
      ViewLayout = this.viewLayoutJs,
      ViewCell = this.viewCellJs,
      Resizer = this.resizerJs,
      Scrollbar = this.scrollbarJs,
      Timeline = this.timelineJs,
      Grid = this.gridJs,
      ResourceGrid = this.gridJs,
      ResourceTimeline = this.timelineJs,
      ResourceHistogram = this.timelineJs;


    var gridEditorsFactory = this.gridEditorFactoryJs;


    var renderTaskBar = this.renderTaskBarJs,
      renderSplitTaskBar = this.renderSplitTaskBarJS,
      renderTaskBg = this.renderTaskBgJs,
      renderLink = this.renderLinkJs,
      gridRenderer = this.gridRendererJs;

    var mainGridInitializer = this.mainGridInitializerJs;
    var mainTimelineInitializer = this.mainTimelineInitializerJs;
    var mainLayoutInitializer = this.mainLayoutInitializerJs;

    function initUI(gantt) {
      function attachInitializer(view, initializer) {
        var ext = initializer(gantt);
        if (ext.onCreated)
          ext.onCreated(view);
        view.attachEvent("onReady", function () {
          if (ext.onInitialized)
            ext.onInitialized(view);
        });
        view.attachEvent("onDestroy", function () {
          if (ext.onDestroyed)
            ext.onDestroyed(view);
        });
      }

      var factory = uiFactory.createFactory(gantt);
      factory.registerView("cell", Cell);
      factory.registerView("resizer", Resizer);
      factory.registerView("scrollbar", Scrollbar);
      factory.registerView("layout", Layout, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "main") {
          attachInitializer(view, mainLayoutInitializer);
        }
      });
      factory.registerView("viewcell", ViewCell);
      factory.registerView("multiview", ViewLayout);
      factory.registerView("timeline", Timeline, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "timeline" || view.$config.bind == "task") {
          attachInitializer(view, mainTimelineInitializer);
        }
      });
      factory.registerView("grid", Grid, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "grid" || view.$config.bind == "task") {
          attachInitializer(view, mainGridInitializer);
        }
      });

      factory.registerView("resourceGrid", ResourceGrid);
      factory.registerView("resourceTimeline", ResourceTimeline);
      factory.registerView("resourceHistogram", ResourceHistogram);

      var layersEngine = createLayers(gantt);

      var inlineEditors = gridEditorsFactory(gantt);

      gantt.ext.inlineEditors = inlineEditors;
      gantt.ext._inlineEditors = inlineEditors;
      inlineEditors.init(gantt);

      return {
        factory,
        mouseEvents: mouseEvents.init(gantt),
        layersApi: layersEngine.init(),
        render: {
          gridLine() {
            return gridRenderer(gantt);
          },
          taskBg() {
            return renderTaskBg(gantt);
          },
          taskBar() {
            return renderTaskBar(gantt);
          },
          taskSplitBar() {
            return renderSplitTaskBar(gantt);
          },
          link() {
            return renderLink(gantt);
          }
        },
        layersService: {
          getDataRender(name) {
            return layersEngine.getDataRender(name, gantt);
          },
          createDataRender(config) {
            return layersEngine.createDataRender(config, gantt);
          }
        }
      };
    }

    return {
      init: initUI
    };

    /***/
  }

  configurableJs = function () {

    var utils = this.helperService.utils;

    function ViewSettings(config) {
      utils.mixin(this, config, true);
    }


    function extendSettings(store, parentSettings) {
      var own = this.$config[store];

      if (own) {
        if (own instanceof ViewSettings) {
          return own;
        } else {
          ViewSettings.prototype = parentSettings;
          this.$config[store] = new ViewSettings(own);
          return this.$config[store];
        }
      } else {
        return parentSettings;
      }
    }

    var configurable = function (parentView) {
      var parentConfig,
        parentTemplates;

      return {
        $getConfig() {
          if (!parentConfig) {
            parentConfig = parentView ? parentView.$getConfig() : this.$gantt.config;
          }
          if (!this.$config.config) {
            return parentConfig;
          } else {
            return extendSettings.call(this, "config", parentConfig);
          }
        },
        $getTemplates() {
          if (!parentTemplates) {
            parentTemplates = parentView ? parentView.$getTemplates() : this.$gantt.templates;
          }
          if (!this.$config.templates) {
            return parentTemplates;
          } else {
            return extendSettings.call(this, "templates", parentTemplates);
          }
        }
      };
    };

    return function (obj, parent) {
      utils.mixin(obj, configurable(parent));
    };

    /***/
  };

  uiFactoryJs = function () {

    var utils = this.helperService.utils,
      configurable = this.configurableJs;

    var uiFactory = function createFactory(gantt) {
      var views = {};

      function ui(cell, parentView) {
        var content;
        var view = "cell";
        if (cell.view) {
          view = "viewcell";
        } else if (cell.resizer) {
          view = "resizer";
        }
        else if (cell.rows || cell.cols) {
          view = "layout";
        }
        else if (cell.views) {
          view = "multiview";
        }

        content = createView.call(this, view, null, cell, parentView);
        return content;
      }

      var createdViews = {};

      function createView(name, parent, config, parentView) {
        var creator = views[name];

        if (!creator || !creator.create)
          return false;

        if (name == "resizer" && !config.mode) {
          if (parentView.$config.cols) {
            config.mode = "x";
          } else {
            config.mode = "y";
          }
        }

        if (name == "viewcell" && config.view == "scrollbar" && !config.scroll) {
          if (parentView.$config.cols) {
            config.scroll = "y";
          } else {
            config.scroll = "x";
          }
        }

        var config = utils.copy(config);

        if (!config.id && !createdViews[config.view]) {
          config.id = config.view;
        }

        if (config.id && !config.css) {
          config.css = config.id + "_cell";
        }

        var view = new creator.create(parent, config, this, gantt);

        if (creator.configure) {
          creator.configure(view);
        }

        configurable(view, parentView);
        if (!view.$id) {
          view.$id = config.id || gantt.uid();
        }

        if (!view.$parent && typeof parent == "object") {
          view.$parent = parent;
        }
        if (!view.$config) {
          view.$config = config;
        }

        if (createdViews[view.$id]) {
          view.$id = gantt.uid();
        }

        createdViews[view.$id] = view;

        return view;
      }

      function reset() {
        createdViews = {};
      }

      function register(name, viewConstructor, configure) {
        views[name] = { create: viewConstructor, configure };
      }

      function getView(id) {
        return createdViews[id];
      }

      var factory = {
        initUI: ui,
        reset,
        registerView: register,
        createView,
        getView
      };

      return factory;
    };

    return {
      createFactory: uiFactory
    };

  }

  addEventTarget(event, className, handler, root) {
    if (!this.eventHandlers[event][className]) {
      this.eventHandlers[event][className] = [];
    }

    this.eventHandlers[event][className].push({
      handler,
      root
    });
  }

  callHandler(eventName, className, root, args) {
    var handlers = this.eventHandlers[eventName][className];
    if (handlers) {
      for (var i = 0; i < handlers.length; i++) {
        if (!(root || handlers[i].root) || handlers[i].root === root) {
          handlers[i].handler.apply(this, args);
        }
      }
    }
  }

  onClick(e) {
    e = e || window.event;
    var id = gantt.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.click);
    var res = true;
    if (id !== null) {
      res = !gantt.checkEvent("onTaskClick") || gantt.callEvent("onTaskClick", [id, e]);
    } else {
      gantt.callEvent("onEmptyClick", [e]);
    }

    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id && gantt.getTask(id) && gantt.config.select_task && !gantt.config.multiselect) {
        gantt.selectTask(id);
      }
    }
  }

  onContextMenu(e) {
    e = e || window.event;
    var src = e.target || e.srcElement,
      taskId = gantt.locate(src),
      // linkId = gantt.locate(src, this.commonService.result.link_attribute);
      linkId = gantt.locate(src);

    var res = !gantt.checkEvent("onContextMenu") || gantt.callEvent("onContextMenu", [taskId, linkId, e]);
    if (!res) {
      if (e.preventDefault)
        e.preventDefault();
      else
        e.returnValue = false;
    }
    return res;
  }

  findEventHandlers(e, hash) {
    var trg = e.target || e.srcElement;
    var handlers = [];
    while (trg) {
      var css = this.helperService.getClassName(trg);
      if (css) {
        css = css.split(" ");
        for (var i = 0; i < css.length; i++) {
          if (!css[i]) continue;
          if (hash[css[i]]) {
            var delegateHandlers = hash[css[i]];

            for (var h = 0; h < delegateHandlers.length; h++) {
              if (delegateHandlers[h].root) {
                if (!this.helperService.isChildOf(trg, delegateHandlers[h].root)) {
                  continue;
                }
              }
              handlers.push(delegateHandlers[h].handler);
            }
          }
        }
      }
      trg = trg.parentNode;
    }
    return handlers;
  }

  callEventHandlers(handlers, e, id) {
    var res = true;

    for (var i = 0; i < handlers.length; i++) {
      var handlerResult = handlers[i].call(gantt, e, id, e.target || e.srcElement);
      res = res && !(typeof handlerResult != "undefined" && handlerResult !== true);
    }

    return res;
  }


  onDoubleClick(e) {
    e = e || window.event;
    var id = gantt.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.doubleclick);
    // when doubleclick fired not on task, id === null
    var res = !gantt.checkEvent("onTaskDblClick") || id === null || gantt.callEvent("onTaskDblClick", [id, e]);
    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id !== null && gantt.getTask(id)) {
        if (res && gantt.config.details_on_dblclick) {
          gantt.showLightbox(id);
        }
      }
    }
  }

  onMouseMove(e) {
    if (gantt.checkEvent("onMouseMove")) {
      var id = gantt.locate(e);
      gantt._last_move_event = e;
      gantt.callEvent("onMouseMove", [id, e]);
    }
  }

  detach(eventName, className, handler, root) {
    if (this.eventHandlers[eventName] && this.eventHandlers[eventName][className]) {
      var handlers = this.eventHandlers[eventName];
      var elementHandlers = handlers[className];
      for (var i = 0; i < elementHandlers.length; i++) {
        if (elementHandlers[i].root == root) {
          elementHandlers.splice(i, 1);
          i--;
        }
      }
      if (!elementHandlers.length) {
        delete handlers[className];
      }

    }
  }

  domEvents = this.helperService;

  reset(node?) {

    this.domEvents.detachAll();

    if (node) {
      this.domEvents.attach(node, "click", this.onClick, undefined);
      this.domEvents.attach(node, "dblclick", this.onDoubleClick, undefined);
      this.domEvents.attach(node, "mousemove", this.onMouseMove, undefined);
      this.domEvents.attach(node, "contextmenu", this.onContextMenu, undefined);
    }
  }

  task_area_pulls = {};
  task_area_renderers = {};

  getRenderer(id, layer?, node?) {

    if (this.task_area_renderers[id])
      return this.task_area_renderers[id];

    if (!layer.renderer)
      gantt.assert(false, "Invalid renderer call");

    var renderMethod = null;
    var updateMethod = null;

    if (typeof layer.renderer === "function") {
      renderMethod = layer.renderer;
    } else {
      renderMethod = layer.renderer.render;
      updateMethod = layer.renderer.update;
    }

    var renderOne = function (item, viewPort) {
      var rendererViewPort = viewPort;
      if (!rendererViewPort && layer.getViewPort) {
        rendererViewPort = layer.getViewPort();
      }
      return renderMethod.call(this, item, layer.host, rendererViewPort || null);
    };

    var filter = layer.filter;

    if (node)
      node.setAttribute(this.commonService.configOptions().layer_attribute, true);

    this.task_area_renderers[id] = {
      render_item(item, container, viewPort) {
        container = container || node;

        if (filter) {
          if (!filter(item)) {
            this.remove_item(item.id);
            return;
          }
        }

        var dom = renderOne.call(gantt, item, viewPort);
        this.append(item, dom, container);

      },

      clear(container) {

        this.rendered = this.task_area_pulls[id] = {};
        if (!layer.append)
          this.clear_container(container);
      },
      clear_container(container) {
        container = container || node;
        if (container)
          container.innerHTML = "";
      },
      render_items(items, container) {
        container = container || node;

        var buffer = document.createDocumentFragment();
        this.clear(container);
        var viewPort = null;
        if (layer.getViewPort) {
          viewPort = layer.getViewPort();
        }
        for (var i = 0, vis = items.length; i < vis; i++) {
          this.render_item(items[i], buffer, viewPort);
        }

        container.appendChild(buffer, container);
      },
      update_items(items, container) {
        container = container || node;
        if (!updateMethod) {
          return;
        }

        var buffer = document.createDocumentFragment();
        var viewPort = null;
        if (layer.getViewPort) {
          viewPort = layer.getViewPort();
        }

        for (var i = 0, vis = items.length; i < vis; i++) {
          var item = items[i];
          var itemNode = this.rendered[item.id];
          if (itemNode && itemNode.parentNode) {
            updateMethod.call(gantt, item, layer.host, this, viewPort);
          } else {
            this.render_item(items[i], buffer, viewPort);
          }


        }
        if (buffer.childNodes.length) {
          container.appendChild(buffer, container);
        }
      },
      append(item, node, container) {
        if (!node) {
          if (this.rendered[item.id]) {
            this.remove_item(item.id);
          }
          return;
        }

        if (this.rendered[item.id] && this.rendered[item.id].parentNode) {
          this.replace_item(item.id, node);
        } else {
          container.appendChild(node);
        }
        this.rendered[item.id] = node;

      },
      replace_item(item_id, newNode) {
        var item = this.rendered[item_id];
        if (item && item.parentNode) {
          item.parentNode.replaceChild(newNode, item);
        }
        this.rendered[item_id] = newNode;
      },
      remove_item(item_id) {
        this.hide(item_id);
        delete this.rendered[item_id];
      },
      hide(item_id) {
        var item = this.rendered[item_id];
        if (item && item.parentNode) {
          item.parentNode.removeChild(item);
        }
      },
      restore(item) {
        var dom = this.rendered[item.id];
        if (dom) {
          if (!dom.parentNode) {
            this.append(item, dom, node);
          }
        } else {
          this.render_item(item, node);
        }
      },
      change_id(oldid, newid) {
        this.rendered[newid] = this.rendered[oldid];
        delete this.rendered[oldid];
      },
      rendered: this.task_area_pulls[id],
      node,
      destructor() {
        this.clear();
        delete this.task_area_renderers[id];
        delete this.task_area_pulls[id];
      }
    };

    return this.task_area_renderers[id];
  }


  clearRenderers() {
    // tslint:disable-next-line: forin
    for (var i in this.task_area_renderers) {
      this.getRenderer(i).destructor();
    }
  }

  rendererFactory(gantt) {
    var services = gantt.$services;
  }

  isLegacyRender(gantt) {
    return gantt.config.smart_rendering && gantt._smart_render;
  }

  createLayerJs = function () {

    var renderFactoryProvider = this.renderFactoryProviderJs;
    var utils = this.helperService,
      domHelpers = this.helperService,
      isLegacyRender = this.isLegacyRenderJs;

    var layerFactory = function (gantt) {

      var renderFactory = renderFactoryProvider(gantt);
      return {
        createGroup(get_container, rel_root, defaultFilters) {

          var renderGroup = {
            tempCollection: [],
            renderers: {},
            container: get_container,
            filters: [],
            getLayers() {
              this._add();// add pending layers

              var res = [];
              for (var i in this.renderers) {
                res.push(this.renderers[i]);
              }
              return res;
            },
            getLayer(id) {
              return this.renderers[id];
            },
            _add(layer) {
              if (layer) {
                layer.id = layer.id || utils.uid();
                this.tempCollection.push(layer);
              }

              var container = this.container();

              var pending = this.tempCollection;
              for (var i = 0; i < pending.length; i++) {
                layer = pending[i];

                if (!this.container() && !(layer && layer.container && domHelpers.isChildOf(layer.container, document.body))) continue;

                var node = layer.container,
                  id = layer.id,
                  topmost = layer.topmost;
                if (!node.parentNode) {
                  //insert on top or below the tasks
                  if (topmost) {
                    container.appendChild(node);
                  } else {
                    var rel = rel_root ? rel_root() : container.firstChild;
                    if (rel)
                      container.insertBefore(node, rel);
                    else
                      container.appendChild(node);
                  }
                }
                this.renderers[id] = renderFactory.getRenderer(
                  id,
                  layer,
                  node
                );
                this.tempCollection.splice(i, 1);
                i--;
              }
            },
            addLayer(config) {
              //config = prepareConfig(config);
              if (config) {
                if (typeof config == "function") {
                  config = { renderer: config };
                }

                if (config.filter === undefined) {
                  config.filter = mergeFilters(defaultFilters || []);
                } else if (config.filter instanceof Array) {
                  config.filter.push(defaultFilters);
                  config.filter = mergeFilters(config.filter);
                }

                if (!config.container) {
                  config.container = document.createElement("div");
                }
                var self = this;
                config.requestUpdate = function () {
                  if (gantt.config.smart_rendering && !isLegacyRender(gantt)) {
                    if (self.renderers[config.id]) {
                      self.onUpdateRequest(self.renderers[config.id]);
                    }
                  }

                };
              }

              this._add(config);
              return (config ? config.id : undefined);
            },
            onUpdateRequest(layer) {

            },

            eachLayer(code) {
              for (var i in this.renderers) {
                code(this.renderers[i]);
              }
            },
            removeLayer(id) {
              if (!this.renderers[id])
                return;
              this.renderers[id].destructor();
              delete this.renderers[id];
            },
            clear() {
              for (var i in this.renderers) {
                this.renderers[i].destructor();
              }
              this.renderers = {};
            }//,
            //prepareConfig: prepareConfig
          };

          gantt.attachEvent("onDestroy", function () {
            renderGroup.clear();
            renderGroup = null;
          });

          return renderGroup;
        }
      };
    };


    function mergeFilters(filter_methods) {
      if (!(filter_methods instanceof Array)) {
        filter_methods = Array.prototype.slice.call(arguments, 0);
      }

      return function (obj) {
        var res = true;
        for (var i = 0, len = filter_methods.length; i < len; i++) {
          var filter_method = filter_methods[i];
          if (filter_method) {
            res = res && (filter_method(obj.id, obj) !== false);
          }
        }

        return res;
      };
    }


    return layerFactory;


    /***/
  }

  createLayers = function () {

    var createLayerFactory = this.createLayerFactoryJs;

    var createLayerEngine = function (gantt) {
      var factory = createLayerFactory(gantt);
      return {
        getDataRender(name) {
          return gantt.$services.getService("layer:" + name) || null;
        },
        createDataRender(config) {
          var name = config.name,
            defaultContainer = config.defaultContainer,
            previusSiblingContainer = config.defaultContainerSibling;

          var layers = factory.createGroup(
            defaultContainer,
            previusSiblingContainer,
            function (itemId, item) {
              if (layers.filters) {
                for (var i = 0; i < layers.filters.length; i++) {
                  if (layers.filters[i](itemId, item) === false) {
                    return false;
                  }
                }
              } else {
                return true;
              }
            }
          );

          gantt.$services.setService("layer:" + name, function () {
            return layers;
          });

          gantt.attachEvent("onGanttReady", function () {
            layers.addLayer();// init layers on start
          });

          return layers;
        },
        init() {
          var taskLayers = this.createDataRender({
            name: "task",
            defaultContainer() {
              if (gantt.$task_data) {
                return gantt.$task_data;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_data;
              }
            },
            defaultContainerSibling() {
              if (gantt.$task_links) {
                return gantt.$task_links;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_links;
              }
            },
            filter(item) {

            }
          }, gantt);

          var linkLayers = this.createDataRender({
            name: "link",
            defaultContainer() {
              if (gantt.$task_data) {
                return gantt.$task_data;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_data;
              }
            }
          }, gantt);

          return {
            addTaskLayer(config) {
              return taskLayers.addLayer(config);
            },

            /*getTaskLayer: function(id){
              return taskLayers.getLayer(id);
            },*/

            _getTaskLayers() {
              return taskLayers.getLayers();
            },
            removeTaskLayer(id) {
              taskLayers.removeLayer(id);
            },
            /*eachTaskLayer: function(code){
              taskLayers.eachLayer(code);
            },*/
            _clearTaskLayers() {
              taskLayers.clear();
            },
            addLinkLayer(config) {
              return linkLayers.addLayer(config);
            },
            /*getLinkLayer: function(id){
              return linkLayers.getLayer(id);
            },*/
            _getLinkLayers() {
              return linkLayers.getLayers();
            },
            removeLinkLayer(id) {
              linkLayers.removeLayer(id);
            },
            /*eachLinkLayer: function(code){
              linkLayers.eachLayer(code);
            },*/
            _clearLinkLayers() {
              linkLayers.clear();
            }
          };
        }
      };
    };

    return createLayerEngine;

    /***/
  }

  cellJs = function () {

    var utils = this.helperService.utils,
      eventable = this.eventableService,
      domHelpers = this.helperService;

    var Cell = (function () {
      "use strict";

      function Cell(parent, config, factory, gantt) {
        if (parent) {
          this.$container = domHelpers.toNode(parent);
          this.$parent = parent;
        }
        // save config
        this.$config = utils.mixin(config, {
          headerHeight: 33
        });
        this.$gantt = gantt;
        this.$domEvents = gantt._createDomEventScope();
        // set id
        this.$id = config.id || "c" + utils.uid();

        this.$name = "cell";
        this.$factory = factory;

        eventable(this);

      }

      Cell.prototype.destructor = function () {
        this.$parent = this.$container = this.$view = null;
        var mouse = this.$gantt.$services.getService("mouseEvents");
        mouse.detach("click", "gantt_header_arrow", this._headerClickHandler);
        this.$domEvents.detachAll();
        this.callEvent("onDestroy", []);
        this.detachAllEvents();
      };
      Cell.prototype.cell = function (id) {
        return null;
      };

      Cell.prototype.scrollTo = function (left, top) {

        if (left * 1 == left) {
          this.$view.scrollLeft = left;
        }
        if (top * 1 == top) {
          this.$view.scrollTop = top;
        }
      };

      Cell.prototype.clear = function () {
        this.getNode().innerHTML = "";
        this.getNode().className = "gantt_layout_content";
        this.getNode().style.padding = "0";
      };

      Cell.prototype.resize = function (final) {
        if (this.$parent) {
          return this.$parent.resize(final);
        }

        if (final === false) {
          this.$preResize = true;
        }

        var topCont = this.$container;
        var x = topCont.offsetWidth;
        var y = topCont.offsetHeight;
        var topSize = this.getSize();
        if (topCont === document.body) {
          x = document.body.offsetWidth;
          y = document.body.offsetHeight;
        }
        if (x < topSize.minWidth) {
          x = topSize.minWidth;
        }
        if (x > topSize.maxWidth) {
          x = topSize.maxWidth;
        }
        if (y < topSize.minHeight) {
          y = topSize.minHeight;
        }
        if (y > topSize.maxHeight) {
          y = topSize.maxHeight;
        }
        this.setSize(x, y);

        if (!this.$preResize) {
          //	self.callEvent("onResize", [x, y]);
        }
        this.$preResize = false;
      };

      Cell.prototype.hide = function () {
        this._hide(true);
        this.resize();
      };
      Cell.prototype.show = function (force) {
        this._hide(false);
        if (force && this.$parent) {
          this.$parent.show();
        }
        this.resize();
      };
      Cell.prototype._hide = function (mode) {
        if (mode === true && this.$view.parentNode) {
          this.$view.parentNode.removeChild(this.$view);
        }
        else if (mode === false && !this.$view.parentNode) {
          var index = this.$parent.cellIndex(this.$id);
          this.$parent.moveView(this, index);
        }
        this.$config.hidden = mode;
      };
      Cell.prototype.$toHTML = function (content, css) {
        if (content === void 0) { content = ""; }
        css = [(css || ""), (this.$config.css || "")].join(" ");
        var obj = this.$config;
        var header = "";
        if (obj.raw) {
          content = typeof obj.raw === "string" ? obj.raw : "";
        }
        else {
          if (!content) {
            content = "<div class='gantt_layout_content' " + (css ? " class='" + css + "' " : "") + " >" + (obj.html || "") + "</div>";
          }
          if (obj.header) {
            var collapseIcon = obj.canCollapse ? "<div class='gantt_layout_header_arrow'></div>" : "";
            header = "<div class='gantt_layout_header'>" + collapseIcon + "<div class='gantt_layout_header_content'>" + obj.header + "</div></div>";
          }
        }
        return "<div class='gantt_layout_cell " + css + "' data-cell-id='" + this.$id + "'>" + header + content + "</div>";
      };
      Cell.prototype.$fill = function (node, parent) {
        this.$view = node;
        this.$parent = parent;
        this.init();
      };
      Cell.prototype.getNode = function () {
        return (this.$view.querySelector("gantt_layout_cell") || this.$view);
      };
      Cell.prototype.init = function () {
        // [NOT-GOOD] code is executed for each component, while it still has only one handler, it is no good

        var self = this;

        this._headerClickHandler = function (e) {
          var cellId = domHelpers.locateAttribute(e, "data-cell-id");
          if (cellId == self.$id) {
            self.toggle();
          }
        };

        var mouse = this.$gantt.$services.getService("mouseEvents");
        mouse.delegate("click", "gantt_header_arrow", this._headerClickHandler);

        this.callEvent("onReady", []);
      };
      Cell.prototype.toggle = function () {
        this.$config.collapsed = !this.$config.collapsed;
        this.resize();
      };
      Cell.prototype.getSize = function () {
        var size = {
          height: this.$config.height || 0,
          width: this.$config.width || 0,
          gravity: this.$config.gravity || 1,
          minHeight: this.$config.minHeight || 0,
          minWidth: this.$config.minWidth || 0,
          maxHeight: this.$config.maxHeight || 100000,
          maxWidth: this.$config.maxWidth || 100000
        };
        if (this.$config.collapsed) {
          var mode = this.$config.mode === "x";
          size[mode ? "width" : "height"] = size[mode ? "maxWidth" : "maxHeight"] = this.$config.headerHeight;
        }
        return size;
      };

      Cell.prototype.getContentSize = function () {

        var width = this.$lastSize.contentX;
        if (width !== width * 1) {
          width = this.$lastSize.width;
        }

        var height = this.$lastSize.contentY;
        if (height !== height * 1) {
          height = this.$lastSize.height;
        }

        return {
          width: width,
          height: height
        };
      };

      Cell.prototype._getBorderSizes = function () {
        var borders = {
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          horizontal: 0,
          vertical: 0
        };
        if (this._currentBorders) {
          if (this._currentBorders[this._borders.left]) {
            borders.left = 1;
            borders.horizontal++;
          }

          if (this._currentBorders[this._borders.right]) {
            borders.right = 1;
            borders.horizontal++;
          }

          if (this._currentBorders[this._borders.top]) {
            borders.top = 1;
            borders.vertical++;
          }

          if (this._currentBorders[this._borders.bottom]) {
            borders.bottom = 1;
            borders.vertical++;
          }
        }

        return borders;

      };

      Cell.prototype.setSize = function (x, y) {
        this.$view.style.width = x + "px";
        this.$view.style.height = y + "px";

        var borders = this._getBorderSizes();
        var contentY = y - borders.vertical;
        var contentX = x - borders.horizontal;

        this.$lastSize = { x: x, y: y, contentX: contentX, contentY: contentY };
        if (this.$config.header) {
          this._sizeHeader();
        } else {
          this._sizeContent();
        }
      };

      Cell.prototype._borders = {
        "left": "gantt_layout_cell_border_left",
        "right": "gantt_layout_cell_border_right",
        "top": "gantt_layout_cell_border_top",
        "bottom": "gantt_layout_cell_border_bottom"
      };

      Cell.prototype._setBorders = function (css, view) {
        if (!view) {
          view = this;
        }
        var node = view.$view;

        for (var i in this._borders) {
          domHelpers.removeClassName(node, this._borders[i]);
        }

        if (typeof css == "string") {
          css = [css];
        }

        var cssHash = {};

        for (let i = 0; i < css.length; i++) {
          domHelpers.addClassName(node, css[i]);
          cssHash[css[i]] = true;
        }

        view._currentBorders = cssHash;
      };


      Cell.prototype._sizeContent = function () {
        var content = this.$view.childNodes[0];
        if (content && content.className == "gantt_layout_content") {
          content.style.height = this.$lastSize.contentY + "px";
        }
      };

      Cell.prototype._sizeHeader = function () {
        var size = this.$lastSize;
        size.contentY -= this.$config.headerHeight;
        var header = this.$view.childNodes[0];
        var content = this.$view.childNodes[1];
        var xLayout = this.$config.mode === "x";
        if (this.$config.collapsed) {
          content.style.display = "none";
          if (xLayout) {
            header.className = "gantt_layout_header collapsed_x";
            header.style.width = size.y + "px";
            var d = Math.floor(size.y / 2 - size.x / 2);
            header.style.transform = "rotate(90deg) translate(" + d + "px, " + d + "px)";
            content.style.display = "none";
          }
          else {
            header.className = "gantt_layout_header collapsed_y";
          }
        }
        else {
          if (xLayout) {
            header.className = "gantt_layout_header";
          }
          else {
            header.className = "gantt_layout_header vertical";
          }
          header.style.width = 'auto';
          header.style.transform = '';
          content.style.display = "";
          content.style.height = size.contentY + "px";
        }
        header.style.height = this.$config.headerHeight + "px";
      };
      return Cell;
    }());

    return Cell;


  }

  layoutJs = function () {

    var __extends = this.helperService.extends,
      domHelpers = this.helperService,
      Cell = this.cellJs;

    var Layout = (function (_super) {
      "use strict";

      __extends(Layout, _super);
      function Layout(parent, config, factory) {
        var _this = _super.apply(this, arguments) || this;

        if (parent)
          _this.$root = true;

        _this._parseConfig(config);
        _this.$name = "layout";
        return _this;
      }

      Layout.prototype.destructor = function () {
        if (this.$container && this.$view) {
          domHelpers.removeNode(this.$view);
        }

        for (var i = 0; i < this.$cells.length; i++) {
          var child = this.$cells[i];
          child.destructor();
        }
        this.$cells = [];

        _super.prototype.destructor.call(this);
      };

      Layout.prototype._resizeScrollbars = function (autosize, scrollbars) {
        var scrollChanged = false;
        var visibleScrollbars = [],
          hiddenSrollbars = [];

        function showScrollbar(scrollbar) {
          scrollbar.$parent.show();
          scrollChanged = true;
          visibleScrollbars.push(scrollbar);
        }
        function hideScrollbar(scrollbar) {
          scrollbar.$parent.hide();
          scrollChanged = true;
          hiddenSrollbars.push(scrollbar);
        }

        var scrollbar;
        for (var i = 0; i < scrollbars.length; i++) {
          scrollbar = scrollbars[i];

          if (autosize[scrollbar.$config.scroll]) {
            hideScrollbar(scrollbar);
          } else if (scrollbar.shouldHide()) {
            hideScrollbar(scrollbar);
          } else if (scrollbar.shouldShow()) {
            showScrollbar(scrollbar);
          } else {
            if (scrollbar.isVisible()) {
              visibleScrollbars.push(scrollbar);
            } else {
              hiddenSrollbars.push(scrollbar);
            }
          }
        }

        var visibleGroups = {};
        for (var i = 0; i < visibleScrollbars.length; i++) {
          if (visibleScrollbars[i].$config.group) {
            visibleGroups[visibleScrollbars[i].$config.group] = true;
          }
        }

        for (var i = 0; i < hiddenSrollbars.length; i++) {
          scrollbar = hiddenSrollbars[i];

          if (scrollbar.$config.group && visibleGroups[scrollbar.$config.group]) {
            showScrollbar(scrollbar);
          }
        }

        return scrollChanged;
      };

      Layout.prototype._syncCellSizes = function (groupName, newSize) {
        if (!groupName)
          return;

        var groups = {};

        this._eachChild(function (cell) {
          if (cell.$config.group && cell.$name != "scrollbar" && cell.$name != "resizer") {
            if (!groups[cell.$config.group]) {
              groups[cell.$config.group] = [];
            }
            groups[cell.$config.group].push(cell);
          }
        });

        if (groups[groupName]) {
          this._syncGroupSize(groups[groupName], newSize);
        }
        return groups[groupName];
      };

      Layout.prototype._syncGroupSize = function (cells, newSize) {
        if (!cells.length) return;

        var property = cells[0].$parent._xLayout ? "width" : "height";
        var direction = cells[0].$parent.getNextSibling(cells[0].$id) ? 1 : -1;

        for (var i = 0; i < cells.length; i++) {
          var ownSize = cells[i].getSize();

          var resizeSibling = direction > 0 ? cells[i].$parent.getNextSibling(cells[i].$id) : cells[i].$parent.getPrevSibling(cells[i].$id);
          if (resizeSibling.$name == "resizer") {
            resizeSibling = direction > 0 ? resizeSibling.$parent.getNextSibling(resizeSibling.$id) : resizeSibling.$parent.getPrevSibling(resizeSibling.$id);
          }
          var siblingSize = resizeSibling.getSize();

          if (resizeSibling[property]) {
            var totalGravity = ownSize.gravity + siblingSize.gravity;
            var totalSize = ownSize[property] + siblingSize[property];
            var k = totalGravity / totalSize;
            cells[i].$config.gravity = k * newSize;

            resizeSibling.$config[property] = totalSize - newSize;
            resizeSibling.$config.gravity = totalGravity - k * newSize;
          } else {


            cells[i].$config[property] = newSize;
          }

          var mainGrid = this.$gantt.$ui.getView("grid");
          if (mainGrid && cells[i].$content === mainGrid && !mainGrid.$config.scrollable) {
            this.$gantt.config.grid_width = newSize;
          }
        }
      };

      Layout.prototype.resize = function (startStage) {
        var mainCall = false;
        if (this.$root && !this._resizeInProgress) {
          this.callEvent("onBeforeResize", []);
          mainCall = true;
          this._resizeInProgress = true;
        }

        _super.prototype.resize.call(this, true);
        _super.prototype.resize.call(this, false);

        if (mainCall) {

          var contentViews = [];
          contentViews = contentViews.concat(this.getCellsByType("viewCell"));
          contentViews = contentViews.concat(this.getCellsByType("viewLayout"));
          contentViews = contentViews.concat(this.getCellsByType("hostCell"));

          var scrollbars = this.getCellsByType("scroller");

          for (var i = 0; i < contentViews.length; i++) {
            if (!contentViews[i].$config.hidden)
              contentViews[i].setContentSize();
          }

          var autosize = this._getAutosizeMode(this.$config.autosize);

          var scrollChanged = this._resizeScrollbars(autosize, scrollbars);

          if (this.$config.autosize) {
            this.autosize(this.$config.autosize);
            scrollChanged = true;
          }

          if (scrollChanged) {
            this.resize();
            for (var i = 0; i < contentViews.length; i++) {
              if (!contentViews[i].$config.hidden)
                contentViews[i].setContentSize();
            }
          }

          this.callEvent("onResize", []);
        }
        if (mainCall) {
          this._resizeInProgress = false;
        }
      };

      Layout.prototype._eachChild = function (code, cell) {
        cell = cell || this;
        code(cell);
        if (cell.$cells) {
          for (var i = 0; i < cell.$cells.length; i++) {
            this._eachChild(code, cell.$cells[i]);
          }
        }
      };

      Layout.prototype.isChild = function (view) {
        var res = false;
        this._eachChild(function (child) {
          if (child === view || child.$content === view) {
            res = true;
          }
        });
        return res;
      };

      Layout.prototype.getCellsByType = function (type) {
        var res = [];
        if (type === this.$name) {
          res.push(this);
        }

        if (this.$content && this.$content.$name == type) {
          res.push(this.$content);
        }

        if (this.$cells) {
          for (var i = 0; i < this.$cells.length; i++) {
            var children = Layout.prototype.getCellsByType.call(this.$cells[i], type);
            if (children.length) {
              res.push.apply(res, children);
            }
          }
        }
        return res;
      };

      Layout.prototype.getNextSibling = function (cellId) {
        var index = this.cellIndex(cellId);
        if (index >= 0 && this.$cells[index + 1]) {
          return this.$cells[index + 1];
        } else {
          return null;
        }
      };

      Layout.prototype.getPrevSibling = function (cellId) {
        var index = this.cellIndex(cellId);
        if (index >= 0 && this.$cells[index - 1]) {
          return this.$cells[index - 1];
        } else {
          return null;
        }
      };


      Layout.prototype.cell = function (id) {
        for (var i = 0; i < this.$cells.length; i++) {
          var child = this.$cells[i];
          if (child.$id === id) {
            return child;
          }
          var sub = child.cell(id);
          if (sub) {
            return sub;
          }
        }
      };
      Layout.prototype.cellIndex = function (id) {
        for (var i = 0; i < this.$cells.length; i++) {
          if (this.$cells[i].$id === id) {
            return i;
          }
        }
        return -1;
      };
      Layout.prototype.moveView = function (view, ind) {
        if (this.$cells[ind] !== view) {
          return window.alert("Not implemented");
        }
        else {
          ind += this.$config.header ? 1 : 0;
          var node = this.$view;
          if (ind >= node.childNodes.length) {
            node.appendChild(view.$view);
          }
          else {
            node.insertBefore(view.$view, node.childNodes[ind]);
          }
        }
      };
      Layout.prototype._parseConfig = function (config) {
        this.$cells = [];
        this._xLayout = !config.rows;
        var cells = config.rows || config.cols || config.views;
        for (var i = 0; i < cells.length; i++) {
          var cell = cells[i];
          cell.mode = this._xLayout ? "x" : "y";
          var $content = this.$factory.initUI(cell, this);
          if (!$content) {
            cells.splice(i, 1);
            i--;
          } else {
            $content.$parent = this;
            this.$cells.push($content);
          }
        }
      };
      Layout.prototype.getCells = function () {
        return this.$cells;
      };
      Layout.prototype.render = function () {
        var view = domHelpers.insertNode(this.$container, this.$toHTML());
        this.$fill(view, null);
        this.callEvent("onReady", []);
        this.resize();

        // do simple repaint after the first call
        this.render = this.resize;
      };
      Layout.prototype.$fill = function (node, parent) {
        this.$view = node;
        this.$parent = parent;
        var cells = domHelpers.getChildNodes(node, "gantt_layout_cell");
        for (var i = cells.length - 1; i >= 0; i--) {
          var sub = this.$cells[i];
          sub.$fill(cells[i], this);
          // initially hidden cell
          if (sub.$config.hidden) {
            sub.$view.parentNode.removeChild(sub.$view);
          }
        }
      };
      Layout.prototype.$toHTML = function () {
        var mode = this._xLayout ? "x" : "y";
        var html = [];
        for (var i = 0; i < this.$cells.length; i++) {
          html.push(this.$cells[i].$toHTML());
        }
        return _super.prototype.$toHTML.call(this, html.join(""), (this.$root ? "gantt_layout_root " : "") + "gantt_layout gantt_layout_" + mode);
      };

      Layout.prototype.getContentSize = function (mode) {
        var contentWidth = 0,
          contentHeight = 0;

        var cellSize, cell, borders;
        for (var i = 0; i < this.$cells.length; i++) {
          cell = this.$cells[i];
          if (cell.$config.hidden)
            continue;

          cellSize = cell.getContentSize(mode);

          if (cell.$config.view === "scrollbar" && mode[cell.$config.scroll]) {
            cellSize.height = 0;
            cellSize.width = 0;
          }

          if (cell.$config.resizer) {
            if (this._xLayout) {
              cellSize.height = 0;
            } else {
              cellSize.width = 0;
            }
          }

          borders = cell._getBorderSizes();

          if (this._xLayout) {
            contentWidth += (cellSize.width + borders.horizontal);
            contentHeight = Math.max(contentHeight, (cellSize.height + borders.vertical));
          } else {
            contentWidth = Math.max(contentWidth, cellSize.width + borders.horizontal);
            contentHeight += cellSize.height + borders.vertical;
          }
        }

        borders = this._getBorderSizes();
        contentWidth += borders.horizontal;
        contentHeight += borders.vertical;

        if (this.$root) {
          contentWidth += 1;
          contentHeight += 1;
        }

        return {
          width: contentWidth,
          height: contentHeight
        };
      };

      Layout.prototype._cleanElSize = function (value) {
        return ((value || "").toString().replace("px", "") * 1 || 0);
      };
      Layout.prototype._getBoxStyles = function (div) {
        var computed = null;
        if (window.getComputedStyle) {
          computed = window.getComputedStyle(div, null);
        } else {
          //IE with elem.currentStyle does not calculate sizes from %, so will use the default approach
          computed = {
            "width": div.clientWidth,
            "height": div.clientHeight
          };
        }
        var properties = [
          "width",
          "height",

          "paddingTop",
          "paddingBottom",
          "paddingLeft",
          "paddingRight",

          "borderLeftWidth",
          "borderRightWidth",
          "borderTopWidth",
          "borderBottomWidth"
        ];
        var styles: any = {
          boxSizing: (computed.boxSizing == "border-box")
        };

        if (computed.MozBoxSizing) {
          styles.boxSizing = (computed.MozBoxSizing == "border-box");
        }
        for (var i = 0; i < properties.length; i++) {
          styles[properties[i]] = computed[properties[i]] ? this._cleanElSize(computed[properties[i]]) : 0;
        }


        var box = {
          horPaddings: (styles.paddingLeft + styles.paddingRight + styles.borderLeftWidth + styles.borderRightWidth),
          vertPaddings: (styles.paddingTop + styles.paddingBottom + styles.borderTopWidth + styles.borderBottomWidth),
          borderBox: styles.boxSizing,
          innerWidth: styles.width,
          innerHeight: styles.height,
          outerWidth: styles.width,
          outerHeight: styles.height
        };


        if (box.borderBox) {
          box.innerWidth -= box.horPaddings;
          box.innerHeight -= box.vertPaddings;
        } else {
          box.outerWidth += box.horPaddings;
          box.outerHeight += box.vertPaddings;
        }

        return box;
      };

      Layout.prototype._getAutosizeMode = function (config) {
        var res = { x: false, y: false };
        if (config === "xy") {
          res.x = res.y = true;
        } else if (config === "y" || config === true) {
          res.y = true;
        } else if (config === "x") {
          res.x = true;
        }
        return res;
      };

      Layout.prototype.autosize = function (mode) {
        var res = this._getAutosizeMode(mode);
        var boxSizes = this._getBoxStyles(this.$container);
        var contentSizes = this.getContentSize(mode);

        var node = this.$container;
        if (res.x) {
          if (boxSizes.borderBox) {
            contentSizes.width += boxSizes.horPaddings;
          }
          node.style.width = contentSizes.width + "px";
        }
        if (res.y) {
          if (boxSizes.borderBox) {
            contentSizes.height += boxSizes.vertPaddings;
          }
          node.style.height = contentSizes.height + "px";
        }
      };

      Layout.prototype.getSize = function () {
        this._sizes = [];
        var width = 0;
        var minWidth = 0;
        var maxWidth = 100000;
        var height = 0;
        var maxHeight = 100000;
        var minHeight = 0;

        for (var i = 0; i < this.$cells.length; i++) {

          var size = this._sizes[i] = this.$cells[i].getSize();
          if (this.$cells[i].$config.hidden) {
            continue;
          }
          if (this._xLayout) {
            if (!size.width && size.minWidth) {
              width += size.minWidth;
            }
            else {
              width += size.width;
            }
            maxWidth += size.maxWidth;
            minWidth += size.minWidth;
            height = Math.max(height, size.height);
            maxHeight = Math.min(maxHeight, size.maxHeight); // min of maxHeight
            minHeight = Math.max(minHeight, size.minHeight); // max of minHeight
          }
          else {
            if (!size.height && size.minHeight) {
              height += size.minHeight;
            }
            else {
              height += size.height;
            }
            maxHeight += size.maxHeight;
            minHeight += size.minHeight;
            width = Math.max(width, size.width);
            maxWidth = Math.min(maxWidth, size.maxWidth); // min of maxWidth
            minWidth = Math.max(minWidth, size.minWidth); // max of minWidth
          }
        }
        var self = _super.prototype.getSize.call(this);
        // maxWidth
        if (self.maxWidth >= 100000) {
          self.maxWidth = maxWidth;
        }
        // maxHeight
        if (self.maxHeight >= 100000) {
          self.maxHeight = maxHeight;
        }
        // minWidth
        self.minWidth = self.minWidth !== self.minWidth ? 0 : self.minWidth;// || self.width || Math.max(minWidth, width);
        // minHeight
        self.minHeight = self.minHeight !== self.minHeight ? 0 : self.minHeight;//self.minHeight || self.height || Math.max(minHeight, height);
        // sizes with paddings and margins
        if (this._xLayout) {
          self.minWidth += this.$config.margin * (this.$cells.length) || 0;
          self.minWidth += this.$config.padding * 2 || 0;
          self.minHeight += (this.$config.padding * 2) || 0;
        }
        else {
          self.minHeight += this.$config.margin * (this.$cells.length) || 0;
          self.minHeight += (this.$config.padding * 2) || 0;
        }

        return self;
      };
      // calc total gravity and free space
      Layout.prototype._calcFreeSpace = function (s, cell, xLayout) {
        var min = xLayout ? cell.minWidth : cell.minHeight;
        var max = xLayout ? cell.maxWidth : cell.maxWidth;
        var side = s;
        if (!side) {
          side = Math.floor(this._free / this._gravity * cell.gravity);
          if (side > max) {
            side = max;
            this._free -= side;
            this._gravity -= cell.gravity;
          }
          if (side < min) {
            side = min;
            this._free -= side;
            this._gravity -= cell.gravity;
          }
        }
        else {
          if (side > max) {
            side = max;
          }
          if (side < min) {
            side = min;
          }
          this._free -= side;
        }
        return side;
      };
      Layout.prototype._calcSize = function (s, size, xLayout) {
        var side = s;
        var min = xLayout ? size.minWidth : size.minHeight;
        var max = xLayout ? size.maxWidth : size.maxHeight;
        if (!side) {
          side = Math.floor(this._free / this._gravity * size.gravity);
        }
        if (side > max) {
          side = max;
        }
        if (side < min) {
          side = min;
        }
        return side;
      };

      Layout.prototype._configureBorders = function () {
        if (this.$root) {
          this._setBorders([
            this._borders.left,
            this._borders.top,
            this._borders.right,
            this._borders.bottom
          ],
            this);
        }

        var borderClass = this._xLayout ? this._borders.right : this._borders.bottom;

        var cells = this.$cells;

        var lastVisibleIndex = cells.length - 1;
        for (var i = lastVisibleIndex; i >= 0; i--) {
          if (!cells[i].$config.hidden) {
            lastVisibleIndex = i;
            break;
          }
        }

        for (var i = 0; i < cells.length; i++) {
          if (cells[i].$config.hidden) {
            continue;
          }

          var lastCell = i >= lastVisibleIndex;
          var borderColorClass = "";
          if (!lastCell && cells[i + 1]) {
            if (cells[i + 1].$config.view == "scrollbar") {
              if (this._xLayout) {
                lastCell = true;
              } else {
                borderColorClass = "gantt_layout_cell_border_transparent";
              }

            }
          }


          this._setBorders(lastCell ? [] : [borderClass, borderColorClass], cells[i]);
        }
      };

      Layout.prototype._updateCellVisibility = function () {
        var oldVisibleCells = this._visibleCells || {};
        var firstCall = !this._visibleCells;
        var visibleCells = {};
        var cell;
        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (!firstCall && cell.$config.hidden && oldVisibleCells[cell.$id]) {
            cell._hide(true);
          } else if (!cell.$config.hidden && !oldVisibleCells[cell.$id]) {
            cell._hide(false);
          }

          if (!cell.$config.hidden) {
            visibleCells[cell.$id] = true;
          }
        }
        this._visibleCells = visibleCells;
      };

      Layout.prototype.setSize = function (x, y) {
        this._configureBorders();
        _super.prototype.setSize.call(this, x, y);
        y = this.$lastSize.contentY;
        x = this.$lastSize.contentX;

        var padding = (this.$config.padding || 0);
        this.$view.style.padding = padding + "px";
        this._gravity = 0;
        this._free = this._xLayout ? x : y;
        this._free -= padding * 2;
        // calc all gravity

        var cell,
          size;

        this._updateCellVisibility();

        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          var margin = (this.$config.margin || 0);
          if (cell.$name == "resizer" && !margin) {
            margin = -1;
          }

          // set margins to child cell
          var cellView = cell.$view;

          var marginSide = this._xLayout ? "marginRight" : "marginBottom";
          if (i !== this.$cells.length - 1) {
            cellView.style[marginSide] = margin + "px";
            this._free -= margin; // calc free space without margin
          }
          size = this._sizes[i];
          if (this._xLayout) {
            if (!size.width) {
              this._gravity += size.gravity;
            }
          }
          else {
            if (!size.height) {
              this._gravity += size.gravity;
            }
          }
        }
        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          size = this._sizes[i];
          var width = size.width;
          var height = size.height;
          if (this._xLayout) {
            this._calcFreeSpace(width, size, true);
          }
          else {
            this._calcFreeSpace(height, size, false);
          }
        }
        for (var i = 0; i < this.$cells.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          size = this._sizes[i];
          var dx = void 0;
          var dy = void 0;
          if (this._xLayout) {
            dx = this._calcSize(size.width, size, true);
            dy = y - padding * 2; // layout height without paddings
          }
          else {
            dx = x - padding * 2; // layout width without paddings
            dy = this._calcSize(size.height, size, false);
          }

          cell.setSize(dx, dy);
        }

      };

      return Layout;
    }(Cell));

    return Layout;
  }

  viewLayoutJs = function () {

    var __extends = this.helperService.extends,
      Layout = this.layoutJs,
      Cell = this.cellJs;

    var ViewLayout = (function (_super) {
      "use strict";

      __extends(ViewLayout, _super);
      function ViewLayout(parent, config, factory) {
        var _this = _super.apply(this, arguments) || this;
        for (var i = 0; i < _this.$cells.length; i++) {
          _this.$cells[i].$config.hidden = (i !== 0);
        }
        _this.$cell = _this.$cells[0];
        _this.$name = "viewLayout";

        return _this;
      }
      ViewLayout.prototype.cell = function (id) {
        var cell = _super.prototype.cell.call(this, id);
        if (!cell.$view) {
          this.$fill(null, this);
        }
        return cell;
      };
      ViewLayout.prototype.moveView = function (view) {
        var body = this.$view;
        if (this.$cell) {
          this.$cell.$config.hidden = true;
          body.removeChild(this.$cell.$view);
        }
        this.$cell = view;
        body.appendChild(view.$view);
      };
      ViewLayout.prototype.setSize = function (x, y) {
        Cell.prototype.setSize.call(this, x, y);
      };

      ViewLayout.prototype.setContentSize = function () {
        var size = this.$lastSize;
        this.$cell.setSize(size.contentX, size.contentY);
      };

      ViewLayout.prototype.getSize = function () {
        var sizes = _super.prototype.getSize.call(this);
        if (this.$cell) {
          var cellSize = this.$cell.getSize();
          if (this.$config.byMaxSize) {
            for (var i = 0; i < this.$cells.length; i++) {
              var otherCell = this.$cells[i].getSize();
              for (var cell in cellSize) {
                cellSize[cell] = Math.max(cellSize[cell], otherCell[cell]);
              }
            }
          }
          for (var size in sizes) {
            sizes[size] = sizes[size] || cellSize[size];
          }
          sizes.gravity = Math.max(sizes.gravity, cellSize.gravity);
        }
        return sizes;
      };
      return ViewLayout;
    }(Layout));

    return ViewLayout;

  }

  viewCellJs = function () {

    // tslint:disable-next-line: variable-name
    let __extends = this.helperService.extends,
      utils = this.helperService.utils,
      // tslint:disable-next-line: prefer-const
      Cell = this.cellJs;

    var ViewCell = (function (_super) {
      "use strict";

      __extends(ViewCell, _super);
      function ViewCell(parent, config, factory) {

        var _this = _super.apply(this, arguments) || this;

        if (config.view) {
          if (config.id) {
            // pass id to the nested view
            this.$id = utils.uid();
          }
          var childConfig = utils.copy(config);
          delete childConfig.config;
          delete childConfig.templates;

          this.$content = this.$factory.createView(config.view, this, childConfig, this);
          if (!this.$content)
            return false;
        }

        _this.$name = "viewCell";
        return _this;
      }

      ViewCell.prototype.destructor = function () {
        this.clear();
        _super.prototype.destructor.call(this);
      };

      ViewCell.prototype.clear = function () {

        this.$initialized = false;

        // call destructor
        if (this.$content) {
          var method = this.$content.unload || this.$content.destructor;
          if (method) {
            method.call(this.$content);
          }
        }

        _super.prototype.clear.call(this);

      };

      ViewCell.prototype.scrollTo = function (left, top) {

        if (this.$content && this.$content.scrollTo) {
          this.$content.scrollTo(left, top);
        } else {
          _super.prototype.scrollTo.call(this, left, top);
        }
      };

      ViewCell.prototype._setContentSize = function (x, y) {
        var borders = this._getBorderSizes();
        var outerX = x + borders.horizontal;
        var outerY = y + borders.vertical;
        this.$config.width = outerX;
        this.$config.height = outerY;
      };

      ViewCell.prototype.setSize = function (x, y) {
        _super.prototype.setSize.call(this, x, y);

        if (!this.$preResize && this.$content) {
          if (!this.$initialized) {
            this.$initialized = true;
            var header = this.$view.childNodes[0];
            var content = this.$view.childNodes[1];
            if (!content) content = header;

            /*if(this.$content.$config){
              this.$content.$config.width = this.$lastSize.contentX;
              this.$content.$config.height = this.$lastSize.contentY;
            }*/
            this.$content.init(content);
          }
        }
      };

      ViewCell.prototype.setContentSize = function () {
        if (!this.$preResize && this.$content) {
          if (this.$initialized) {
            this.$content.setSize(this.$lastSize.contentX, this.$lastSize.contentY);
          }
        }
      };


      ViewCell.prototype.getContentSize = function () {
        var size = _super.prototype.getContentSize.call(this);

        if (this.$content && this.$initialized) {
          var childSize = this.$content.getSize();
          size.width = childSize.contentX === undefined ? childSize.width : childSize.contentX;
          size.height = childSize.contentY === undefined ? childSize.height : childSize.contentY;
        }

        var borders = this._getBorderSizes();
        size.width += borders.horizontal;
        size.height += borders.vertical;

        return size;
      };

      return ViewCell;
    }(Cell));

    return ViewCell;

  }

  resizerJs = function () {

    return null;

  }

  scrollbarJs = function () {

    var __extends = this.helperService.extends,
      domHelpers = this.helperService,
      utils = this.helperService,
      env = this.constantService.env,
      Cell = this.cellJs;

    var ScrollbarCell = (function (_super) {
      "use strict";

      var SCROLL_MODIFIER_KEYS = ["altKey", "shiftKey", "metaKey"]; // it's no way to disable ctrl+wheel
      __extends(ScrollbarCell, _super);
      function ScrollbarCell(parent, config, factory, gantt) {

        var _this = _super.apply(this, arguments) || this;
        this.$config = utils.mixin(config, { scroll: "x" });
        _this._scrollHorizontalHandler = utils.bind(_this._scrollHorizontalHandler, _this);
        _this._scrollVerticalHandler = utils.bind(_this._scrollVerticalHandler, _this);
        _this._outerScrollVerticalHandler = utils.bind(_this._outerScrollVerticalHandler, _this);
        _this._outerScrollHorizontalHandler = utils.bind(_this._outerScrollHorizontalHandler, _this);
        _this._mouseWheelHandler = utils.bind(_this._mouseWheelHandler, _this);

        this.$config.hidden = true;
        var size = gantt.config.scroll_size;

        if (gantt.env.isIE) {
          // full element height/width must be bigger than just a browser scrollbar,
          // otherwise the scrollbar element won't be scrolled on click
          size += 1;
        }

        if (this._isHorizontal()) {
          _this.$config.height = size;
          _this.$parent.$config.height = size;
        } else {
          _this.$config.width = size;
          _this.$parent.$config.width = size;
        }

        this.$config.scrollPosition = 0;

        _this.$name = "scroller";
        return _this;
      }

      ScrollbarCell.prototype.init = function (container) {
        container.innerHTML = this.$toHTML();
        this.$view = container.firstChild;

        if (!this.$view) {
          this.init();
        }
        if (this._isVertical()) {
          this._initVertical();
        } else {
          this._initHorizontal();
        }
        this._initMouseWheel();
        this._initLinkedViews();
      };

      ScrollbarCell.prototype.$toHTML = function () {
        var className = this._isHorizontal() ? "gantt_hor_scroll" : "gantt_ver_scroll";
        return "<div class='gantt_layout_cell " + className + "'><div style='" + (this._isHorizontal() ? "width:2000px" : "height:2000px") + "'></div></div>";
      };

      ScrollbarCell.prototype._getRootParent = function () {
        var parent = this.$parent;
        while (parent && parent.$parent) {
          parent = parent.$parent;
        }
        if (parent) {
          return parent;
        }
      };


      function eachCell(root, res) {
        res.push(root);
        if (root.$cells) {
          for (var i = 0; i < root.$cells.length; i++) {
            eachCell(root.$cells[i], res);
          }
        }
      }
      ScrollbarCell.prototype._eachView = function () {
        var res = [];
        eachCell(this._getRootParent(), res);
        return res;
      };

      ScrollbarCell.prototype._getLinkedViews = function () {
        var views = this._eachView();
        var res = [];
        for (var i = 0; i < views.length; i++) {
          if (views[i].$config && ((this._isVertical() && views[i].$config.scrollY == this.$id) || (this._isHorizontal() && views[i].$config.scrollX == this.$id))) {
            res.push(views[i]);
          }
        }
        return res;
      };


      ScrollbarCell.prototype._initHorizontal = function () {
        this.$scroll_hor = this.$view;
        this.$domEvents.attach(this.$view, "scroll", this._scrollHorizontalHandler);

      };

      ScrollbarCell.prototype._initLinkedViews = function () {
        var views = this._getLinkedViews();
        var css = this._isVertical() ? "gantt_layout_outer_scroll gantt_layout_outer_scroll_vertical" : "gantt_layout_outer_scroll gantt_layout_outer_scroll_horizontal";
        for (var i = 0; i < views.length; i++) {
          //views[i].$config.css = [views[i].$config.css || "", css].join(" ");
          domHelpers.addClassName(views[i].$view || views[i].getNode(), css);
        }
      };

      ScrollbarCell.prototype._initVertical = function () {
        this.$scroll_ver = this.$view;
        this.$domEvents.attach(this.$view, "scroll", this._scrollVerticalHandler);
      };

      ScrollbarCell.prototype._updateLinkedViews = function () {
      };

      ScrollbarCell.prototype._initMouseWheel = function () {
        var ff = env.isFF;
        if (ff)
          this.$domEvents.attach(this._getRootParent().$view, "wheel", this._mouseWheelHandler);
        else
          this.$domEvents.attach(this._getRootParent().$view, "mousewheel", this._mouseWheelHandler);
      };




      ScrollbarCell.prototype.scrollHorizontally = function (left) {
        if (this._scrolling) return;
        this._scrolling = true;

        this.$scroll_hor.scrollLeft = left;
        this.$config.codeScrollLeft = left;
        left = this.$scroll_hor.scrollLeft;

        var views = this._getLinkedViews();
        for (var i = 0; i < views.length; i++) {
          if (views[i].scrollTo) {
            views[i].scrollTo(left, undefined);
          }
        }
        var oldSize = this.$config.scrollPosition;
        this.$config.scrollPosition = left;
        this.callEvent("onScroll", [oldSize, left, this.$config.scroll]);
        this._scrolling = false;
      };
      ScrollbarCell.prototype.scrollVertically = function (top) {
        if (this._scrolling) return;
        this._scrolling = true;

        this.$scroll_ver.scrollTop = top;
        top = this.$scroll_ver.scrollTop;

        var views = this._getLinkedViews();

        for (var i = 0; i < views.length; i++) {
          if (views[i].scrollTo) {
            views[i].scrollTo(undefined, top);
          }
        }
        var oldSize = this.$config.scrollPosition;
        this.$config.scrollPosition = top;
        this.callEvent("onScroll", [oldSize, top, this.$config.scroll]);
        this._scrolling = false;
      };

      ScrollbarCell.prototype._isVertical = function () {
        return this.$config.scroll == "y";
      };
      ScrollbarCell.prototype._isHorizontal = function () {
        return this.$config.scroll == "x";
      };
      ScrollbarCell.prototype._scrollHorizontalHandler = function (e) {
        if (this._isVertical() || this._scrolling) {
          return;
        }

        //in safari we can catch previous onscroll after setting new value from mouse-wheel event
        //set delay to prevent value drifiting
        if ((new Date().getTime()) - (this._wheel_time || 0) < 100) {
          return true;
        }
        if (this.$gantt._touch_scroll_active) return;
        var left = this.$scroll_hor.scrollLeft;

        this.scrollHorizontally(left);

        this._oldLeft = this.$scroll_hor.scrollLeft;
      };
      ScrollbarCell.prototype._outerScrollHorizontalHandler = function (e) {
        if (this._isVertical()) {
          return;
        }
      };

      ScrollbarCell.prototype.show = function () {
        this.$parent.show();
      };
      ScrollbarCell.prototype.hide = function () {
        this.$parent.hide();
      };

      ScrollbarCell.prototype._getScrollSize = function () {
        var scrollSize = 0;
        var outerSize = 0;
        var isHorizontal = this._isHorizontal();

        var linked = this._getLinkedViews();
        var view;
        var scrollProperty = isHorizontal ? "scrollWidth" : "scrollHeight",
          innerSizeProperty = isHorizontal ? "contentX" : "contentY";
        var outerProperty = isHorizontal ? "x" : "y";
        var offset = this._getScrollOffset();

        for (var i = 0; i < linked.length; i++) {
          view = linked[i];
          if (!(view && view.$content && view.$content.getSize && !view.$config.hidden)) continue;

          var sizes = view.$content.getSize();
          var cellScrollSize;
          if (sizes.hasOwnProperty(scrollProperty)) {
            cellScrollSize = sizes[scrollProperty];
          } else {
            cellScrollSize = sizes[innerSizeProperty];
          }

          if (offset) {
            // precalculated vertical/horizontal offsets of scrollbar to emulate 4.x look
            if (sizes[innerSizeProperty] > sizes[outerProperty] && sizes[innerSizeProperty] > scrollSize && (cellScrollSize > (sizes[outerProperty] - offset + 2))) {
              scrollSize = cellScrollSize + (isHorizontal ? 0 : 2);
              outerSize = sizes[outerProperty];
            }
          } else {
            var nonScrollableSize = Math.max(sizes[innerSizeProperty] - cellScrollSize, 0);
            var scrollableViewPortSize = Math.max(sizes[outerProperty] - nonScrollableSize, 0);
            cellScrollSize = cellScrollSize + nonScrollableSize;

            if (cellScrollSize > scrollableViewPortSize && (cellScrollSize > scrollSize)) {
              //|| (cellScrollSize === scrollSize && sizes[outerProperty] < outerSize) // same scroll width but smaller scrollable view port

              scrollSize = cellScrollSize;
              outerSize = sizes[outerProperty];
            }
          }
        }

        return {
          outerScroll: outerSize,
          innerScroll: scrollSize
        };
      };

      ScrollbarCell.prototype.scroll = function (position) {
        if (this._isHorizontal()) {
          this.scrollHorizontally(position);
        } else {
          this.scrollVertically(position);
        }
      };

      ScrollbarCell.prototype.getScrollState = function () {
        return {
          visible: this.isVisible(),
          direction: this.$config.scroll,
          size: this.$config.outerSize,
          scrollSize: this.$config.scrollSize || 0,
          position: this.$config.scrollPosition || 0
        };
      };

      ScrollbarCell.prototype.setSize = function (width, height) {
        _super.prototype.setSize.apply(this, arguments);

        var scrollSizes = this._getScrollSize();

        var ownSize = (this._isVertical() ? height : width) - this._getScrollOffset() + (this._isHorizontal() ? 1 : 0);

        if (scrollSizes.innerScroll && ownSize > scrollSizes.outerScroll) {
          scrollSizes.innerScroll += (ownSize - scrollSizes.outerScroll);
        }
        this.$config.scrollSize = scrollSizes.innerScroll;

        this.$config.width = width;
        this.$config.height = height;
        this._setScrollSize(scrollSizes.innerScroll);
      };

      ScrollbarCell.prototype.isVisible = function () {
        return !!(this.$parent && this.$parent.$view.parentNode);
      };

      ScrollbarCell.prototype.shouldShow = function () {
        var scrollSizes = this._getScrollSize();
        if (!scrollSizes.innerScroll && (this.$parent && this.$parent.$view.parentNode)) {
          return false;
        } else if (scrollSizes.innerScroll && !(this.$parent && this.$parent.$view.parentNode)) {
          return true;
        } else {
          return false;
        }
      };

      ScrollbarCell.prototype.shouldHide = function () {
        var scrollSizes = this._getScrollSize();
        if (!scrollSizes.innerScroll && (this.$parent && this.$parent.$view.parentNode)) {
          return true;
        } else {
          return false;
        }
      };


      ScrollbarCell.prototype.toggleVisibility = function () {
        if (this.shouldHide()) {
          this.hide();
        } else if (this.shouldShow()) {
          this.show();
        }
      };

      ScrollbarCell.prototype._getScaleOffset = function (view) {
        var offset = 0;
        if (view && (view.$config.view == "timeline" || view.$config.view == "grid")) {
          offset = view.$content.$getConfig().scale_height;
        }
        return offset;
      };

      ScrollbarCell.prototype._getScrollOffset = function () {
        var offset = 0;
        if (this._isVertical()) {
          var parentLayout = this.$parent.$parent;
          offset = Math.max(
            this._getScaleOffset(parentLayout.getPrevSibling(this.$parent.$id)),
            this._getScaleOffset(parentLayout.getNextSibling(this.$parent.$id))
          );
        } else {
          var linked = this._getLinkedViews();

          for (var i = 0; i < linked.length; i++) {
            var view = linked[i],
              vparent = view.$parent;
            var cells = vparent.$cells;

            var last = cells[cells.length - 1];

            if (last && last.$config.view == "scrollbar" && last.$config.hidden === false) {
              offset = last.$config.width;
              break;
            }

          }
        }
        return offset || 0;
      };

      ScrollbarCell.prototype._setScrollSize = function (size) {
        var property = this._isHorizontal() ? "width" : "height";
        var scrollbar = this._isHorizontal() ? this.$scroll_hor : this.$scroll_ver;

        var offset = this._getScrollOffset();

        var node = scrollbar.firstChild;

        if (offset) {
          if (this._isVertical()) {

            this.$config.outerSize = (this.$config.height - offset + 3);
            scrollbar.style.height = this.$config.outerSize + "px";
            scrollbar.style.top = (offset - 1) + "px";
            domHelpers.addClassName(scrollbar, this.$parent._borders.top);
            domHelpers.addClassName(scrollbar.parentNode, "gantt_task_vscroll");
          } else {
            this.$config.outerSize = (this.$config.width - offset + 1);
            scrollbar.style.width = this.$config.outerSize + "px";
            //domHelpers.addClassName(scrollbar, this.$parent._borders.right);
          }
        } else {
          scrollbar.style.top = "auto";
          domHelpers.removeClassName(scrollbar, this.$parent._borders.top);
          domHelpers.removeClassName(scrollbar.parentNode, "gantt_task_vscroll");
          this.$config.outerSize = this.$config.height;
        }

        node.style[property] = size + "px";
      };

      ScrollbarCell.prototype._scrollVerticalHandler = function (e) {
        if (this._scrollHorizontalHandler() || this._scrolling) {
          return;
        }

        if (this.$gantt._touch_scroll_active) return;
        var top = this.$scroll_ver.scrollTop;
        var prev = this._oldTop;
        if (top == prev) return;

        this.scrollVertically(top);

        this._oldTop = this.$scroll_ver.scrollTop;

      };
      ScrollbarCell.prototype._outerScrollVerticalHandler = function (e) {
        if (this._scrollHorizontalHandler()) {
          return;
        }
      };

      ScrollbarCell.prototype._checkWheelTarget = function (targetNode) {
        var connectedViews = this._getLinkedViews().concat(this);

        for (var i = 0; i < connectedViews.length; i++) {
          var node = connectedViews[i].$view;
          if (domHelpers.isChildOf(targetNode, node)) {
            return true;
          }
        }

        return false;
      };

      ScrollbarCell.prototype._mouseWheelHandler = function (e) {
        var target = e.target || e.srcElement;

        if (!this._checkWheelTarget(target))
          return;

        this._wheel_time = new Date();

        var res: any = {};
        var ff = env.isFF;
        var wx = ff ? (e.deltaX * -20) : e.wheelDeltaX * 2;
        var wy = ff ? (e.deltaY * -40) : e.wheelDelta;

        var horizontalScrollModifier = this.$gantt.config.horizontal_scroll_key;

        if (horizontalScrollModifier !== false) {
          if (SCROLL_MODIFIER_KEYS.indexOf(horizontalScrollModifier) >= 0) {
            if (e[horizontalScrollModifier] && !(e.deltaX || e.wheelDeltaX)) {
              // shift+mousewheel for horizontal scroll
              wx = wy * 2;
              wy = 0;
            }
          }
        }


        if (wx && Math.abs(wx) > Math.abs(wy)) {
          if (this._isVertical()) {
            return;
          }

          if (res.x) return true;//no horisontal scroll, must not block scrolling
          if (!this.$scroll_hor || !this.$scroll_hor.offsetWidth) return true;

          var dir = wx / -40;
          var oldLeft = this._oldLeft;
          var left = oldLeft + dir * 30;
          this.scrollHorizontally(left);
          this.$scroll_hor.scrollLeft = left;
          // not block scroll if position hasn't changed
          if (oldLeft == this.$scroll_hor.scrollLeft) {
            return true;
          }

          this._oldLeft = this.$scroll_hor.scrollLeft;
        } else {
          if (this._isHorizontal()) {
            return;
          }

          if (res.y) return true;//no vertical scroll, must not block scrolling
          if (!this.$scroll_ver || !this.$scroll_ver.offsetHeight) return true;

          var dir = wy / -40;
          if (typeof wy == "undefined")
            dir = e.detail;

          var oldTop = this._oldTop;
          var top = this.$scroll_ver.scrollTop + dir * 30;

          //if(!this.$gantt.config.prevent_default_scroll &&
          //	(this.$gantt._cached_scroll_pos && ((this.$gantt._cached_scroll_pos.y == top) || (this.$gantt._cached_scroll_pos.y <= 0 && top <= 0)))) return true;


          this.scrollVertically(top);
          this.$scroll_ver.scrollTop = top;

          // not block scroll if position hasn't changed
          if (oldTop == this.$scroll_ver.scrollTop) {
            return true;
          }
          this._oldTop = this.$scroll_ver.scrollTop;
        }

        if (e.preventDefault)
          e.preventDefault();
        e.cancelBubble = true;
        return false;
      };

      return ScrollbarCell;
    })(Cell);

    return ScrollbarCell;

    /***/
  }

  scaleHelperJs = function () {

    var utils = this.helperService.utils;

    function ScaleHelper(gantt) {
      var dateHelper = gantt.date;
      var services = gantt.$services;

      return {
        getSum: function (sizes, from, to) {
          if (to === undefined)
            to = sizes.length - 1;
          if (from === undefined)
            from = 0;

          var summ = 0;
          for (var i = from; i <= to; i++)
            summ += sizes[i];

          return summ;
        },
        setSumWidth: function (sum_width, scale, from, to) {
          var parts = scale.width;

          if (to === undefined)
            to = parts.length - 1;
          if (from === undefined)
            from = 0;
          var length = to - from + 1;

          if (from > parts.length - 1 || length <= 0 || to > parts.length - 1)
            return;

          var oldWidth = this.getSum(parts, from, to);

          var diff = sum_width - oldWidth;

          this.adjustSize(diff, parts, from, to);
          this.adjustSize(-diff, parts, to + 1);

          scale.full_width = this.getSum(parts);
        },
        splitSize: function (width, count) {
          var arr = [];
          for (var i = 0; i < count; i++) arr[i] = 0;

          this.adjustSize(width, arr);
          return arr;

        },
        adjustSize: function (width, parts, from, to) {
          if (!from)
            from = 0;
          if (to === undefined)
            to = parts.length - 1;

          var length = to - from + 1;

          var full = this.getSum(parts, from, to);

          for (var i = from; i <= to; i++) {
            var share = Math.floor(width * (full ? (parts[i] / full) : (1 / length)));

            full -= parts[i];
            width -= share;
            length--;

            parts[i] += share;
          }
          parts[parts.length - 1] += width;
        },
        sortScales: function (scales) {
          function cellSize(unit, step) {
            var d = new Date(1970, 0, 1);
            return dateHelper.add(d, step, unit) - d.getDate();
          }

          scales.sort(function (a, b) {
            if (cellSize(a.unit, a.step) < cellSize(b.unit, b.step)) {
              return 1;
            } else if (cellSize(a.unit, a.step) > cellSize(b.unit, b.step)) {
              return -1;
            } else {
              return 0;
            }
          });

          for (var i = 0; i < scales.length; i++) {
            scales[i].index = i;
          }
        },
        _isLegacyMode: function (config) {
          var scaleConfig = config || services.config();
          return scaleConfig.scale_unit || scaleConfig.date_scale || scaleConfig.subscales;
        },
        _prepareScaleObject: function (scale) {
          var format = scale.format;
          if (!format) {
            format = scale.template || scale.date || "%d %M";
          }

          if (typeof format === "string") {
            format = gantt.date.date_to_str(format);
          }
          return {
            unit: scale.unit || "day",
            step: scale.step || 1,
            format: format,
            css: scale.css
          };
        },
        primaryScale: function (config) {
          var templates = services.getService("templateLoader");
          var legacyMode = this._isLegacyMode(config);

          var scaleConfig = config || services.config();

          var result;
          if (legacyMode) {
            templates.initTemplate("date_scale", undefined, undefined, scaleConfig, services.templates());
            result = {
              unit: services.config().scale_unit,
              step: services.config().step,
              template: services.templates().date_scale,
              date: services.config().date_scale,
              css: services.templates().scale_cell_class
            };
          } else {
            var primaryScale = scaleConfig.scales[0];
            result = {
              unit: primaryScale.unit,
              step: primaryScale.step,
              template: primaryScale.template,
              format: primaryScale.format,
              date: primaryScale.date,
              css: primaryScale.css || services.templates().scale_cell_class
            };
          }

          return this._prepareScaleObject(result);
        },
        getSubScales: function (config) {
          var legacyMode = this._isLegacyMode(config);
          var scaleConfig = config || services.config();
          var scales;
          if (legacyMode) {
            scales = scaleConfig.subscales || [];
          } else {
            scales = scaleConfig.scales.slice(1);
          }

          return scales.map(function (scale) {
            return this._prepareScaleObject(scale);
          }.bind(this));
        },

        prepareConfigs: function (scales, min_coll_width, container_width, scale_height, minDate, maxDate, rtl) {
          var heights = this.splitSize(scale_height, scales.length);
          var full_width = container_width;

          var configs = [];
          for (var i = scales.length - 1; i >= 0; i--) {
            var main_scale = (i == scales.length - 1);
            var cfg = this.initScaleConfig(scales[i], minDate, maxDate);
            if (main_scale) {
              this.processIgnores(cfg);
            }

            this.initColSizes(cfg, min_coll_width, full_width, heights[i]);
            this.limitVisibleRange(cfg);

            if (main_scale) {
              full_width = cfg.full_width;
            }

            configs.unshift(cfg);
          }


          for (var i = 0; i < configs.length - 1; i++) {
            this.alineScaleColumns(configs[configs.length - 1], configs[i]);
          }
          for (var i = 0; i < configs.length; i++) {

            if (rtl) {
              this.reverseScale(configs[i]);
            }
            this.setPosSettings(configs[i]);
          }
          return configs;

        },

        reverseScale: function (scale) {
          scale.width = scale.width.reverse();
          scale.trace_x = scale.trace_x.reverse();

          var indexes = scale.trace_indexes;
          scale.trace_indexes = {};
          scale.trace_index_transition = {};
          scale.rtl = true;
          for (var i = 0; i < scale.trace_x.length; i++) {
            scale.trace_indexes[scale.trace_x[i].valueOf()] = i;
            scale.trace_index_transition[indexes[scale.trace_x[i].valueOf()]] = i;
          }
          return scale;
        },

        setPosSettings: function (config) {
          for (var i = 0, len = config.trace_x.length; i < len; i++) {
            config.left.push((config.width[i - 1] || 0) + (config.left[i - 1] || 0));
          }
        },

        _ignore_time_config: function (date, scale) {

          if (services.config().skip_off_time) {
            var skip = true;
            var probe = date;

            // check dates in case custom scale unit, e.g. {unit: "month", step: 3}
            for (var i = 0; i < scale.step; i++) {
              if (i) {
                probe = dateHelper.add(date, i, scale.unit);
              }

              skip = skip && !this.isWorkTime(probe, scale.unit);
            }

            return skip;
          }
          return false;
        },
        //defined in an extension
        processIgnores: function (config) {
          config.ignore_x = {};
          config.display_count = config.count;
        },
        initColSizes: function (config, min_col_width, full_width, line_height) {
          var cont_width = full_width;

          config.height = line_height;

          var column_count = config.display_count === undefined ? config.count : config.display_count;

          if (!column_count)
            column_count = 1;

          config.col_width = Math.floor(cont_width / column_count);

          if (min_col_width) {
            if (config.col_width < min_col_width) {
              config.col_width = min_col_width;
              cont_width = config.col_width * column_count;
            }
          }
          config.width = [];
          var ignores = config.ignore_x || {};
          for (var i = 0; i < config.trace_x.length; i++) {
            if (ignores[config.trace_x[i].valueOf()] || (config.display_count == config.count)) {
              config.width[i] = 0;
            } else {
              // width of month columns should be proportional month duration
              var width = 1;
              if (config.unit == "month") {
                var days = Math.round((dateHelper.add(config.trace_x[i], config.step, config.unit) - config.trace_x[i]) / (1000 * 60 * 60 * 24));
                width = days;
              }
              config.width[i] = width;
            }
          }

          this.adjustSize(cont_width - this.getSum(config.width)/* 1 width per column from the code above */, config.width);
          config.full_width = this.getSum(config.width);
        },
        initScaleConfig: function (config, min_date, max_date) {
          var cfg = utils.mixin({
            count: 0,
            col_width: 0,
            full_width: 0,
            height: 0,
            width: [],
            left: [],
            trace_x: [],
            trace_indexes: {},
            min_date: new Date(min_date),
            max_date: new Date(max_date)
          }, config);

          this.eachColumn(config.unit, config.step, min_date, max_date, function (date) {
            cfg.count++;
            cfg.trace_x.push(new Date(date));
            cfg.trace_indexes[date.valueOf()] = cfg.trace_x.length - 1;
          });

          cfg.trace_x_ascending = cfg.trace_x.slice();
          return cfg;
        },
        iterateScales: function (lower_scale, upper_scale, from, to, callback) {
          var upper_dates = upper_scale.trace_x;
          var lower_dates = lower_scale.trace_x;

          var prev = from || 0;
          var end = to || (lower_dates.length - 1);
          var prevUpper = 0;


          for (var up = 1; up < upper_dates.length; up++) {
            var target_index = (lower_scale.trace_indexes[+upper_dates[up]]);
            if (target_index !== undefined && target_index <= end) {
              if (callback) {
                callback.apply(this, [prevUpper, up, prev, target_index]);
              }
              prev = target_index;
              prevUpper = up;
              continue;
            }
          }
        },
        alineScaleColumns: function (lower_scale, upper_scale, from, to) {
          this.iterateScales(lower_scale, upper_scale, from, to, function (upper_start, upper_end, lower_start, lower_end) {
            var targetWidth = this.getSum(lower_scale.width, lower_start, lower_end - 1);
            var actualWidth = this.getSum(upper_scale.width, upper_start, upper_end - 1);
            if (actualWidth != targetWidth) {
              this.setSumWidth(targetWidth, upper_scale, upper_start, upper_end - 1);
            }

          });
        },

        eachColumn: function (unit, step, min_date, max_date, callback) {
          var start = new Date(min_date),
            end = new Date(max_date);
          if (dateHelper[unit + "_start"]) {
            start = dateHelper[unit + "_start"](start);
          }

          var curr = new Date(start);
          if (+curr >= +end) {
            end = dateHelper.add(curr, step, unit);
          }
          while (+curr < +end) {
            callback.call(this, new Date(curr));
            var tzOffset = curr.getTimezoneOffset();
            curr = dateHelper.add(curr, step, unit);
            curr = gantt._correct_dst_change(curr, tzOffset, step, unit);
            if (dateHelper[unit + '_start'])
              curr = dateHelper[unit + "_start"](curr);
          }
        },
        limitVisibleRange: function (cfg) {
          var dates = cfg.trace_x;

          var left = 0, right = cfg.width.length - 1;
          var diff = 0;
          if (+dates[0] < +cfg.min_date && left != right) {
            var width = Math.floor(cfg.width[0] * ((dates[1] - cfg.min_date) / (dates[1] - dates[0])));
            diff += cfg.width[0] - width;
            cfg.width[0] = width;

            dates[0] = new Date(cfg.min_date);
          }

          var last = dates.length - 1;
          var lastDate = dates[last];
          var outDate = dateHelper.add(lastDate, cfg.step, cfg.unit);
          if (+outDate > +cfg.max_date && last > 0) {
            var width = cfg.width[last] - Math.floor(cfg.width[last] * ((outDate - cfg.max_date) / (outDate - lastDate)));
            diff += cfg.width[last] - width;
            cfg.width[last] = width;
          }

          if (diff) {
            var full = this.getSum(cfg.width);
            var shared = 0;
            for (var i = 0; i < cfg.width.length; i++) {
              var share = Math.floor(diff * (cfg.width[i] / full));
              cfg.width[i] += share;
              shared += share;
            }
            this.adjustSize(diff - shared, cfg.width);
          }

        }
      };
    }

    return ScaleHelper;


    /***/
  }

  topPostionMixinJs = function (module, exports) {

    function createMixin() {
      var topCache = {};
      return {
        _resetTopPositionHeight: function () {
          topCache = {};
        },

        /**
         * Get top coordinate by row index (order)
         * @param {number} index
         */
        getRowTop: function (index) {
          return index * this.$getConfig().row_height;
        },

        /**
         * Get top coordinate by item id
         * @param {*} task_id
         */
        getItemTop: function (taskId) {
          if (this.$config.rowStore) {
            if (topCache[taskId] !== undefined) {
              return topCache[taskId];
            }
            var store = this.$config.rowStore;
            if (!store) return 0;

            var itemIndex = store.getIndexById(taskId);

            if (itemIndex === -1 && store.getParent && store.exists(taskId)) {
              var parentId = store.getParent(taskId);
              if (store.exists(parentId)) {
                // if task is not found in list - maybe it's parent is a split task and we should use parents index instead
                var parent = store.getItem(parentId);
                if (this.$gantt.isSplitTask(parent)) {
                  return this.getRowTop(store.getIndexById(parent.id));
                }
              }
            }
            topCache[taskId] = this.getRowTop(itemIndex);
            return topCache[taskId];
          } else {
            return 0;
          }

        }
      };
    }

    return createMixin;

    /***/
  }

  canvasRenderJs = function (module, exports) {

    var createStaticBgHelper = function () {
      return {
        render: function () { },
        destroy: function () { }
      };
    };

    return {
      create: function () {
        return createStaticBgHelper();
      }
    };
  }

  timelineJs = function () {

    var ScaleHelper = this.scaleHelperJs;
    var eventable = this.eventableService;
    var utils = this.helperService.utils;
    var topPositionMixin = this.topPostionMixinJs;
    var canvasRender = this.canvasRenderJs;

    var Timeline = function (parent, config, factory, gantt) {
      this.$config = utils.mixin({}, config || {});
      this.$scaleHelper = new ScaleHelper(gantt);
      this.$gantt = gantt;
      this._posFromDateCache = {};
      utils.mixin(this, topPositionMixin());
      eventable(this);
    };

    Timeline.prototype = {
      init: function (container) {
        container.innerHTML += "<div class='gantt_task' style='width:inherit;height:inherit;'></div>";
        this.$task = container.childNodes[0];

        this.$task.innerHTML = "<div class='gantt_task_scale'></div><div class='gantt_data_area'></div>";
        this.$task_scale = this.$task.childNodes[0];

        this.$task_data = this.$task.childNodes[1];
        this.$task_data.innerHTML = "<div class='gantt_task_bg'></div><div class='gantt_links_area'></div><div class='gantt_bars_area'></div>";
        this.$task_bg = this.$task_data.childNodes[0];
        this.$task_links = this.$task_data.childNodes[1];
        this.$task_bars = this.$task_data.childNodes[2];

        this._tasks = {
          col_width: 0,
          width: [], // width of each column
          full_width: 0, // width of all columns
          trace_x: [],
          rendered: {}
        };

        var config = this.$getConfig();
        var attr = config[this.$config.bind + "_attribute"];
        var linksAttr = config[this.$config.bindLinks + "_attribute"];
        if (!attr && this.$config.bind) {
          attr = this.$config.bind + "_id";
        }
        if (!linksAttr && this.$config.bindLinks) {
          linksAttr = this.$config.bindLinks + "_id";
        }
        this.$config.item_attribute = attr || null;
        this.$config.link_attribute = linksAttr || null;

        var layers = this._createLayerConfig();
        if (!this.$config.layers) {
          this.$config.layers = layers.tasks;
        }
        if (!this.$config.linkLayers) {
          this.$config.linkLayers = layers.links;
        }

        this._attachLayers(this.$gantt);

        this.callEvent("onReady", []);
        //this.refresh();
      },

      setSize: function (width, height) {
        var config = this.$getConfig();

        if (width * 1 === width) {
          this.$config.width = width;
        }
        if (height * 1 === height) {

          this.$config.height = height;
          var dataHeight = Math.max(this.$config.height - config.scale_height);
          this.$task_data.style.height = dataHeight + 'px';
        }

        this.refresh();
        this.$task_bg.style.backgroundImage = "";

        if (config.smart_rendering && this.$config.rowStore) {
          var store = this.$config.rowStore;
          this.$task_bg.style.height = config.row_height * store.countVisible() + "px";
        } else {
          this.$task_bg.style.height = "";
        }

        var scale = this._tasks;
        //timeline area layers
        var data_els = this.$task_data.childNodes;
        for (var i = 0, len = data_els.length; i < len; i++) {
          var el = data_els[i];
          if (el.hasAttribute("data-layer") && el.style)
            el.style.width = scale.full_width + "px";
        }
      },

      isVisible: function () {
        if (this.$parent && this.$parent.$config) {
          return !this.$parent.$config.hidden;
        } else {
          return this.$task.offsetWidth;
        }
      },

      getSize: function () {
        var config = this.$getConfig();
        var store = this.$config.rowStore;

        var contentHeight = store ? config.row_height * store.countVisible() : 0,
          contentWidth = this.isVisible() ? this._tasks.full_width : 0;

        return {
          x: this.isVisible() ? this.$config.width : 0,
          y: this.isVisible() ? this.$config.height : 0,
          contentX: this.isVisible() ? contentWidth : 0,
          contentY: this.isVisible() ? (config.scale_height + contentHeight) : 0,
          scrollHeight: this.isVisible() ? contentHeight : 0,
          scrollWidth: this.isVisible() ? contentWidth : 0
        };
      },

      scrollTo: function (left, top) {
        if (!this.isVisible())
          return;

        var scrolled = false;

        this.$config.scrollTop = this.$config.scrollTop || 0;
        this.$config.scrollLeft = this.$config.scrollLeft || 0;
        if (top * 1 === top) {
          this.$config.scrollTop = top;
          this.$task_data.scrollTop = this.$config.scrollTop;
          scrolled = true;
        }
        if (left * 1 === left) {
          this.$task.scrollLeft = left;
          this.$config.scrollLeft = this.$task.scrollLeft;
          this._refreshScales();
          scrolled = true;
        }

        if (scrolled) {
          this.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
        }
      },

      _refreshScales: function _refreshScales() {
        if (!this.isVisible())
          return;

        var config = this.$getConfig();
        if (!config.smart_scales) return;

        var viewPort = this.getViewPort();

        var scales = this._scales;
        this.$task_scale.innerHTML = this._getScaleChunkHtml(scales, viewPort.x, viewPort.x_end);
      },

      getViewPort: function () {
        var scrollLeft = this.$config.scrollLeft || 0;
        var scrollTop = this.$config.scrollTop || 0;
        var height = this.$config.height || 0;
        var width = this.$config.width || 0;
        return {
          y: scrollTop,
          y_end: scrollTop + height,
          x: scrollLeft,
          x_end: scrollLeft + width,
          height: height,
          width: width
        };
      },

      _createLayerConfig: function () {
        var self = this;
        var taskFilter = function () {
          return self.isVisible();
        };

        var taskLayers = [
          {
            expose: true,
            renderer: this.$gantt.$ui.layers.taskBar(),
            container: this.$task_bars,
            filter: [taskFilter]
          },
          {
            renderer: this.$gantt.$ui.layers.taskSplitBar(),
            filter: [taskFilter],
            container: this.$task_bars,
            append: true
          },
          {
            renderer: this.$gantt.$ui.layers.taskBg(),
            container: this.$task_bg,
            filter: [
              //function(){
              //	return !self.$getConfig().static_background;
              //},
              taskFilter
            ]
          }
        ];

        var linkLayers = [
          {
            expose: true,
            renderer: this.$gantt.$ui.layers.link(),
            container: this.$task_links,
            filter: [taskFilter]
          }
        ];

        return {
          tasks: taskLayers,
          links: linkLayers
        };

      },

      _attachLayers: function (gantt) {
        this._taskLayers = [];
        this._linkLayers = [];

        var self = this;
        var getViewPort = function () {
          return self.getViewPort();
        };
        var layers = this.$gantt.$services.getService("layers");

        function subscribeSmartRender(layer) {
          self.attachEvent("onScroll", function () {
            if (layer.requestUpdate) {
              layer.requestUpdate();
            }
          });
        }

        if (this.$config.bind) {

          this._bindStore();
          var taskRenderer = layers.getDataRender(this.$config.bind);

          if (!taskRenderer) {
            taskRenderer = layers.createDataRender({
              name: this.$config.bind,
              defaultContainer: function () { return self.$task_data; }
            });
          }

          taskRenderer.container = function () { return self.$task_data; };

          var taskLayers = this.$config.layers;
          for (var i = 0; taskLayers && i < taskLayers.length; i++) {
            var layer = taskLayers[i];

            if (typeof layer == "string") {
              layer = this.$gantt.$ui.layers[layer]();
            }

            if (typeof layer == "function" || (layer && layer.render && layer.update)) {
              layer = { renderer: layer };
            }

            layer.host = this;
            if (!layer.viewPort) {
              var self = this;
              layer.getViewPort = function () {
                if (!self.getViewPort) {
                  return null;
                }
                return self.getViewPort();
              };
            }

            layer.getViewPort = getViewPort;
            subscribeSmartRender(layer);
            var bar_layer = taskRenderer.addLayer(layer);
            this._taskLayers.push(bar_layer);
            if (layer.expose) {
              this._taskRenderer = taskRenderer.getLayer(bar_layer);
            }
          }

          this._initStaticBackgroundRender();
        }

        if (this.$config.bindLinks) {
          self.$config.linkStore = self.$gantt.getDatastore(self.$config.bindLinks);

          var linkRenderer = layers.getDataRender(this.$config.bindLinks);

          if (!linkRenderer) {
            linkRenderer = layers.createDataRender({
              name: this.$config.bindLinks,
              defaultContainer: function () { return self.$task_data; }
            });
          }
          var linkLayers = this.$config.linkLayers;
          for (var i = 0; linkLayers && i < linkLayers.length; i++) {

            if (typeof layer == "string") {
              layer = this.$gantt.$ui.layers[layer]();
            }

            var layer = linkLayers[i];
            layer.host = this;
            layer.getViewPort = getViewPort;
            subscribeSmartRender(layer);
            var linkLayer = linkRenderer.addLayer(layer);
            this._taskLayers.push(linkLayer);
            if (linkLayers[i].expose) {
              this._linkRenderer = linkRenderer.getLayer(linkLayer);
            }
          }
        }
      },

      _initStaticBackgroundRender: function () {
        var self = this;
        var staticRender = canvasRender.create();
        var store = self.$config.rowStore;
        if (!store) return;

        this._staticBgHandler = store.attachEvent("onStoreUpdated", function (id, item, mode) {
          if (id !== null) {
            return;
          }

          if (!self.isVisible())
            return;
          var config = self.$getConfig();
          if (config.static_background) {
            var store = self.$gantt.getDatastore(self.$config.bind);
            var staticBgContainer = self.$task_bg_static;
            if (!staticBgContainer) {
              staticBgContainer = document.createElement("div");
              staticBgContainer.className = "gantt_task_bg";
              self.$task_bg_static = staticBgContainer;
              if (self.$task_bg.nextSibling) {
                self.$task_data.insertBefore(staticBgContainer, self.$task_bg.nextSibling);
              } else {
                self.$task_data.appendChild(staticBgContainer);
              }
            }
            if (store) {
              staticRender.render(staticBgContainer, config, self.getScale(), config.row_height * store.countVisible());
            }
          } else if (config.static_background) {
            if (self.$task_bg_static && self.$task_bg_static.parentNode) {
              self.$task_bg_static.parentNode.removeChild(self.$task_bg_static);
            }
          }
        });
        this.attachEvent("onDestroy", function () {
          staticRender.destroy();
        });
        this._initStaticBackgroundRender = function () { };//init once
      },

      _clearLayers: function (gantt) {
        var layers = this.$gantt.$services.getService("layers");
        var taskRenderer = layers.getDataRender(this.$config.bind);
        var linkRenderer = layers.getDataRender(this.$config.bindLinks);

        if (this._taskLayers) {
          for (var i = 0; i < this._taskLayers.length; i++) {
            taskRenderer.removeLayer(this._taskLayers[i]);
          }
        }
        if (this._linkLayers) {
          for (var i = 0; i < this._linkLayers.length; i++) {
            linkRenderer.removeLayer(this._linkLayers[i]);
          }
        }

        this._linkLayers = [];
        this._taskLayers = [];
      },

      _render_tasks_scales: function _render_tasks_scales() {
        var config = this.$getConfig();

        var scales_html = "",
          outer_width: any = 0,
          scale_height: any = 0;

        var state = this.$gantt.getState();

        if (this.isVisible()) {
          var helpers = this.$scaleHelper;
          var scales = this._getScales();
          scale_height = config.scale_height;

          var availWidth = this.$config.width;
          if (config.autosize == "x" || config.autosize == "xy") {
            availWidth = Math.max(config.autosize_min_width, 0);
          }

          var cfgs = helpers.prepareConfigs(scales, config.min_column_width, availWidth, scale_height - 1, state.min_date, state.max_date, config.rtl);
          var cfg = this._tasks = cfgs[cfgs.length - 1];
          this._scales = cfgs;
          this._posFromDateCache = {};

          scales_html = this._getScaleChunkHtml(cfgs, 0, this.$config.width);

          outer_width = cfg.full_width + "px";//cfg.full_width + (this._scroll_sizes().y ? scrollSizes.scroll_size : 0) + "px";
          scale_height += "px";
        }

        this.$task_scale.style.height = scale_height;

        this.$task_data.style.width =
          this.$task_scale.style.width = outer_width;

        this.$task_scale.innerHTML = scales_html;

      },

      _getScaleChunkHtml: function _get_scale_chunk_html(scales, fromPos, toPos) {
        var templates = this.$gantt.$services.templates();
        var html = [];

        var css = templates.scale_row_class;
        for (var i = 0; i < scales.length; i++) {
          var cssClass = "gantt_scale_line";
          var tplClass = css(scales[i]);
          if (tplClass) {
            cssClass += " " + tplClass;
          }

          html.push("<div class=\"" + cssClass + "\" style=\"height:" + (scales[i].height) +
            "px;position:relative;line-height:" + (scales[i].height) + "px\">" + this._prepareScaleHtml(scales[i], fromPos, toPos) + "</div>");
        }

        return html.join("");
      },
      _prepareScaleHtml: function _prepare_scale_html(config, fromPos, toPos) {
        var globalConfig = this.$getConfig();
        var globalTemplates = this.$gantt.$services.templates();

        var cells = [];
        var date = null, css = null;

        var content = config.format || config.template || config.date;

        if (typeof content === "string") {
          content = this.$gantt.date.date_to_str(content);
        }

        var startIndex = 0,
          endIndex = config.count;

        if (globalConfig.smart_scales && (!isNaN(fromPos) && !isNaN(toPos))) {
          startIndex = _findBinary(config.left, fromPos);
          endIndex = _findBinary(config.left, toPos) + 1;
        }

        css = config.css || function () {
        };
        if (!config.css && globalConfig.inherit_scale_class) {
          css = globalTemplates.scale_cell_class;
        }

        for (var i = startIndex; i < endIndex; i++) {
          if (!config.trace_x[i]) break;

          date = new Date(config.trace_x[i]);
          var value = content.call(this, date),
            width = config.width[i],
            height = config.height,
            left = config.left[i],
            style = "",
            template = "",
            cssclass = "";

          if (width) {
            var position = globalConfig.smart_scales ? ("position:absolute;left:" + left + "px") : "";

            style = "width:" + (width) + "px;height:" + height + "px;" + position;
            cssclass = "gantt_scale_cell" + (i == config.count - 1 ? " gantt_last_cell" : "");

            template = css.call(this, date);
            if (template) cssclass += " " + template;

            var ariaAttr = this.$gantt._waiAria.getTimelineCellAttr(value);
            var cell = "<div class='" + cssclass + "'" + ariaAttr + " style='" + style + "'>" + value + "</div>";
            cells.push(cell);
          } else {
            //do not render ignored cells
          }

        }
        return cells.join("");
      },
      dateFromPos: function dateFromPos(x) {
        var scale = this._tasks;
        if (x < 0 || x > scale.full_width || !scale.full_width) {
          return null;
        }

        var ind = _findBinary(this._tasks.left, x);
        var summ = this._tasks.left[ind];

        var col_width = scale.width[ind] || scale.col_width;
        var part = 0;
        if (col_width) {
          part = (x - summ) / col_width;
          if (scale.rtl) {
            part = 1 - part;
          }

        }

        var unit = 0;
        if (part) {
          unit = this._getColumnDuration(scale, scale.trace_x[ind]);
        }

        var date = new Date(scale.trace_x[ind].valueOf() + Math.round(part * unit));
        return date;
      },
      posFromDate: function posFromDate(date) {
        if (!this.isVisible())
          return 0;

        if (!date) {
          return 0;
        }

        var dateValue = String(date.valueOf());

        if (this._posFromDateCache[dateValue] !== undefined) {
          return this._posFromDateCache[dateValue];
        }
        var ind = this.columnIndexByDate(date);
        this.$gantt.assert(ind >= 0, "Invalid day index");

        var wholeCells = Math.floor(ind);
        var partCell = ind % 1;

        var pos = this._tasks.left[Math.min(wholeCells, this._tasks.width.length - 1)];
        if (wholeCells == this._tasks.width.length)
          pos += this._tasks.width[this._tasks.width.length - 1];
        //for(var i=1; i <= wholeCells; i++)
        //	pos += gantt._tasks.width[i-1];

        if (partCell) {
          if (wholeCells < this._tasks.width.length) {
            pos += this._tasks.width[wholeCells] * (partCell % 1);
          } else {
            pos += 1;
          }

        }

        var roundPos = Math.round(pos);
        this._posFromDateCache[dateValue] = roundPos;
        return Math.round(roundPos);
      },

      _getNextVisibleColumn: function (startIndex, columns, ignores) {
        // iterate columns to the right
        var date = +columns[startIndex];
        var visibleDateIndex = startIndex;
        while (ignores[date]) {
          visibleDateIndex++;
          date = +columns[visibleDateIndex];
        }

        return visibleDateIndex;
      },
      _getPrevVisibleColumn: function (startIndex, columns, ignores) {
        // iterate columns to the left
        var date = +columns[startIndex];
        var visibleDateIndex = startIndex;
        while (ignores[date]) {
          visibleDateIndex--;
          date = +columns[visibleDateIndex];
        }
        return visibleDateIndex;
      },
      _getClosestVisibleColumn: function (startIndex, columns, ignores) {
        var visibleDateIndex = this._getNextVisibleColumn(startIndex, columns, ignores);
        if (!columns[visibleDateIndex]) {
          visibleDateIndex = this._getPrevVisibleColumn(startIndex, columns, ignores);
        }
        return visibleDateIndex;
      },
      columnIndexByDate: function columnIndexByDate(date) {
        var pos = new Date(date).valueOf();
        var days = this._tasks.trace_x_ascending,
          ignores = this._tasks.ignore_x;

        var state = this.$gantt.getState();

        if (pos <= state.min_date) {
          if (this._tasks.rtl) {
            return days.length;
          } else {
            return 0;
          }

        }

        if (pos >= state.max_date) {
          if (this._tasks.rtl) {
            return 0;
          } else {
            return days.length;
          }
        }

        var dateIndex = _findBinary(days, pos);

        var visibleIndex = this._getClosestVisibleColumn(dateIndex, days, ignores);
        var visibleDate = days[visibleIndex];
        var transition = this._tasks.trace_index_transition;

        if (!visibleDate) {
          if (transition) {
            return transition[0];
          } else {
            return 0;
          }
        }

        var part = ((date - days[visibleIndex]) / this._getColumnDuration(this._tasks, days[visibleIndex]));
        if (transition) {
          return transition[visibleIndex] + (1 - part);
        } else {
          return visibleIndex + part;
        }
      },
      getItemPosition: function (task, start_date, end_date) {
        var xLeft, xRight, width;
        if (this._tasks.rtl) {
          xRight = this.posFromDate(start_date || task.start_date);
          xLeft = this.posFromDate(end_date || task.end_date);
        } else {
          xLeft = this.posFromDate(start_date || task.start_date);
          xRight = this.posFromDate(end_date || task.end_date);
        }
        width = Math.max((xRight - xLeft), 0);

        var y = this.getItemTop(task.id);
        var height = this.getItemHeight();
        return {
          left: xLeft,
          top: y,
          height: height,
          width: width
        };
      },

      getItemHeight: function () {
        var config = this.$getConfig();

        // height of the bar item
        var height = config.task_height;

        if (height == "full") {
          var offset = config.task_height_offset || 5;
          height = config.row_height - offset;
        }
        //item height cannot be bigger than row height
        height = Math.min(height, config.row_height);
        return Math.max(height, 0);
      },

      getScale: function () {
        return this._tasks;
      },

      _getScales: function _get_scales() {
        var config = this.$getConfig();
        var helpers = this.$scaleHelper;
        var scales = [helpers.primaryScale(config)].concat(helpers.getSubScales(config));

        helpers.sortScales(scales);
        return scales;
      },

      _getColumnDuration: function _get_coll_duration(scale, date) {
        return this.$gantt.date.add(date, scale.step, scale.unit) - date;
      },
      _bindStore: function () {
        if (this.$config.bind) {
          var rowStore = this.$gantt.getDatastore(this.$config.bind);
          this.$config.rowStore = rowStore;
          if (rowStore && !rowStore._timelineCacheAttached) {
            var self = this;
            rowStore._timelineCacheAttached = true;
            rowStore.attachEvent("onBeforeFilter", function () {
              self._resetTopPositionHeight();
            });
          }
        }
      },
      refresh: function () {
        this._bindStore();

        if (this.$config.bindLinks) {
          this.$config.linkStore = this.$gantt.getDatastore(this.$config.bindLinks);
        }

        this._resetTopPositionHeight();
        this._initStaticBackgroundRender();
        this._render_tasks_scales();
      },

      destructor: function () {
        var gantt = this.$gantt;
        this._clearLayers(gantt);

        this.$task = null;
        this.$task_scale = null;
        this.$task_data = null;
        this.$task_bg = null;
        this.$task_links = null;
        this.$task_bars = null;

        this.$gantt = null;

        if (this.$config.rowStore) {
          this.$config.rowStore.detachEvent(this._staticBgHandler);
          this.$config.rowStore = null;
        }
        if (this.$config.linkStore) {
          this.$config.linkStore = null;
        }

        this.callEvent("onDestroy", []);
        this.detachAllEvents();

      }
    };

    return Timeline;

    function _findBinary(array, target) {
      // modified binary search, target value not exactly match array elements, looking for closest one

      var low = 0, high = array.length - 1, i, item, prev;
      while (low <= high) {

        i = Math.floor((low + high) / 2);
        item = +array[i];
        prev = +array[i - 1];
        if (item < target) {
          low = i + 1;
          continue;
        }
        if (item > target) {
          if (!(!isNaN(prev) && prev < target)) {
            high = i - 1;
            continue;
          } else {
            // if target is between 'i' and 'i-1' return 'i - 1'
            return i - 1;
          }

        }
        while (+array[i] == +array[i + 1]) i++;

        return i;
      }
      return array.length - 1;
    }

  }

  gridResizeJs = function () {

    function createResizer(gantt, grid) {
      return {
        init: function () { },
        doOnRender: function () { }
      };
    }

    return createResizer;

  }

  mouseDelegatesJs = function () {

    function create(gantt) {
      var events = [];

      return {
        delegate: function (event, className, handler, root) {
          events.push([event, className, handler, root]);

          var helper = gantt.$services.getService("mouseEvents");
          helper.delegate(event, className, handler, root);
        },
        destructor: function () {
          var mouseEvents = gantt.$services.getService("mouseEvents");
          for (var i = 0; i < events.length; i++) {
            var h = events[i];
            mouseEvents.detach(h[0], h[1], h[2], h[3]);
          }
          events = [];
        }
      };
    }

    return create;

  }

  gridJs = function () {

    var domHelpers = this.helperService,
      utils = this.helperService,
      eventable = this.eventableService,
      gridResize = this.gridResizeJs,
      topPositionMixin = this.topPostionMixinJs;

    var Grid = function (parent, config, factory, gantt) {
      this.$config = utils.mixin({}, config || {});
      this.$gantt = gantt;
      this.$parent = parent;
      eventable(this);
      this.$state = {};
      utils.mixin(this, topPositionMixin());
    };


    Grid.prototype = {
      init: function (container) {
        var gantt = this.$gantt;
        var gridAriaAttr = gantt._waiAria.gridAttrString();
        var gridDataAriaAttr = gantt._waiAria.gridDataAttrString();


        container.innerHTML = "<div class='gantt_grid' style='height:inherit;width:inherit;' " + gridAriaAttr + "></div>";
        this.$grid = container.childNodes[0];

        this.$grid.innerHTML = "<div class='gantt_grid_scale' " +
          gantt._waiAria.gridScaleRowAttrString() + "></div><div class='gantt_grid_data' " + gridDataAriaAttr + "></div>";

        this.$grid_scale = this.$grid.childNodes[0];
        this.$grid_data = this.$grid.childNodes[1];

        var attr = this.$getConfig()[this.$config.bind + "_attribute"];
        if (!attr && this.$config.bind) {
          attr = this.$config.bind + "_id";
        }
        this.$config.item_attribute = attr || null;

        if (!this.$config.layers) {
          var layers = this._createLayerConfig();
          this.$config.layers = layers;
        }

        var resizer = gridResize(gantt, this);
        resizer.init();
        this._renderHeaderResizers = resizer.doOnRender;
        this._mouseDelegates = this.mouseDelegatesJs(gantt);

        this._addLayers(this.$gantt);
        this._initEvents();
        this.callEvent("onReady", []);
        //this.refresh();
      },

      _validateColumnWidth: function (column, property) {
        // user can set {name:"text", width:"200",...} for some reason,
        // check and convert it to number when possible
        var value = column[property];
        if (value && value != "*") {
          var gantt = this.$gantt;
          var numericWidth = value * 1;
          if (isNaN(numericWidth)) {
            gantt.assert(false, "Wrong " + property + " value of column " + column.name);
          } else {
            column[property] = numericWidth;
          }
        }
      },

      setSize: function (width, height) {
        this.$config.width = this.$state.width = width;
        this.$config.height = this.$state.height = height;

        // TODO: maybe inherit and override in a subclass instead of extending here

        var columns = this.getGridColumns(),
          innerWidth = 0;

        for (var i = 0, l = columns.length; i < l; i++) {
          this._validateColumnWidth(columns[i], "min_width");
          this._validateColumnWidth(columns[i], "max_width");
          this._validateColumnWidth(columns[i], "width");

          innerWidth += columns[i].width * 1;
        }

        var outerWidth;
        if (isNaN(innerWidth) || !this.$config.scrollable) {
          outerWidth = this._setColumnsWidth(width + 1);
          innerWidth = outerWidth;
        }

        if (this.$config.scrollable) {
          this.$grid_scale.style.width = innerWidth + "px";
          this.$grid_data.style.width = innerWidth + "px";
        } else {
          this.$grid_scale.style.width = "inherit";
          this.$grid_data.style.width = "inherit";
        }
        this.$config.width -= 1;

        var config = this.$getConfig();
        if (outerWidth !== width) {
          config.grid_width = outerWidth;
          this.$config.width = outerWidth - 1;
        }

        var dataHeight = Math.max(this.$state.height - config.scale_height, 0);
        this.$grid_data.style.height = dataHeight + "px";
        this.refresh();
      },
      getSize: function () {

        var config = this.$getConfig();

        var store = this.$config.rowStore;

        var contentHeight = store ? config.row_height * store.countVisible() : 0,
          contentWidth = this._getGridWidth();

        var size = {
          x: this.$state.width,
          y: this.$state.height,
          contentX: this.isVisible() ? contentWidth : 0,
          contentY: this.isVisible() ? (config.scale_height + contentHeight) : 0,
          scrollHeight: this.isVisible() ? contentHeight : 0,
          scrollWidth: this.isVisible() ? contentWidth : 0
        };

        return size;
      },

      _bindStore: function () {
        if (this.$config.bind) {
          var rowStore = this.$gantt.getDatastore(this.$config.bind);
          this.$config.rowStore = rowStore;
          if (rowStore && !rowStore._gridCacheAttached) {
            var self = this;
            rowStore._gridCacheAttached = true;
            rowStore.attachEvent("onBeforeFilter", function () {
              self._resetTopPositionHeight();
            });
          }
        }
      },

      refresh: function () {
        this._bindStore();

        this._resetTopPositionHeight();
        this._initSmartRenderingPlaceholder();

        this._calculateGridWidth();
        this._renderGridHeader();
      },

      getViewPort: function () {
        var scrollLeft = this.$config.scrollLeft || 0;
        var scrollTop = this.$config.scrollTop || 0;
        var height = this.$config.height || 0;
        var width = this.$config.width || 0;
        return {
          y: scrollTop,
          y_end: scrollTop + height,
          x: scrollLeft,
          x_end: scrollLeft + width,
          height: height,
          width: width
        };
      },

      scrollTo: function (left, top) {
        if (!this.isVisible())
          return;

        var scrolled = false;

        this.$config.scrollTop = this.$config.scrollTop || 0;
        this.$config.scrollLeft = this.$config.scrollLeft || 0;

        if (left * 1 == left) {
          this.$config.scrollLeft = this.$state.scrollLeft = this.$grid.scrollLeft = left;
          scrolled = true;
        }

        // var config = this.$getConfig();
        if (top * 1 == top) {
          this.$config.scrollTop = this.$state.scrollTop = this.$grid_data.scrollTop = top;
          scrolled = true;
        }

        if (scrolled) {
          this.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
        }
      },

      getColumnIndex: function (name) {
        var columns = this.$getConfig().columns;

        for (var i = 0; i < columns.length; i++) {
          if (columns[i].name == name) {
            return i;
          }
        }
        return null;
      },

      getColumn: function (name) {
        var index = this.getColumnIndex(name);
        if (index === null) {
          return null;
        }
        return this.$getConfig().columns[index];
      },

      getGridColumns: function () {
        var config = this.$getConfig();
        return config.columns.slice();
      },
      isVisible: function () {
        if (this.$parent && this.$parent.$config) {
          return !this.$parent.$config.hidden;
        } else {
          return this.$grid.offsetWidth;
        }
      },

      getItemHeight: function () {
        var config = this.$getConfig();
        return config.row_height;
      },

      _createLayerConfig: function () {
        var gantt = this.$gantt;
        var self = this;
        var layers = [
          {
            renderer: gantt.$ui.layers.gridLine(),
            container: this.$grid_data,
            filter: [function () {
              return self.isVisible();
            }]
          }
        ];
        return layers;
      },

      _addLayers: function (gantt) {
        if (!this.$config.bind)
          return;

        this._taskLayers = [];

        var self = this;

        var layers = this.$gantt.$services.getService("layers");
        var taskRenderer = layers.getDataRender(this.$config.bind);
        var getViewPort = function () {
          return self.getViewPort();
        };
        if (!taskRenderer) {
          taskRenderer = layers.createDataRender({
            name: this.$config.bind,
            defaultContainer: function () { return self.$grid_data; }
          });
        }

        var taskLayers = this.$config.layers;
        for (var i = 0; taskLayers && i < taskLayers.length; i++) {
          var layer = taskLayers[i];
          layer.host = this;
          layer.getViewPort = getViewPort;
          var bar_layer = taskRenderer.addLayer(layer);
          this._taskLayers.push(bar_layer);
          this.attachEvent("onScroll", (function (layer) {
            return function () {
              if (layer.requestUpdate) {
                layer.requestUpdate();
              }
            };
          })(layer));
        }

        this._bindStore();

        this._initSmartRenderingPlaceholder();
      },

      _refreshPlaceholderOnStoreUpdate: function (id) {
        var config = this.$getConfig(),
          store = this.$config.rowStore;

        if (!store || id !== null || !this.isVisible() || !config.smart_rendering) {
          return;
        }

        var contentHeight;
        if (this.$config.scrollY) {
          var scroll = this.$gantt.$ui.getView(this.$config.scrollY);
          if (scroll)
            contentHeight = scroll.getScrollState().scrollSize;
        }

        if (!contentHeight) {
          contentHeight = store ? config.row_height * store.countVisible() : 0;
        }

        if (contentHeight) {
          if (this.$rowsPlaceholder && this.$rowsPlaceholder.parentNode) {
            this.$rowsPlaceholder.parentNode.removeChild(this.$rowsPlaceholder);
          }

          var placeholder = this.$rowsPlaceholder = document.createElement("div");
          placeholder.style.visibility = "hidden";
          placeholder.style.height = contentHeight + "px";
          placeholder.style.width = "1px";
          this.$grid_data.appendChild(placeholder);
        }
      },

      _initSmartRenderingPlaceholder: function () {
        var store = this.$config.rowStore;
        if (!store) {
          return;
        } else {
          this._initSmartRenderingPlaceholder = function () { };
        }
        this._staticBgHandler = store.attachEvent("onStoreUpdated", utils.bind(this._refreshPlaceholderOnStoreUpdate, this));
      },

      _initEvents: function () {
        var gantt = this.$gantt;
        this._mouseDelegates.delegate("click", "gantt_close", gantt.bind(function (e, id, trg) {
          var store = this.$config.rowStore;
          if (!store) return true;

          var target = domHelpers.locateAttribute(e, this.$config.item_attribute);
          if (target) {
            store.close(target.getAttribute(this.$config.item_attribute));

          }
          return false;
        }, this), this.$grid);

        this._mouseDelegates.delegate("click", "gantt_open", gantt.bind(function (e, id, trg) {
          var store = this.$config.rowStore;
          if (!store) return true;

          var target = domHelpers.locateAttribute(e, this.$config.item_attribute);
          if (target) {
            store.open(target.getAttribute(this.$config.item_attribute));

          }
          return false;
        }, this), this.$grid);
      },

      _clearLayers: function (gantt) {
        var layers = this.$gantt.$services.getService("layers");
        var taskRenderer = layers.getDataRender(this.$config.bind);

        if (this._taskLayers) {
          for (var i = 0; i < this._taskLayers.length; i++) {
            taskRenderer.removeLayer(this._taskLayers[i]);
          }
        }

        this._taskLayers = [];
      },

      _getColumnWidth: function (column, config, width) {
        var min_width = column.min_width || config.min_grid_column_width;
        var new_width = Math.max(width, min_width || 10);
        if (column.max_width)
          new_width = Math.min(new_width, column.max_width);
        return new_width;
      },
      // return min and max possible grid width according to restricts
      _getGridWidthLimits: function () {
        var config = this.$getConfig(),
          columns = this.getGridColumns(),
          min_limit = 0,
          max_limit = 0;

        for (var i = 0; i < columns.length; i++) {
          min_limit += columns[i].min_width ? columns[i].min_width : config.min_grid_column_width;
          if (max_limit !== undefined) {
            max_limit = columns[i].max_width ? (max_limit + columns[i].max_width) : undefined;
          }
        }

        return [min_limit, max_limit];
      },
      // resize columns to get total newWidth, starting from columns[start_index]
      _setColumnsWidth: function (newWidth, start_index) {
        var config = this.$getConfig();
        var columns = this.getGridColumns(),
          columns_width = 0,
          final_width = newWidth;
        // start_index = !window.isNaN(start_index) ? start_index : -1;
        start_index = start_index ? start_index : -1;


        for (var i = 0, l = columns.length; i < l; i++) {
          columns_width += columns[i].width * 1;
        }

        // if (window.isNaN(columns_width)) {
        //   this._calculateGridWidth();
        //   columns_width = 0;
        //   for (var i = 0, l = columns.length; i < l; i++) {
        //     columns_width += columns[i].width * 1;
        //   }
        // }

        var extra_width = final_width - columns_width;

        var start_width = 0;
        for (var i = 0; i < start_index + 1; i++) {
          start_width += columns[i].width;
        }

        columns_width -= start_width;

        for (let i = start_index + 1; i < columns.length; i++) {

          var col = columns[i];
          var share = Math.round(extra_width * (col.width / columns_width));

          // columns have 2 additional restrict fields - min_width & max_width that are set by user
          if (extra_width < 0) {
            if (col.min_width && col.width + share < col.min_width)
              share = col.min_width - col.width;
            else if (!col.min_width && config.min_grid_column_width && col.width + share < config.min_grid_column_width)
              share = config.min_grid_column_width - col.width;
          } else if (col.max_width && col.width + share > col.max_width)
            share = col.max_width - col.width;

          columns_width -= col.width;
          col.width += share;
          extra_width -= share;

        }

        var iterator = extra_width > 0 ? 1 : -1;
        while ((extra_width > 0 && iterator === 1) || (extra_width < 0 && iterator === -1)) {
          var curExtra = extra_width;
          for (i = start_index + 1; i < columns.length; i++) {
            var new_width = columns[i].width + iterator;

            if (new_width == this._getColumnWidth(columns[i], config, new_width)) {
              extra_width -= iterator;
              columns[i].width = new_width;
            }

            if (!extra_width)
              break;

          }

          if (curExtra == extra_width)
            break;
        }

        // if impossible to resize the right-side columns, resize the start column
        if (extra_width && start_index > -1) {
          var new_width = columns[start_index].width + extra_width;
          if (new_width == this._getColumnWidth(columns[start_index], config, new_width))
            columns[start_index].width = new_width;
        }

        //if (this.callEvent("onGridResizeEnd", [config.grid_width, final_width]) === false)
        //	return;

        return this._getColsTotalWidth();
      },

      _getColsTotalWidth: function () {
        var columns = this.getGridColumns();
        var cols_width = 0;

        for (var i = 0; i < columns.length; i++) {
          var v = parseFloat(columns[i].width);
          // if (WinisNaN(v)) {
          //   return false;
          // }
          cols_width += v;
        }
        return cols_width;
      },
      _calculateGridWidth: function () {
        var config = this.$getConfig();
        var columns = this.getGridColumns();
        var cols_width = 0;
        var unknown = [];
        var width = [];

        for (var i = 0; i < columns.length; i++) {
          var v = parseFloat(columns[i].width);
          // if (window.isNaN(v)) {
          //   v = config.min_grid_column_width || 10;
          //   unknown.push(i);
          // }
          width[i] = v;
          cols_width += v;
        }
        var gridWidth = this._getGridWidth() + 1;
        if (config.autofit || unknown.length) {
          var diff = gridWidth - cols_width;
          // TODO: logic may be improved for proportional changing of width
          if (config.autofit) {
            // delta must be added for all columns
            for (var i = 0; i < width.length; i++) {
              var delta = Math.round(diff / (width.length - i));
              width[i] += delta;
              var new_width = this._getColumnWidth(columns[i], config, width[i]);

              if (new_width != width[i]) {
                delta = new_width - width[i];
                width[i] = new_width;
              }
              diff -= delta;
            }
          } else if (unknown.length) {
            // there are several columns with undefined width
            for (var i = 0; i < unknown.length; i++) {
              var delta = Math.round(diff / (unknown.length - i)); // no float values, just integer
              var index = unknown[i];
              width[index] += delta;
              var new_width = this._getColumnWidth(columns[index], config, width[index]);
              if (new_width != width[index]) {
                delta = new_width - width[index];
                width[index] = new_width;
              }
              diff -= delta;
            }
          }

          for (var i = 0; i < width.length; i++) {
            columns[i].width = width[i];
          }
        } else {
          var changed = (gridWidth != cols_width);
          this.$config.width = cols_width - 1;
          config.grid_width = cols_width;
          if (changed) {
            this.$parent._setContentSize(this.$config.width, this.$config.height);
            //				this.$parent.$config.width = cols_width;
          }
        }

      },

      _renderGridHeader: function () {
        var gantt = this.$gantt;
        var config = this.$getConfig();
        var locale = this.$gantt.locale;
        var templates = this.$gantt.templates;

        var columns = this.getGridColumns();
        if (config.rtl) {
          columns = columns.reverse();
        }
        var cells = [];
        var width = 0,
          labels = locale.labels;

        var lineHeigth = config.scale_height - 1;

        for (var i = 0; i < columns.length; i++) {
          var last = i == columns.length - 1;
          var col = columns[i];

          // ensure columns have non-empty names
          if (!col.name) {
            col.name = gantt.uid() + "";
          }

          var colWidth = col.width * 1;

          var gridWidth = this._getGridWidth();
          if (last && gridWidth > width + colWidth)
            col.width = colWidth = gridWidth - width;
          width += colWidth;
          var sort = (gantt._sort && col.name == gantt._sort.name) ? ("<div class='gantt_sort gantt_" + gantt._sort.direction + "'></div>") : "";
          var cssClass = ["gantt_grid_head_cell",
            ("gantt_grid_head_" + col.name),
            (last ? "gantt_last_cell" : ""),
            templates.grid_header_class(col.name, col)].join(" ");

          var style = "width:" + (colWidth - (last ? 1 : 0)) + "px;";
          var label = (col.label || labels["column_" + col.name] || labels[col.name]);
          label = label || "";

          var ariaAttrs = gantt._waiAria.gridScaleCellAttrString(col, label);

          var cell = "<div class='" + cssClass + "' style='" + style + "' " + ariaAttrs + " data-column-id='" + col.name + "' column_id='" + col.name + "'>" + label + sort + "</div>";
          cells.push(cell);
        }
        this.$grid_scale.style.height = (config.scale_height) + "px";
        this.$grid_scale.style.lineHeight = lineHeigth + "px";
        //this.$grid_scale.style.width = "inherit";
        this.$grid_scale.innerHTML = cells.join("");

        if (this._renderHeaderResizers) {
          this._renderHeaderResizers();
        }
      },

      _getGridWidth: function () {
        // TODO: refactor/remove/comment some of _getGridWidth/this.$config.width/this.$state.width, it's not clear what they do
        return this.$config.width;
      },

      destructor: function () {
        this._clearLayers(this.$gantt);
        if (this._mouseDelegates) {
          this._mouseDelegates.destructor();
          this._mouseDelegates = null;
        }
        this.$grid = null;
        this.$grid_scale = null;
        this.$grid_data = null;
        this.$gantt = null;

        if (this.$config.rowStore) {
          this.$config.rowStore.detachEvent(this._staticBgHandler);
          this.$config.rowStore = null;
        }

        this.callEvent("onDestroy", []);
        this.detachAllEvents();
      }
    };

    return Grid;
  }

  defaultMappingJs = function () {

    return {
      init: function (controller, grid) {
        var gantt = grid.$gantt;

        gantt.attachEvent("onTaskClick", function (id, e) {
          if (gantt._is_icon_open_click(e))
            return true;
          var state = controller.getState();
          var cell = controller.locateCell(e.target);

          if (cell && controller.getEditorConfig(cell.columnName)) {
            if (controller.isVisible() && state.id == cell.id && state.columnName == cell.columnName) {
              // do nothing if editor is already active in this cell
            } else {
              controller.startEdit(cell.id, cell.columnName);
            }
            return false;
          }
          return true;
        });

        gantt.attachEvent("onEmptyClick", function () {
          if (controller.isVisible() && controller.isChanged()) {
            controller.save();
          } else {
            controller.hide();
          }
          return true;
        });

        gantt.attachEvent("onTaskDblClick", function (id, e) {
          var state = controller.getState();
          var cell = controller.locateCell(e.target);
          if (cell && controller.isVisible() && cell.columnName == state.columnName) {
            return false;
          }
          return true;
        });
      },

      onShow: function (controller, placeholder, grid) {
        if (grid.$getConfig().keyboard_navigation) {
          // keyboard navigation extension will handle arrows if enabled
          return;
        }
        var gantt = grid.$gantt;
        placeholder.onkeydown = function (e) {
          e = e || window.event;

          var keyboard = gantt.constants.KEY_CODES;
          if (e.defaultPrevented || (e.shiftKey && e.keyCode != keyboard.TAB)) {
            return;
          }

          var shouldPrevent = true;
          switch (e.keyCode) {
            case gantt.keys.edit_save:
              controller.save();
              break;
            case gantt.keys.edit_cancel:
              controller.hide();
              break;
            case keyboard.TAB:
              if (e.shiftKey) {
                controller.editPrevCell(true);
              } else {
                controller.editNextCell(true);
              }
              break;
            default:
              shouldPrevent = false;
              break;
          }

          if (shouldPrevent) {
            e.preventDefault();
          }
        };
      },
      onHide: function () {

      },

      destroy: function () {

      }
    };



  }

  keyNavMappingJs = function () {

    return {
      init: function (controller, grid) {
        var self = controller;
        var gantt = grid.$gantt;

        var onBlurDelay = null;
        var keyNav = gantt.ext.keyboardNavigation;
        keyNav.attachEvent("onBeforeFocus", function (node) {
          var activeCell = controller.locateCell(node);
          clearTimeout(onBlurDelay);
          if (activeCell) {
            var columnName = activeCell.columnName;
            var id = activeCell.id;

            var editorState = self.getState();
            if (self.isVisible()) {
              if (editorState.id == id && editorState.columnName === columnName) {
                return false;
              }
            }
          }
          return true;
        });

        keyNav.attachEvent("onFocus", function (node) {
          var activeCell = controller.locateCell(node);
          var state = controller.getState();
          clearTimeout(onBlurDelay);
          if (activeCell && !(activeCell.id == state.id && activeCell.columnName == state.columnName)) {
            if (self.isVisible()) {
              self.save();
            }
          }
          return true;
        });

        controller.attachEvent("onHide", function () {
          clearTimeout(onBlurDelay);
        });

        keyNav.attachEvent("onBlur", function () {
          onBlurDelay = setTimeout(function () {
            self.save();
          });

          return true;
        });

        gantt.attachEvent("onTaskDblClick", function (id, e) {
          // block lightbox on double click inside editor
          var state = controller.getState();
          var cell = controller.locateCell(e.target);
          if (cell && controller.isVisible() && cell.columnName == state.columnName) {
            return false;
          }
          return true;
        });

        gantt.attachEvent("onTaskClick", function (id, e) {
          if (gantt._is_icon_open_click(e))
            return true;

          var state = controller.getState();
          var cell = controller.locateCell(e.target);

          if (cell && controller.getEditorConfig(cell.columnName)) {
            if (controller.isVisible() && state.id == cell.id && state.columnName == cell.columnName) {
              // do nothing if editor is already active in this cell
            } else {
              controller.startEdit(cell.id, cell.columnName);
            }
            return false;
          }
          return true;
        });
        gantt.attachEvent("onEmptyClick", function () {
          self.save();
          return true;
        });

        keyNav.attachEvent("onKeyDown", function (command, e) {
          var activeCell = controller.locateCell(e.target);
          var hasEditor = activeCell ? controller.getEditorConfig(activeCell.columnName) : false;

          var state = controller.getState();
          var keyboard = gantt.constants.KEY_CODES;
          var keyCode = e.keyCode;
          var preventKeyNav = false;

          switch (keyCode) {
            case keyboard.ENTER:
              if (controller.isVisible()) {
                controller.save();
                e.preventDefault();
                preventKeyNav = true;
              } else if (hasEditor && !(e.ctrlKey || e.metaKey || e.shiftKey)) {
                self.startEdit(activeCell.id, activeCell.columnName);
                e.preventDefault();
                preventKeyNav = true;
              }
              break;
            case keyboard.ESC:
              if (controller.isVisible()) {
                controller.hide();
                e.preventDefault();
                preventKeyNav = true;
              }
              break;
            case keyboard.UP:
            case keyboard.DOWN:
              break;
            case keyboard.LEFT:
            case keyboard.RIGHT:
              if (state.editorType === "date") {
                preventKeyNav = true;
              }
              break;
            case keyboard.SPACE:
              if (controller.isVisible()) {
                preventKeyNav = true;
              }

              if (hasEditor && !controller.isVisible()) {
                self.startEdit(activeCell.id, activeCell.columnName);
                e.preventDefault();
                preventKeyNav = true;
              }
              break;
            case keyboard.DELETE:
              if (hasEditor && !controller.isVisible()) {
                self.startEdit(activeCell.id, activeCell.columnName);
                preventKeyNav = true;
              }
              break;
            case keyboard.TAB:
              if (controller.isVisible()) {

                if (e.shiftKey) {
                  controller.editPrevCell(true);
                } else {
                  controller.editNextCell(true);
                }
                var newState = controller.getState();
                if (newState.id) {
                  keyNav.focus({ type: "taskCell", id: newState.id, column: newState.columnName });
                }
                e.preventDefault();
                preventKeyNav = true;
              }
              break;
            default:
              if (controller.isVisible())
                preventKeyNav = true;
              else {

                // start editing on character key
                if ((keyCode >= 48 && keyCode <= 57) || // [0-9]
                  (keyCode > 95 && keyCode < 112) || // numpad
                  (keyCode >= 64 && keyCode <= 91) || // [a-z]
                  (keyCode > 185 && keyCode < 193) || //;=-,etc
                  (keyCode > 218 && keyCode < 223)
                ) {
                  var modifiers = command.modifiers;

                  var anyModifier = modifiers.alt || modifiers.ctrl || modifiers.meta || modifiers.shift;
                  if (modifiers.alt) {
                    // don't start editing on alt+key
                  } else if (anyModifier && keyNav.getCommandHandler(command, "taskCell")) {
                    // don't start editing if command already have a keyboard shortcut
                  } else if (hasEditor && !controller.isVisible()) {
                    self.startEdit(activeCell.id, activeCell.columnName);
                    preventKeyNav = true;
                  }
                }
              }

              break;
          }

          if (preventKeyNav) {
            return false;
          } else {
            return true;
          }

        });
      },
      onShow: function (controller, placeholder, grid) { },
      onHide: function (controller, placeholder, grid) {
        var gantt = grid.$gantt;
        gantt.focus();

      },
      destroy: function () { }
    };



    /***/
  }

  keyboardMappingJs = function () {

    var defaultMapping = this.defaultMappingJs;
    var keyNavMappings = this.keyNavMappingJs;

    return function (gantt) {

      var mapping = null;

      return {
        setMapping: function (map) {
          mapping = map;
        },
        getMapping: function () {

          if (mapping) {
            return mapping;
          } else if (gantt.config.keyboard_navigation_cells) {
            return keyNavMappings;
          } else {
            return defaultMapping;
          }
        }
      };
    };
  }

  baseEditorJs = function () {

    return function (gantt) {

      var BaseEditor = function () {
      };

      BaseEditor.prototype = {
        show: function (id, column, config, placeholder) {
        },
        hide: function () {
        },
        set_value: function (value, id, column, node) {
          this.get_input(node).value = value;
        },
        get_value: function (id, column, node) {
          return this.get_input(node).value || "";
        },
        is_changed: function (value, id, column, node) {
          var currentValue = this.get_value(id, column, node);
          if (currentValue && value && currentValue.valueOf && value.valueOf) {
            return currentValue.valueOf() != value.valueOf();
          } else {
            return currentValue != value;
          }
        },
        is_valid: function (value, id, column, node) {
          return true;
        },

        save: function (id, column, node) {

        },
        get_input: function (node) {
          return node.querySelector("input");
        },
        focus: function (node) {
          var input = this.get_input(node);
          if (!input) {
            return;
          }
          if (input.focus) {
            input.focus();
          }

          if (input.select) {
            input.select();
          }
        }
      };
      return BaseEditor;
    };

    /***/
  }

  textEditorFactoryJs = function () {

    return function (gantt) {

      var BaseEditor = this.baseEditorJs(gantt),
        utils = this.helperService.utils;
      var __extends = this.helperService.extends;

      function TextEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(TextEditor, BaseEditor);

      utils.mixin(TextEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><input type='text' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        }
      }, true);

      return TextEditor;
    };

    /***/
  }

  numberEditorFactoryJs = function () {

    return function (gantt) {

      var BaseEditor = this.baseEditorJs(gantt),
        utils = this.helperService.utils;
      var __extends = this.helperService.extends;

      function NumberEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(NumberEditor, BaseEditor);

      utils.mixin(NumberEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var min = config.min || 0,
            max = config.max || 100;

          var html = "<div><input type='number' min='" + min + "' max='" + max + "' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        get_value: function (id, column, node) {
          return this.get_input(node).value || "";
        },
        is_valid: function (value, id, column, node) {
          return !isNaN(parseInt(value, 10));
        }
      }, true);

      return NumberEditor;
    };

    /***/
  }

  selectEditorFactoryJs = function () {

    return function (gantt) {
      var BaseEditor = this.baseEditorJs(gantt),
        utils = this.helperService.utils;
      var __extends = this.helperService.extends;

      function SelectEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(SelectEditor, BaseEditor);

      utils.mixin(SelectEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><select name='" + column.name + "'>";
          var optionsHtml = [],
            options = config.options || [];

          for (var i = 0; i < options.length; i++) {
            optionsHtml.push("<option value='" + config.options[i].key + "'>" + options[i].label + "</option>");
          }

          html += optionsHtml.join("") + "</select></div>";
          placeholder.innerHTML = html;
        },
        get_input: function (node) {
          return node.querySelector("select");
        }
      }, true);

      return SelectEditor;
    };

    /***/
  }

  dateEditorFactoryJs = function () {

    return function (gantt) {
      var BaseEditor = this.baseEditorJs(gantt),
        utils = this.helperService.utils;
      var __extends = this.helperService.extends;

      var html5DateFormat = "%Y-%m-%d";

      var dateToStr = null;
      var strToDate = null;

      function init() {
        if (!dateToStr) {
          dateToStr = gantt.date.date_to_str(html5DateFormat);
        }
        if (!strToDate) {
          strToDate = gantt.date.str_to_date(html5DateFormat);
        }
      }

      function DateEditor() {
        var self = BaseEditor.apply(this, arguments) || this;

        return self;
      }

      __extends(DateEditor, BaseEditor);

      utils.mixin(DateEditor.prototype, {
        show: function (id, column, config, placeholder) {

          init();
          var minValue = dateToStr(config.min || gantt.getState().min_date);
          var maxValue = dateToStr(config.max || gantt.getState().max_date);

          var html = "<div style='width:140px'><input type='date' min='" + minValue + "' max='" + maxValue + "' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        set_value: function (value, id, column, node) {
          if (value && value.getFullYear) {
            this.get_input(node).value = dateToStr(value);
          } else {
            this.get_input(node).value = value;
          }
        },
        is_valid: function (value, id, column, node) {
          if (!value || isNaN(value.getTime()))
            return false;
          return true;
        },
        get_value: function (id, column, node) {
          var parsed;
          try {
            parsed = strToDate(this.get_input(node).value || "");
          } catch (e) {
            parsed = null;// return null will cancel changes
          }

          return parsed;
        }
      }, true);

      return DateEditor;
    };
  }

  predecessorEditorFactoryJs = function () {

    return function (gantt) {

      var BaseEditor = this.baseEditorJs(gantt),
        utils = this.helperService.utils;
      var __extends = this.helperService.extends;

      function PredecessorEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(PredecessorEditor, BaseEditor);

      function parseInputString(value, config) {
        var predecessors = (value || "").split(config.delimiter || ",");
        for (var i = 0; i < predecessors.length; i++) {
          var val = predecessors[i].trim();
          if (val) {
            predecessors[i] = val;
          } else {
            predecessors.splice(i, 1);
            i--;
          }
        }
        predecessors.sort();
        return predecessors;
      }

      function formatPredecessors(task, config, gantt) {
        var links = task.$target;
        var labels = [];
        for (var i = 0; i < links.length; i++) {
          var link = gantt.getLink(links[i]);
          var pred = gantt.getTask(link.source);
          labels.push(gantt.getWBSCode(pred));
        }
        return labels.join((config.delimiter || ",") + " ");
      }

      function getSelectedLinks(taskId, predecessorCodes) {
        var links = [];
        predecessorCodes.forEach(function (code) {
          var predecessor = gantt.getTaskByWBSCode(code);
          if (predecessor) {
            var link = {
              source: predecessor.id,
              target: taskId,
              type: gantt.config.links.finish_to_start,
              lag: 0
            };
            if (gantt.isLinkAllowed(link)) {
              links.push(link);
            }
          }
        });
        return links;
      }

      function getLinksDiff(task, predecessorCodes) {
        var selectedLinks = getSelectedLinks(task.id, predecessorCodes);
        var existingLinksSearch = {};
        task.$target.forEach(function (linkId) {
          var link = gantt.getLink(linkId);
          existingLinksSearch[link.source + "_" + link.target] = link.id;
        });

        var linksToAdd = [];
        selectedLinks.forEach(function (link) {
          var linkKey = link.source + "_" + link.target;
          if (!existingLinksSearch[linkKey]) {
            linksToAdd.push(link);
          } else {
            delete existingLinksSearch[linkKey];
          }
        });

        var linksToDelete = [];
        for (var i in existingLinksSearch) {
          linksToDelete.push(existingLinksSearch[i]);
        }

        return {
          add: linksToAdd,
          remove: linksToDelete
        };
      }

      utils.mixin(PredecessorEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><input type='text' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        hide: function () {
        },
        set_value: function (value, id, column, node) {
          this.get_input(node).value = formatPredecessors(value, column.editor, gantt);
        },
        get_value: function (id, column, node) {
          return parseInputString((this.get_input(node).value || ""), column.editor);
        },
        save: function (id, column, node) {
          var task = gantt.getTask(id);

          var linksDiff = getLinksDiff(task, this.get_value(id, column, node));

          if (linksDiff.add.length || linksDiff.remove.length) {
            gantt.batchUpdate(function () {
              linksDiff.add.forEach(function (link) {
                gantt.addLink(link);
              });
              linksDiff.remove.forEach(function (linkId) {
                gantt.deleteLink(linkId);
              });

              if (gantt.autoSchedule)
                gantt.autoSchedule();
            });
          }
        },
        is_changed: function (value, id, column, node) {
          var inputPredecessors = this.get_value(id, column, node);
          var taskPredecessors = parseInputString(formatPredecessors(value, column.editor, gantt), column.editor);

          return inputPredecessors.join() !== taskPredecessors.join();
        }
      }, true);

      return PredecessorEditor;
    };

    /***/
  }

  linkedPropertiesProcessorJs = function () {

    return function (gantt) {
      return function processTaskDateProperties(item, mapTo, mode) {
        if (mode == "keepDates") {
          keepDatesOnEdit(item, mapTo);
        } else if (mode == "keepDuration") {
          keepDurationOnEdit(item, mapTo);
        } else {
          defaultActionOnEdit(item, mapTo);
        }
      };

      // resize task
      // resize task when start/end/duration changes
      function keepDatesOnEdit(item, mapTo) {
        if (mapTo == "duration") {
          item.end_date = gantt.calculateEndDate(item);
        } else if (mapTo == "end_date" || mapTo == "start_date") {
          item.duration = gantt.calculateDuration(item);
        }
      }

      // move task(before 6.2)
      // move task when start/end dates changes
      // resize task when duration changes
      function keepDurationOnEdit(item, mapTo) {
        if (mapTo == "end_date") {
          item.start_date = gantt.calculateEndDate({
            start_date: item.end_date,
            duration: -item.duration,
            task: item
          }
          );
        } else if (mapTo == "start_date" || mapTo == "duration") {
          item.end_date = gantt.calculateEndDate(item);
        }
      }

      // default behavior
      // move task when start date changes
      // resize task when end date/duration changes
      function defaultActionOnEdit(item, mapTo) {
        if (mapTo == "start_date" || mapTo == "duration") {
          item.end_date = gantt.calculateEndDate(item);
        } else if (mapTo == "end_date") {
          item.duration = gantt.calculateDuration(item);
        }
      }
    };

  }

  gridEditorFactoryJs = function () {

    var getKeyboardMapping = this.getKeyboardMappingJs;
    var textEditorFactory = this.textEditorFactoryJs,
      numberEditorFactory = this.numberEditorFactoryJs,
      selectEditorFactory = this.selectEditorFactoryJs,
      dateEditorFactory = this.dateEditorFactoryJs,
      predecessorEditorFactory = this.predecessorEditorFactoryJs;
    var utils = this.helperService;
    var domHelpers = this.helperService;
    var eventable = this.eventableService;
    var linkedPropertiesProcessor = this.linkedPropertiesProcessorJs;

    function initConfigs(gantt) {
      gantt.config.editor_types = {
        text: new (textEditorFactory(gantt))(),
        number: new (numberEditorFactory(gantt))(),
        select: new (selectEditorFactory(gantt))(),
        date: new (dateEditorFactory(gantt))(),
        predecessor: new (predecessorEditorFactory(gantt))()
      };
    }

    function create(gantt) {
      var keyboardMapping = getKeyboardMapping(gantt);

      var eventBus = {};
      eventable(eventBus);

      function createGridEditors(grid) {

        function _getGridCellFromNode(node) {
          if (!domHelpers.isChildOf(node, grid.$grid)) {
            return null;
          }

          var row = domHelpers.locateAttribute(node, grid.$config.item_attribute);
          var cell = domHelpers.locateAttribute(node, "data-column-name");
          if (cell) {
            var columnName = cell.getAttribute("data-column-name");
            var id = row.getAttribute(grid.$config.item_attribute);
            return {
              id: id,
              columnName: columnName
            };
          }
          return null;

        }

        function _getEditorPosition(itemId, columnName) {
          var top = grid.getItemTop(itemId);
          var height = grid.getItemHeight(itemId);
          var cols = grid.getGridColumns();
          var left = 0,
            width = 0;

          for (var i = 0; i < cols.length; i++) {
            if (cols[i].name == columnName) {
              width = cols[i].width;
              break;
            }
            left += cols[i].width;
          }
          return {
            top: top,
            left: left,
            height: height,
            width: width
          };
        }

        function findVisibleIndex(grid, columnName) {
          var columns = grid.getGridColumns();
          for (var i = 0; i < columns.length; i++) {
            if (columns[i].name == columnName) {
              return i;
            }
          }
          return 0;
        }

        function _createPlaceholder(itemId, columnName) {
          var pos = _getEditorPosition(itemId, columnName);
          var el = document.createElement("div");
          el.className = "gantt_grid_editor_placeholder";
          el.setAttribute(grid.$config.item_attribute, itemId);
          el.setAttribute("data-column-name", columnName);

          var visibleIndex: any = findVisibleIndex(grid, columnName);
          el.setAttribute("data-column-index", visibleIndex);

          el.style.cssText = [
            "top:" + pos.top + "px",
            "left:" + pos.left + "px",
            "width:" + pos.width + "px",
            "height:" + pos.height + "px"
          ].join(";");

          return el;
        }

        var updateTaskDateProperties = linkedPropertiesProcessor(gantt);

        var handlers = [];
        var store = null;
        var controller = {
          _itemId: null,
          _columnName: null,
          _editor: null,
          _editorType: null,
          _placeholder: null,

          locateCell: _getGridCellFromNode,
          getEditorConfig: function (columnName) {
            var column = grid.getColumn(columnName);
            return column.editor;
          },

          init: function () {
            var mapping = keyboardMapping.getMapping();
            if (mapping.init) {
              mapping.init(this, grid);
            }

            store = grid.$gantt.getDatastore(grid.$config.bind);

            var self = this;

            handlers.push(store.attachEvent("onIdChange", function (oldId, newId) {
              if (self._itemId == oldId) {
                self._itemId = newId;
              }
            }));
            handlers.push(store.attachEvent("onStoreUpdated", function () {
              if (grid.$gantt.getState("batchUpdate").batch_update) {
                return;
              }

              if (self.isVisible() && !store.isVisible(self._itemId)) {
                self.hide();
              }
            }));

            this.init = function () { };
          },

          getState: function () {
            return {
              editor: this._editor,
              editorType: this._editorType,
              placeholder: this._placeholder,
              id: this._itemId,
              columnName: this._columnName
            };
          },

          startEdit: function (itemId, columnName) {
            if (this.isVisible()) {
              this.save();
            }

            if (!store.exists(itemId)) {
              return;
            }

            var editorState = { id: itemId, columnName: columnName };
            if (gantt.isReadonly(store.getItem(itemId))) {
              this.callEvent("onEditPrevent", [editorState]);
              return;
            }

            if (this.callEvent("onBeforeEditStart", [editorState]) === false) {
              this.callEvent("onEditPrevent", [editorState]);
              return;
            }

            this.show(editorState.id, editorState.columnName);
            this.setValue();

            this.callEvent("onEditStart", [editorState]);
          },
          isVisible: function () {
            return !!(this._editor && domHelpers.isChildOf(this._placeholder, document.body));
          },
          show: function (itemId, columnName) {
            if (this.isVisible()) {
              this.save();
            }
            var editorState = { id: itemId, columnName: columnName };

            var column = grid.getColumn(editorState.columnName);
            var editorConfig = this.getEditorConfig(column.name);
            if (!editorConfig)
              return;

            var editor = grid.$getConfig().editor_types[editorConfig.type];

            var placeholder = _createPlaceholder(editorState.id, editorState.columnName);
            grid.$grid_data.appendChild(placeholder);
            editor.show(editorState.id, column, editorConfig, placeholder);
            this._editor = editor;
            this._placeholder = placeholder;
            this._itemId = editorState.id;
            this._columnName = editorState.columnName;
            this._editorType = editorConfig.type;

            var mapping = keyboardMapping.getMapping();
            if (mapping.onShow) {
              mapping.onShow(this, placeholder, grid);
            }
          },

          setValue: function () {
            var state = this.getState();
            var itemId = state.id,
              columnName = state.columnName;

            var column = grid.getColumn(columnName);
            var item = store.getItem(itemId);
            var editorConfig = this.getEditorConfig(columnName);

            if (!editorConfig)
              return;

            var value = item[editorConfig.map_to];
            if (editorConfig.map_to == "auto") {
              value = store.getItem(itemId);
            }

            this._editor.set_value(value, itemId, column, this._placeholder);
            this.focus();
          },

          focus: function () {
            this._editor.focus(this._placeholder);
          },

          getValue: function () {
            var column = grid.getColumn(this._columnName);
            return this._editor.get_value(this._itemId, column, this._placeholder);
          },

          _getItemValue: function () {
            var editorConfig = this.getEditorConfig(this._columnName);

            if (!editorConfig)
              return;

            var item = gantt.getTask(this._itemId);
            var value = item[editorConfig.map_to];
            if (editorConfig.map_to == "auto") {
              value = store.getItem(this._itemId);
            }
            return value;
          },

          isChanged: function () {

            var column = grid.getColumn(this._columnName);

            var value = this._getItemValue();

            return this._editor.is_changed(value, this._itemId, column, this._placeholder);
          },

          hide: function () {
            if (!this._itemId)
              return;

            var itemId = this._itemId,
              columnName = this._columnName;

            var mapping = keyboardMapping.getMapping();
            if (mapping.onHide) {
              mapping.onHide(this, this._placeholder, grid);
            }

            this._itemId = null;
            this._columnName = null;
            this._editorType = null;
            if (!this._placeholder) return;

            if (this._editor) {
              this._editor.hide(this._placeholder);
            }
            this._editor = null;
            if (this._placeholder.parentNode) {
              this._placeholder.parentNode.removeChild(this._placeholder);
            }
            this._placeholder = null;

            this.callEvent("onEditEnd", [{ id: itemId, columnName: columnName }]);
          },
          save: function () {
            if (!(this.isVisible() && store.exists(this._itemId) && this.isChanged())) {
              this.hide();
              return;
            }

            var itemId = this._itemId,
              columnName = this._columnName;

            if (!store.exists(itemId)) {
              return;
            }

            var item = store.getItem(itemId);
            var editorConfig = this.getEditorConfig(columnName);
            var editorState = {
              id: itemId,
              columnName: columnName,
              newValue: this.getValue(),
              oldValue: this._getItemValue()
            };
            if (this.callEvent("onBeforeSave", [editorState]) !== false) {
              if (this._editor.is_valid(editorState.newValue, editorState.id, editorState.columnName, this._placeholder)) {

                var mapTo = editorConfig.map_to;
                var value = editorState.newValue;
                if (mapTo != "auto") {
                  item[mapTo] = value;
                  updateTaskDateProperties(item, mapTo, gantt.config.inline_editors_date_processing);

                  store.updateItem(itemId);
                } else {
                  this._editor.save(itemId, grid.getColumn(columnName), this._placeholder);
                }
                this.callEvent("onSave", [editorState]);
              }
            }
            this.hide();
          },

          _findEditableCell: function findEditableCell(start, direction) {
            var nextIndex = start;
            var columns = grid.getGridColumns();
            var nextColumn = columns[nextIndex];

            var columnName = nextColumn ? nextColumn.name : null;
            if (columnName) {
              while (columnName && !this.getEditorConfig(columnName)) {
                columnName = this._findEditableCell(start + direction, direction);
              }
              return columnName;
            }
            return null;
          },

          getNextCell: function moveCell(dir) {
            return this._findEditableCell(grid.getColumnIndex(this._columnName) + dir, dir);
          },

          getFirstCell: function getFirstCell() {
            return this._findEditableCell(0, 1);
          },

          getLastCell: function getLastCell() {
            return this._findEditableCell(grid.getGridColumns().length - 1, -1);
          },

          editNextCell: function nextCell(canChangeRow) {
            var cell = this.getNextCell(1);
            if (cell) {
              var nextColumn = this.getNextCell(1);
              if (nextColumn && this.getEditorConfig(nextColumn)) {
                this.startEdit(this._itemId, nextColumn);
              }
            } else if (canChangeRow && this.moveRow(1)) {
              var task = this.moveRow(1);
              cell = this.getFirstCell();
              if (cell && this.getEditorConfig(cell)) {
                this.startEdit(task, cell);
              }
            }
          },

          editPrevCell: function prevCell(canChangeRow) {
            var cell = this.getNextCell(-1);
            if (cell) {
              var nextColumn = this.getNextCell(-1);
              if (nextColumn && this.getEditorConfig(nextColumn)) {
                this.startEdit(this._itemId, nextColumn);
              }
            } else if (canChangeRow && this.moveRow(-1)) {
              var task = this.moveRow(-1);
              cell = this.getLastCell();
              if (cell && this.getEditorConfig(cell)) {
                this.startEdit(task, cell);
              }
            }
          },

          moveRow: function moveRow(dir) {
            var moveTask = dir > 0 ? gantt.getNext : gantt.getPrev;
            moveTask = gantt.bind(moveTask, gantt);

            var nextItem = moveTask(this._itemId);
            // skip readonly rows
            while (gantt.isTaskExists(nextItem) && gantt.isReadonly(gantt.getTask(nextItem))) {
              nextItem = moveTask(nextItem);
            }
            return nextItem;
          },

          editNextRow: function nextRow() {
            var row = this.getNextCell(1);
            if (row) {
              this.startEdit(row, this._columnName);
            }
          },

          editPrevRow: function prevRow() {
            var row = this.getNextCell(-1);
            if (row) {
              this.startEdit(row, this._columnName);
            }
          },
          destructor: function () {
            handlers.forEach(function (handlerId) {
              store.detachEvent(handlerId);
            });
            store = null;
            this.hide();
            this.detachAllEvents();
          }
        };

        utils.mixin(controller, keyboardMapping);
        utils.mixin(controller, eventBus);

        return controller;
      }


      var inlineEditController = {
        init: initConfigs,
        createEditors: createGridEditors
      };

      utils.mixin(inlineEditController, keyboardMapping);
      utils.mixin(inlineEditController, eventBus);

      return inlineEditController;
    }
    return create;
  }

  smartRenderJs = function () {

    return function wrapSmartRender(renderOne, updateOne, isInViewPort, smartRendering) {
      if (!smartRendering) {
        return renderOne;
      } else {
        return {
          render: function (item, view, viewport) {
            if (!isInViewPort.call(this, item, view, viewport)) {
              return null;
            }
            return renderOne.call(this, item, view, viewport);
          },
          update: function (item, view, engine, viewport) {
            if (!isInViewPort.call(this, item, view, viewport)) {
              engine.hide(item.id);
            } else if (engine.rendered[item.id]) {
              updateOne.call(this, item, view, engine, viewport);
              engine.restore(item);
            } else {
              renderOne.call(this, item, view, viewport);
            }
          }
        };
      }


    };
  }

  isRowInViewPortJs = function (module, exports) {

    return function isInViewPort(item, view, viewport) {
      var position = view.getItemTop(item.id);
      var height = view.getItemHeight(item);
      if (viewport.y > position + height || viewport.y_end < position) {
        return false;
      } else {
        return true;
      }
    };

    /***/
  }

  isBarInViewPortJs = function () {

    var isRowInViewPort = this.isRowInViewPortJs;

    return function isInViewPort(item, view, viewport) {

      if (!isRowInViewPort(item, view, viewport)) {
        return false;
      }

      if (!item.start_date || !item.end_date) {
        return false;
      }
      var left = view.posFromDate(item.start_date);
      var right = view.posFromDate(item.end_date);

      if (left > right) {
        // rtl
        var tmp = right;
        right = left;
        left = tmp;
      }

      left -= 200; // add buffer for custom elements
      right += 200;

      if (viewport.x > right || viewport.x_end < left) {
        return false;
      }

      return true;
    };

    /***/
  }

  createBaseBarRenderJs = function (module, exports) {

    function createTaskRenderer(gantt) {

      function _render_task_element(task, view) {
        var config = view.$getConfig();
        var painters = config.type_renderers;
        var renderer = painters[gantt.getTaskType(task.type)],
          defaultRenderer = _task_default_render;

        if (!renderer) {
          return defaultRenderer.call(gantt, task, view);
        } else {
          return renderer.call(gantt, task, function (task) { return defaultRenderer.call(gantt, task, view); }, view);
        }
      }

      function _task_default_render(task, view) {
        if (gantt._isAllowedUnscheduledTask(task))
          return;


        var pos = view.getItemPosition(task);

        var cfg = view.$getConfig(),
          templates = view.$getTemplates();
        var height = view.getItemHeight();

        var taskType = gantt.getTaskType(task.type);

        var padd = Math.floor((gantt.config.row_height - height) / 2);
        if (taskType == cfg.types.milestone && cfg.link_line_width > 1) {
          //little adjust milestone position, so horisontal corners would match link arrow when thickness of link line is more than 1px
          padd += 1;
        }

        if (taskType == cfg.types.milestone) {
          pos.left -= Math.round(height / 2);
          pos.width = height;
        }

        var div = document.createElement("div");

        var width = Math.round(pos.width);

        if (view.$config.item_attribute) {
          div.setAttribute(view.$config.item_attribute, task.id);
        }

        if (cfg.show_progress && taskType != cfg.types.milestone) {
          _render_task_progress(task, div, width, cfg, templates);
        }

        //use separate div to display content above progress bar
        var content = _render_task_content(task, width, templates);
        if (task.textColor) {
          content.style.color = task.textColor;
        }
        div.appendChild(content);

        var css = _combine_item_class("gantt_task_line",
          templates.task_class(task.start_date, task.end_date, task),
          task.id,
          view);
        if (task.color || task.progressColor || task.textColor) {
          css += " gantt_task_inline_color";
        }
        div.className = css;

        var styles = [
          "left:" + pos.left + "px",
          "top:" + (padd + pos.top) + 'px',
          "height:" + height + 'px',
          "line-height:" + (Math.max(height < 30 ? height - 2 : height, 0)) + 'px',
          "width:" + width + 'px'
        ];
        if (task.color) {
          styles.push("background-color:" + task.color);
        }
        if (task.textColor) {
          styles.push("color:" + task.textColor);
        }

        div.style.cssText = styles.join(";");
        var side = _render_leftside_content(task, cfg, templates);
        if (side) div.appendChild(side);

        side = _render_rightside_content(task, cfg, templates);
        if (side) div.appendChild(side);

        gantt._waiAria.setTaskBarAttr(task, div);

        var state = gantt.getState();

        if (!gantt.isReadonly(task)) {
          if (cfg.drag_resize && !gantt.isSummaryTask(task) && taskType != cfg.types.milestone) {
            _render_pair(div, "gantt_task_drag", task, function (css) {
              var el = document.createElement("div");
              el.className = css;
              return el;
            }, cfg);
          }
          if (cfg.drag_links && cfg.show_links) {
            _render_pair(div, "gantt_link_control", task, function (css) {
              var outer = document.createElement("div");
              outer.className = css;
              outer.style.cssText = [
                "height:" + height + 'px',
                "line-height:" + height + 'px'
              ].join(";");
              var inner = document.createElement("div");
              inner.className = "gantt_link_point";

              var showLinkPoints = false;
              if (state.link_source_id && cfg.touch) {
                showLinkPoints = true;
              }

              inner.style.display = showLinkPoints ? "block" : "";
              outer.appendChild(inner);
              return outer;
            }, cfg);
          }
        }
        return div;
      }

      function _render_side_content(task, template, cssClass) {
        if (!template) return null;

        var text = template(task.start_date, task.end_date, task);
        if (!text) return null;
        var content = document.createElement("div");
        content.className = "gantt_side_content " + cssClass;
        content.innerHTML = text;
        return content;
      }

      function _render_leftside_content(task, cfg: any, templates) {
        var css = "gantt_left " + _get_link_crossing_css(!cfg.rtl ? true : false, task, cfg);
        return _render_side_content(task, templates.leftside_text, css);
      }

      function _render_rightside_content(task, cfg, templates) {
        var css = "gantt_right " + _get_link_crossing_css(!cfg.rtl ? false : true, task, cfg);
        return _render_side_content(task, templates.rightside_text, css);
      }

      function _get_link_crossing_css(left, task, ...args) {
        var cond = _get_conditions(left);

        for (var i in cond) {
          var links = task[i];
          for (var ln = 0; ln < links.length; ln++) {
            var link = gantt.getLink(links[ln]);

            for (var tp = 0; tp < cond[i].length; tp++) {
              if (link.type == cond[i][tp]) {
                return "gantt_link_crossing";
              }
            }
          }
        }
        return "";
      }


      function _render_task_content(task, width, templates) {
        var content = document.createElement("div");
        if (gantt.getTaskType(task.type) != gantt.config.types.milestone)
          content.innerHTML = templates.task_text(task.start_date, task.end_date, task);
        content.className = "gantt_task_content";
        //content.style.width = width + 'px';
        return content;
      }

      function _render_task_progress(task, element, maxWidth, cfg, templates) {
        var done = task.progress * 1 || 0;

        maxWidth = Math.max(maxWidth - 2, 0);//2px for borders
        var pr: any = document.createElement("div");
        var width = Math.round(maxWidth * done);

        width = Math.min(maxWidth, width);
        if (task.progressColor) {
          pr.style.backgroundColor = task.progressColor;
          pr.style.opacity = 1;
        }
        pr.style.width = width + 'px';
        pr.className = "gantt_task_progress";
        pr.innerHTML = templates.progress_text(task.start_date, task.end_date, task);

        if (cfg.rtl) {
          pr.style.position = "absolute";
          pr.style.right = "0px";
        }

        var wrapper = document.createElement("div");
        wrapper.className = "gantt_task_progress_wrapper";
        wrapper.appendChild(pr);
        element.appendChild(wrapper);

        if (gantt.config.drag_progress && !gantt.isReadonly(task)) {
          var drag = document.createElement("div");

          var markerPos = width;
          if (cfg.rtl) {
            markerPos = maxWidth - width;
          }

          drag.style.left = markerPos + 'px';
          drag.className = "gantt_task_progress_drag";
          pr.appendChild(drag);
          element.appendChild(drag);
        }
      }

      function _get_conditions(leftside) {
        if (leftside) {
          return {
            $source: [
              gantt.config.links.start_to_start
            ],
            $target: [
              gantt.config.links.start_to_start,
              gantt.config.links.finish_to_start
            ]
          };
        } else {
          return {
            $source: [
              gantt.config.links.finish_to_start,
              gantt.config.links.finish_to_finish
            ],
            $target: [
              gantt.config.links.finish_to_finish
            ]
          };
        }
      }

      function _combine_item_class(basic, template, itemId, view) {
        var cfg = view.$getConfig();
        var css = [basic];
        if (template)
          css.push(template);

        var state = gantt.getState();

        var task = gantt.getTask(itemId);

        if (gantt.getTaskType(task.type) == cfg.types.milestone) {
          css.push("gantt_milestone");
        } else if (gantt.getTaskType(task.type) == cfg.types.project) {
          css.push("gantt_project");
        }

        css.push("gantt_bar_" + gantt.getTaskType(task.type));


        if (gantt.isSummaryTask(task))
          css.push("gantt_dependent_task");

        if (gantt.isSplitTask(task) && ((cfg.open_split_tasks && !task.$open) || !cfg.open_split_tasks)) {
          css.push("gantt_split_parent");
        }

        if (cfg.select_task && gantt.isSelectedTask(itemId)) {
          css.push("gantt_selected");
        }

        if (itemId == state.drag_id) {
          css.push("gantt_drag_" + state.drag_mode);
          if (state.touch_drag) {
            css.push("gantt_touch_" + state.drag_mode);
          }
        }

        if (state.link_source_id == itemId)
          css.push("gantt_link_source");

        if (state.link_target_id == itemId)
          css.push("gantt_link_target");


        if (cfg.highlight_critical_path && gantt.isCriticalTask) {
          if (gantt.isCriticalTask(task))
            css.push("gantt_critical_task");
        }

        if (state.link_landing_area &&
          (state.link_target_id && state.link_source_id) &&
          (state.link_target_id != state.link_source_id)) {

          var from_id = state.link_source_id;
          var from_start = state.link_from_start;
          var to_start = state.link_to_start;

          var allowDrag = gantt.isLinkAllowed(from_id, itemId, from_start, to_start);

          var dragClass = "";
          if (allowDrag) {
            if (to_start)
              dragClass = "link_start_allow";
            else
              dragClass = "link_finish_allow";
          } else {
            if (to_start)
              dragClass = "link_start_deny";
            else
              dragClass = "link_finish_deny";
          }
          css.push(dragClass);
        }
        return css.join(" ");
      }

      function _render_pair(parent, css, task, content, config) {
        var state = gantt.getState();
        var className, element;
        if (+task.start_date >= +state.min_date) {
          className = [css, config.rtl ? "task_right" : "task_left", "task_start_date"];
          element = content(className.join(" "));
          element.setAttribute("data-bind-property", "start_date");
          parent.appendChild(element);
        }

        if (+task.end_date <= +state.max_date) {
          className = [css, config.rtl ? "task_left" : "task_right", "task_end_date"];
          element = content(className.join(" "));
          element.setAttribute("data-bind-property", "end_date");
          parent.appendChild(element);
        }

      }

      return _render_task_element;
    }

    return createTaskRenderer;

  }

  renderTaskBarJs = function () {

    var smartRender = this.smartRenderJs;
    var isBarInViewPort = this.isBarInViewPortJs;
    var createBaseBarRender = this.createBaseBarRenderJs;
    var isLegacyRender = this.isLegacyRenderJs;
    return function createTaskRenderer(gantt) {
      var defaultRender = createBaseBarRender(gantt);

      return smartRender(
        defaultRender,
        function () { },
        isBarInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    };

  }

  renderSplitTaskBarJS = function () {

    var smartRender = this.smartRenderJs;
    var isBarInViewPort = this.isBarInViewPortJs;
    var createBaseBarRender = this.createBaseBarRenderJs;
    var isLegacyRender = this.isLegacyRenderJs;
    function createTaskRenderer(gantt) {
      var defaultRender = createBaseBarRender(gantt);

      function renderSplitTask(task, timeline) {
        if (gantt.isSplitTask(task) && ((gantt.config.open_split_tasks && !task.$open) || !gantt.config.open_split_tasks)) {
          var el = document.createElement('div'),
            sizes = gantt.getTaskPosition(task);

          var sub_tasks = gantt.getChildren(task.id);


          for (var i = 0; i < sub_tasks.length; i++) {
            var child = gantt.getTask(sub_tasks[i]);

            var element = defaultRender(child, timeline);
            if (!element)
              continue;

            var padding = Math.floor((gantt.config.row_height - sizes.height) / 2);

            element.style.top = (sizes.top + padding) + "px";
            element.className += " gantt_split_child";

            el.appendChild(element);
          }
          return el;
        }
        return false;
      }

      return smartRender(
        renderSplitTask,
        function () { },
        isBarInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createTaskRenderer;
  }

  renderTaskBgJs = function () {

    var smartRender = this.smartRenderJs;
    var isRowInViewPort = this.isRowInViewPortJs;
    var isLegacyRender = this.isLegacyRenderJs;
    function getIndexRange(scale, viewportLeft, viewPortRight) {
      var firstCellIndex = 0;
      var lastCellIndex = scale.left.length - 1;
      for (var i = 0; i < scale.left.length; i++) {
        var left = scale.left[i];
        if (left < viewportLeft) {
          firstCellIndex = i;
        }
        if (left > viewPortRight) {
          lastCellIndex = i;
          break;
        }
      }
      return {
        start: firstCellIndex,
        end: lastCellIndex
      };
    }

    function createTaskBgRender(gantt) {
      var renderedCells = {};
      var visibleCells = {};

      function isRendered(item, columnIndex) {
        if (renderedCells[item.id][columnIndex] && renderedCells[item.id][columnIndex].parentNode) {
          return true;
        } else {
          return false;
        }
      }

      function detachRenderedCell(itemId, columnIndex) {
        if (renderedCells[itemId] && renderedCells[itemId][columnIndex] &&
          renderedCells[itemId][columnIndex].parentNode
        ) {
          renderedCells[itemId][columnIndex].parentNode.removeChild(renderedCells[itemId][columnIndex]);
        }
      }

      function getCellTemplate(view) {
        var templates = view.$getTemplates();
        var cssTemplate;
        if (typeof templates.task_cell_class !== "undefined") {
          cssTemplate = templates.task_cell_class;
          // eslint-disable-next-line no-console
          var log = console.warn || console.log;
          log('gantt.templates.task_cell_class template is deprecated and will be removed soon. Please use gantt.templates.timeline_cell_class instead.');
        } else {
          cssTemplate = templates.timeline_cell_class;
        }
        return cssTemplate;
      }

      function renderCells(item, view, engine, viewPort) {
        var config = view.$getConfig();
        var cfg = view.getScale();
        var count = cfg.count;
        var cssTemplate = getCellTemplate(view);

        if (config.show_task_cells) {
          if (!renderedCells[item.id]) {
            renderedCells[item.id] = {};
          }
          if (!visibleCells[item.id]) {
            visibleCells[item.id] = {};
          }

          var range = getIndexRange(cfg, viewPort.x, viewPort.x_end);

          var row = engine.rendered[item.id];

          for (var i in visibleCells[item.id]) {
            var index = visibleCells[item.id][i];

            if (Number(index) < range.start || Number(index) > range.end) {
              detachRenderedCell(item.id, index);
            }
          }
          visibleCells[item.id][columnIndex] = {};

          // TODO: do not iterate all cell, only ones in the viewport and once that are already rendered
          for (var columnIndex = range.start; columnIndex <= range.end; columnIndex++) {
            var cell = renderOneCell(cfg, columnIndex, item, viewPort, count, cssTemplate, config);
            if (!cell && isRendered(item, columnIndex)) {
              detachRenderedCell(item.id, columnIndex);
            } else if (cell && !cell.parentNode) {
              row.appendChild(cell);
            }
          }
        }
      }

      function isColumnVisible(columnIndex, scale, viewPort) {
        var width = scale.width[columnIndex];
        if (width <= 0) {
          return false;
        }
        if (!gantt.config.smart_rendering || isLegacyRender(gantt)) {
          return true;
        }
        var cellLeftCoord = scale.left[columnIndex] - width;
        var cellRightCoord = scale.left[columnIndex] + width;
        return (cellLeftCoord <= viewPort.x_end && cellRightCoord >= viewPort.x);//do not render skipped columns
      }

      function renderOneCell(scale, columnIndex, item, viewPort, count, cssTemplate, config) {
        var width = scale.width[columnIndex],
          cssclass = "";

        if (isColumnVisible(columnIndex, scale, viewPort)) {//do not render skipped columns

          var cssTemplateContent = cssTemplate(item, scale.trace_x[columnIndex]);

          if (config.static_background) {
            // if cell render in static background is not allowed, or if it's a blank cell
            if (!(config.static_background_cells && cssTemplateContent)) {
              return null;
            }
          }

          if (renderedCells[item.id][columnIndex]) {
            visibleCells[item.id][columnIndex] = columnIndex;
            return renderedCells[item.id][columnIndex];
          }
          var cell = document.createElement("div");
          cell.style.width = (width) + "px";

          cssclass = "gantt_task_cell" + (columnIndex == count - 1 ? " gantt_last_cell" : "");
          if (cssTemplateContent) {
            cssclass += " " + cssTemplateContent;
          }
          cell.className = cssclass;

          if (gantt.config.smart_rendering) {
            cell.style.position = "absolute";
            cell.style.left = scale.left[columnIndex] + "px";
            renderedCells[item.id][columnIndex] = cell;
            visibleCells[item.id][columnIndex] = columnIndex;
          }
          return cell;
        }
        return null;
      }

      function _render_bg_line(item, view, viewPort) {
        var config = view.$getConfig(),
          templates = view.$getTemplates();
        var cfg = view.getScale();
        var count = cfg.count;

        if (config.static_background && !config.static_background_cells) {
          return null;
        }

        var row = document.createElement("div");

        var cellTemplate = getCellTemplate(view);

        var range = getIndexRange(cfg, viewPort.x, viewPort.x_end);

        if (!config.smart_rendering || isLegacyRender(gantt)) {
          range = {
            start: 0,
            end: count - 1
          };
        }
        if (config.show_task_cells) {
          renderedCells[item.id] = {};
          visibleCells[item.id] = {};
          for (var columnIndex = range.start; columnIndex <= range.end; columnIndex++) {
            var cell = renderOneCell(cfg, columnIndex, item, viewPort, count, cellTemplate, config);
            if (cell) {
              row.appendChild(cell);
            }
          }
        }
        var odd = gantt.getGlobalTaskIndex(item.id) % 2 !== 0;
        var cssTemplate = templates.task_row_class(item.start_date, item.end_date, item);
        var css = "gantt_task_row" + (odd ? " odd" : "") + (cssTemplate ? ' ' + cssTemplate : '');

        var store = view.$config.rowStore;
        if (store.isSelected(item.id)) {
          css += " gantt_selected";
        }

        row.className = css;

        if (config.smart_rendering) {
          row.style.position = "absolute";
          row.style.top = view.getItemTop(item.id) + "px";
          row.style.width = "100%";
        }
        row.style.height = (config.row_height) + "px";

        if (view.$config.item_attribute) {
          row.setAttribute(view.$config.item_attribute, item.id);
        }

        return row;
      }

      return smartRender(
        _render_bg_line,
        renderCells,
        isRowInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createTaskBgRender;


    /***/
  }

  isLinkInViewPortJs = function () {
    return function isLinkInViewPort(item, view, viewport) {
      var source = view.$gantt.getTask(item.source);
      var target = view.$gantt.getTask(item.target);

      // check vertical visibility first since it's a lighter check
      var sourceTop = view.getItemTop(source.id);
      var sourceHeight = view.getItemHeight(source);

      var targetTop = view.getItemTop(target.id);
      var targetHeight = view.getItemHeight(target);

      if (viewport.y > sourceTop + sourceHeight &&
        viewport.y > targetTop + targetHeight) {
        return false;
      }

      if (viewport.y_end < targetTop &&
        viewport.y_end < targetHeight) {
        return false;
      }

      var padding = 100;
      var sourceLeft = view.posFromDate(source.start_date);
      var sourceRight = view.posFromDate(source.end_date);
      var targetLeft = view.posFromDate(target.start_date);
      var targetRight = view.posFromDate(target.end_date);

      if (sourceLeft > sourceRight) {
        // rtl
        var tmp = sourceRight;
        sourceRight = sourceLeft;
        sourceLeft = tmp;
      }
      if (targetLeft > targetRight) {
        // rtl
        var tmp = targetRight;
        targetRight = targetLeft;
        targetLeft = tmp;
      }
      sourceLeft += -padding; // add buffer for custom elements
      sourceRight += padding;
      targetLeft += -padding; // add buffer for custom elements
      targetRight += padding;

      if (viewport.x > sourceRight &&
        viewport.x > targetRight) {
        return false;
      }

      if (viewport.x_end < sourceLeft &&
        viewport.x_end < targetLeft) {
        return false;
      }
      return true;
    };


    /***/
  }

  renderLinkJs = function () {

    var smartRender = this.smartRenderJs;
    var isLinkInViewPort = this.isLinkInViewPortJs;
    var isLegacyRender = this.isLegacyRenderJs;

    function createLinkRender(gantt) {

      function _render_link_element(link, view) {
        var config = view.$getConfig();

        var pt = path_builder.get_endpoint(link, view);
        var dy = pt.e_y - pt.y;
        var dx = pt.e_x - pt.x;
        if (!dx && !dy) {
          return null;
        }


        var dots = path_builder.get_points(link, view);
        var lines = drawer.get_lines(dots, view);

        var div = document.createElement("div");

        var css = "gantt_task_link";

        if (link.color) {
          css += " gantt_link_inline_color";
        }
        var cssTemplate = gantt.templates.link_class ? gantt.templates.link_class(link) : "";
        if (cssTemplate) {
          css += " " + cssTemplate;
        }

        if (config.highlight_critical_path && gantt.isCriticalLink) {
          if (gantt.isCriticalLink(link))
            css += " gantt_critical_link";
        }

        div.className = css;

        if (view.$config.link_attribute) {
          div.setAttribute(view.$config.link_attribute, link.id);
        }

        for (var i = 0; i < lines.length; i++) {
          if (i == lines.length - 1) {
            lines[i].size -= config.link_arrow_size;
          }
          var el = drawer.render_line(lines[i], lines[i + 1], view);
          if (link.color) {
            (<HTMLInputElement>el.firstChild).style.backgroundColor = link.color;
          }
          div.appendChild(el);
        }

        var direction = lines[lines.length - 1].direction;
        var endpoint = _render_link_arrow(dots[dots.length - 1], direction, view);
        if (link.color) {
          endpoint.style.borderColor = link.color;
        }
        div.appendChild(endpoint);

        gantt._waiAria.linkAttr(link, div);

        return div;
      }

      function _render_link_arrow(point, direction, view) {
        var config = view.$getConfig();
        var div = document.createElement("div");
        var top = point.y;
        var left = point.x;

        var size = config.link_arrow_size;
        var line_width = config.row_height;
        var className = "gantt_link_arrow gantt_link_arrow_" + direction;
        switch (direction) {
          case drawer.dirs.right:
            top -= (size - line_width) / 2;
            left -= size;
            break;
          case drawer.dirs.left:
            top -= (size - line_width) / 2;
            break;
          case drawer.dirs.up:
            left -= size;
            break;
          case drawer.dirs.down:
            top += size * 2;
            left -= size;
            break;
          default:
            break;
        }
        div.style.cssText = [
          "top:" + top + "px",
          "left:" + left + 'px'].join(';');
        div.className = className;

        return div;
      }


      var drawer = {
        current_pos: null,
        dirs: { "left": 'left', "right": 'right', "up": 'up', "down": 'down' },
        path: [],
        clear: function () {
          this.current_pos = null;
          this.path = [];
        },
        point: function (pos) {
          this.current_pos = gantt.copy(pos);
        },
        get_lines: function (dots, ...args) {
          this.clear();
          this.point(dots[0]);
          for (var i = 1; i < dots.length; i++) {
            this.line_to(dots[i]);
          }
          return this.get_path();
        },
        line_to: function (pos) {
          var next = gantt.copy(pos);
          var prev = this.current_pos;

          var line = this._get_line(prev, next);
          this.path.push(line);
          this.current_pos = next;
        },
        get_path: function () {
          return this.path;
        },
        get_wrapper_sizes: function (v, view) {
          var config = view.$getConfig();
          var res,
            wrapper_size = config.link_wrapper_width,
            y = v.y + (config.row_height - wrapper_size) / 2;
          switch (v.direction) {
            case this.dirs.left:
              res = {
                top: y,
                height: wrapper_size,
                lineHeight: wrapper_size,
                left: v.x - v.size - wrapper_size / 2,
                width: v.size + wrapper_size
              };
              break;
            case this.dirs.right:
              res = {
                top: y,
                lineHeight: wrapper_size,
                height: wrapper_size,
                left: v.x - wrapper_size / 2,
                width: v.size + wrapper_size
              };
              break;
            case this.dirs.up:
              res = {
                top: y - v.size,
                lineHeight: v.size + wrapper_size,
                height: v.size + wrapper_size,
                left: v.x - wrapper_size / 2,
                width: wrapper_size
              };
              break;
            case this.dirs.down:
              res = {
                top: y /*- wrapper_size/2*/,
                lineHeight: v.size + wrapper_size,
                height: v.size + wrapper_size,
                left: v.x - wrapper_size / 2,
                width: wrapper_size
              };
              break;
            default:
              break;
          }

          return res;
        },
        get_line_sizes: function (v, view) {
          var config = view.$getConfig();
          var res,
            line_size = config.link_line_width,
            wrapper_size = config.link_wrapper_width,
            size = v.size + line_size;
          switch (v.direction) {
            case this.dirs.left:
            case this.dirs.right:
              res = {
                height: line_size,
                width: size,
                marginTop: (wrapper_size - line_size) / 2,
                marginLeft: (wrapper_size - line_size) / 2
              };
              break;
            case this.dirs.up:
            case this.dirs.down:
              res = {
                height: size,
                width: line_size,
                marginTop: (wrapper_size - line_size) / 2,
                marginLeft: (wrapper_size - line_size) / 2
              };
              break;
            default:
              break;
          }


          return res;
        },
        render_line: function (v, end, view) {
          var pos = this.get_wrapper_sizes(v, view);
          var wrapper = document.createElement("div");
          wrapper.style.cssText = [
            "top:" + pos.top + "px",
            "left:" + pos.left + "px",
            "height:" + pos.height + "px",
            "width:" + pos.width + "px"
          ].join(';');
          wrapper.className = "gantt_line_wrapper";

          var innerPos = this.get_line_sizes(v, view);
          var inner = document.createElement("div");
          inner.style.cssText = [
            "height:" + innerPos.height + "px",
            "width:" + innerPos.width + "px",
            "margin-top:" + innerPos.marginTop + "px",
            "margin-left:" + innerPos.marginLeft + "px"
          ].join(";");

          inner.className = "gantt_link_line_" + v.direction;
          wrapper.appendChild(inner);

          return wrapper;
        },
        _get_line: function (from, to) {
          var direction = this.get_direction(from, to);
          var vect: any = {
            x: from.x,
            y: from.y,
            direction: this.get_direction(from, to)
          };
          if (direction == this.dirs.left || direction == this.dirs.right) {
            vect.size = Math.abs(from.x - to.x);
          } else {
            vect.size = Math.abs(from.y - to.y);
          }
          return vect;
        },
        get_direction: function (from, to) {
          var direction = 0;
          if (to.x < from.x) {
            direction = this.dirs.left;
          } else if (to.x > from.x) {
            direction = this.dirs.right;
          } else if (to.y > from.y) {
            direction = this.dirs.down;
          } else {
            direction = this.dirs.up;
          }
          return direction;
        }

      };

      var path_builder = {

        path: [],
        clear: function () {
          this.path = [];
        },
        current: function () {
          return this.path[this.path.length - 1];
        },
        point: function (next) {
          if (!next)
            return this.current();

          this.path.push(gantt.copy(next));
          return next;
        },
        point_to: function (direction, diff, point) {
          if (!point)
            point = gantt.copy(this.point());
          else
            point = { x: point.x, y: point.y };
          var dir = drawer.dirs;
          switch (direction) {
            case (dir.left):
              point.x -= diff;
              break;
            case (dir.right):
              point.x += diff;
              break;
            case (dir.up):
              point.y -= diff;
              break;
            case (dir.down):
              point.y += diff;
              break;
            default:
              break;
          }
          return this.point(point);
        },
        get_points: function (link, view) {
          var pt = this.get_endpoint(link, view);
          var xy = gantt.config;

          var dy = pt.e_y - pt.y;
          var dx = pt.e_x - pt.x;

          var dir = drawer.dirs;

          this.clear();
          this.point({ x: pt.x, y: pt.y });

          var shiftX = 2 * xy.link_arrow_size;//just random size for first line
          var lineType = this.get_line_type(link, view.$getConfig());

          var forward = (pt.e_x > pt.x);
          if (lineType.from_start && lineType.to_start) {
            this.point_to(dir.left, shiftX);
            if (forward) {
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              this.point_to(dir.right, dx);
              this.point_to(dir.down, dy);
            }
            this.point_to(dir.right, shiftX);

          } else if (!lineType.from_start && lineType.to_start) {
            forward = (pt.e_x > (pt.x + 2 * shiftX));
            this.point_to(dir.right, shiftX);
            if (forward) {
              dx -= shiftX;
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              dx -= 2 * shiftX;
              var sign = dy > 0 ? 1 : -1;

              this.point_to(dir.down, sign * (xy.row_height / 2));
              this.point_to(dir.right, dx);
              this.point_to(dir.down, sign * (Math.abs(dy) - (xy.row_height / 2)));
              this.point_to(dir.right, shiftX);
            }

          } else if (!lineType.from_start && !lineType.to_start) {
            this.point_to(dir.right, shiftX);
            if (forward) {
              this.point_to(dir.right, dx);
              this.point_to(dir.down, dy);
            } else {
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            }
            this.point_to(dir.left, shiftX);
          } else if (lineType.from_start && !lineType.to_start) {

            forward = (pt.e_x > (pt.x - 2 * shiftX));
            this.point_to(dir.left, shiftX);

            if (!forward) {
              dx += shiftX;
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              dx += 2 * shiftX;
              var sign = dy > 0 ? 1 : -1;
              this.point_to(dir.down, sign * (xy.row_height / 2));
              this.point_to(dir.right, dx);
              this.point_to(dir.down, sign * (Math.abs(dy) - (xy.row_height / 2)));
              this.point_to(dir.left, shiftX);
            }

          }

          return this.path;
        },
        get_line_type: function (link, config) {
          var types = config.links;
          var from_start = false, to_start = false;
          if (link.type == types.start_to_start) {
            from_start = to_start = true;
          } else if (link.type == types.finish_to_finish) {
            from_start = to_start = false;
          } else if (link.type == types.finish_to_start) {
            from_start = false;
            to_start = true;
          } else if (link.type == types.start_to_finish) {
            from_start = true;
            to_start = false;
          } else {
            gantt.assert(false, "Invalid link type");
          }

          if (config.rtl) {
            from_start = !from_start;
            to_start = !to_start;
          }

          return { from_start: from_start, to_start: to_start };
        },

        get_endpoint: function (link, view) {
          var config = view.$getConfig();

          var lineType = this.get_line_type(link, config);
          var from_start = lineType.from_start,
            to_start = lineType.to_start;

          var source = gantt.getTask(link.source);
          var target = gantt.getTask(link.target);

          var from = getMilestonePosition(source, view),
            to = getMilestonePosition(target, view);

          return {
            x: from_start ? from.left : (from.left + from.width),
            e_x: to_start ? to.left : (to.left + to.width),
            y: from.top,
            e_y: to.top
          };
        }
      };

      function getMilestonePosition(task, view) {
        var config = view.$getConfig();
        var pos = view.getItemPosition(task);
        if (gantt.getTaskType(task.type) == config.types.milestone) {
          var milestoneHeight = gantt.getTaskHeight();
          var milestoneWidth = Math.sqrt(2 * milestoneHeight * milestoneHeight);
          pos.left -= milestoneWidth / 2;
          pos.width = milestoneWidth;
        }
        return pos;
      }

      return smartRender(
        _render_link_element,
        function () { },
        isLinkInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createLinkRender;

    /***/
  }

  gridRendererJs = function () {

    var helpers = this.helperService;
    var smartRender = this.smartRenderJs;
    var isRowInViewPort = this.isRowInViewPortJs;
    var isLegacyRender = this.isLegacyRenderJs;
    function createGridLineRender(gantt) {

      function isInViewPort(item, view, viewport) {
        if (gantt.$keyboardNavigation && gantt.$keyboardNavigation.dispatcher.isTaskFocused(item.id)) {
          return true;
        }

        return isRowInViewPort(item, view, viewport);
      }

      function _render_grid_item(item, view, viewport) {
        var columns = view.getGridColumns();
        var config = view.$getConfig(),
          templates = view.$getTemplates();

        var store = view.$config.rowStore;

        if (config.rtl) {
          columns = columns.reverse();
        }

        var cells = [];
        var has_child;
        for (var i = 0; i < columns.length; i++) {
          var last = i == columns.length - 1;
          var col = columns[i];
          var cell;

          var value;
          var textValue;
          if (col.name == "add") {
            var aria = gantt._waiAria.gridAddButtonAttrString(col);

            value = "<div " + aria + " class='gantt_add'></div>";
            textValue = "";
          } else {
            if (col.template)
              value = col.template(item);
            else
              value = item[col.name];

            if (helpers.isDate(value))
              value = templates.date_grid(value, item);

            if (value === null || value === undefined) {
              value = "";
            }

            textValue = value;
            value = "<div class='gantt_tree_content'>" + value + "</div>";
          }
          var css = "gantt_cell" + (last ? " gantt_last_cell" : "");

          var tree = [];
          if (col.tree) {
            for (var j = 0; j < item.$level; j++)
              tree.push(templates.grid_indent(item));

            has_child = store.hasChild(item.id) && !(gantt.isSplitTask(item) && !gantt.config.open_split_tasks);
            if (has_child) {
              tree.push(templates.grid_open(item));
              tree.push(templates.grid_folder(item));
            } else {
              tree.push(templates.grid_blank(item));
              tree.push(templates.grid_file(item));
            }
          }
          var style = "width:" + (col.width - (last ? 1 : 0)) + "px;";
          if (this.defined(col.align))
            style += "text-align:" + col.align + ";";

          var aria = gantt._waiAria.gridCellAttrString(col, textValue);

          tree.push(value);
          if (config.rtl) {
            tree = tree.reverse();
          }
          cell = "<div class='" + css + "' data-column-index='" + i + "' data-column-name='" + col.name + "' style='" + style + "' " + aria + ">" + tree.join("") + "</div>";
          cells.push(cell);
        }
        var css = gantt.getGlobalTaskIndex(item.id) % 2 === 0 ? "" : " odd";
        css += (item.$transparent) ? " gantt_transparent" : "";

        css += (item.$dataprocessor_class ? " " + item.$dataprocessor_class : "");

        if (templates.grid_row_class) {
          var css_template = templates.grid_row_class.call(gantt, item.start_date, item.end_date, item);
          if (css_template)
            css += " " + css_template;
        }

        if (store.isSelected(item.id)) {
          css += " gantt_selected";
        }

        var el = document.createElement("div");
        el.className = "gantt_row" + css + " gantt_row_" + gantt.getTaskType(item.type);
        var height = view.getItemHeight();
        el.style.height = height + "px";
        el.style.lineHeight = height + "px";

        if (config.smart_rendering) {
          el.style.position = "absolute";
          el.style.left = "0px";
          el.style.top = view.getItemTop(item.id) + "px";
        }

        if (view.$config.item_attribute) {
          el.setAttribute(view.$config.item_attribute, item.id);
        }

        gantt._waiAria.taskRowAttr(item, el);

        el.innerHTML = cells.join("");
        return el;
      }

      //return _render_grid_item;

      return smartRender(
        _render_grid_item,
        function () { },
        isInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createGridLineRender;
  }

  rowDndJs = function () {

    var domHelpers = this.helperService;

    function _init_dnd(gantt, grid) {
      var DnD = gantt.$services.getService("dnd");

      if (!grid.$config.bind || !gantt.getDatastore(grid.$config.bind)) {
        return;
      }

      function locate(e) {
        return domHelpers.locateAttribute(e, grid.$config.item_attribute);
      }

      function getStore() {
        return gantt.getDatastore(grid.$config.bind);
      }

      var dnd = new DnD(grid.$grid_data, { updates_per_second: 60 });
      if (gantt.defined(grid.$getConfig().dnd_sensitivity))
        dnd.config.sensitivity = grid.$getConfig().dnd_sensitivity;

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        if (!el) return false;
        if (gantt.hideQuickInfo) gantt._hideQuickInfo();

        if (domHelpers.closest(e.target, ".gantt_grid_editor_placeholder")) {
          return false;
        }

        var id = el.getAttribute(grid.$config.item_attribute);

        var datastore = getStore();

        var task = datastore.getItem(id);

        if (gantt.isReadonly(task))
          return false;

        dnd.config.initial_open_state = task.$open;
        if (!gantt.callEvent("onRowDragStart", [id, e.target || e.srcElement, e])) {
          return false;
        }

      }, gantt));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        dnd.config.marker.innerHTML = el.outerHTML;
        var element = dnd.config.marker.firstChild;
        if (element) {
          element.style.position = "static";
        }

        dnd.config.id = el.getAttribute(grid.$config.item_attribute);

        var store = getStore();

        var task = store.getItem(dnd.config.id);
        dnd.config.index = store.getBranchIndex(dnd.config.id);
        dnd.config.parent = task.parent;
        task.$open = false;
        task.$transparent = true;
        this.refreshData();
      }, gantt));

      dnd.lastTaskOfLevel = function (level) {
        var last_item = null;
        var store = getStore();
        var tasks = store.getItems();
        for (var i = 0, len = tasks.length; i < len; i++) {
          if (tasks[i].$level == level) {
            last_item = tasks[i];
          }
        }
        return last_item ? last_item.id : null;
      };
      dnd._getGridPos = gantt.bind(function (e) {
        var pos = domHelpers.getNodePosition(grid.$grid_data);
        var store = getStore();
        // row offset
        var x = pos.x;
        var y = e.pos.y - 10;

        var config = grid.$getConfig();
        // prevent moving row out of grid_data container
        if (y < pos.y) y = pos.y;
        var gridHeight = store.countVisible() * config.row_height;
        if (y > pos.y + gridHeight - config.row_height) y = pos.y + gridHeight - config.row_height;

        pos.x = x;
        pos.y = y;
        return pos;
      }, gantt);
      dnd._getTargetY = gantt.bind(function (e) {
        var pos = domHelpers.getNodePosition(grid.$grid_data);

        var y = e.pageY - pos.y + (grid.$state.scrollTop || 0);
        if (y < 0)
          y = 0;
        return y;
      }, gantt);
      dnd._getTaskByY = gantt.bind(function (y, dropIndex) {

        var config = grid.$getConfig(),
          store = getStore();

        y = y || 0;

        var index = Math.floor(y / config.row_height);
        index = dropIndex < index ? index - 1 : index;

        if (index > store.countVisible() - 1)
          return null;

        return store.getIdByIndex(index);
      }, gantt);
      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var dd = dnd.config;
        var pos = dnd._getGridPos(e);

        var config = grid.$getConfig(),
          store = getStore();

        // setting position of row
        dd.marker.style.left = pos.x + 10 + "px";
        dd.marker.style.top = pos.y + "px";

        // highlight row when mouseover
        var item = store.getItem(dnd.config.id);
        var targetY = dnd._getTargetY(e);
        var el = dnd._getTaskByY(targetY, store.getIndexById(item.id));

        if (!store.exists(el)) {
          el = dnd.lastTaskOfLevel(config.order_branch_free ? item.$level : 0);
          if (el == dnd.config.id) {
            el = null;
          }
        }

        function allowedLevel(next, item) {
          return (!(store.isChildOf(over.id, item.id)) && (next.$level == item.$level || config.order_branch_free));
        }

        if (store.exists(el)) {
          var over = store.getItem(el);

          if (store.getIndexById(over.id) * config.row_height + config.row_height / 2 < targetY) {
            //hovering over bottom part of item, check can be drop to bottom
            var index = store.getIndexById(over.id);
            var nextId = store.getNext(over.id);//adds +1 when hovering over placeholder
            var next = store.getItem(nextId);
            if (next) {
              if (next.id != item.id) {
                over = next; //there is a valid target
              }
              else {
                if (config.order_branch_free) {
                  if (!(store.isChildOf(item.id, over.id) && store.getChildren(over.id).length == 1))
                    return;
                  else {
                    store.move(item.id, store.getBranchIndex(over.id) + 1, store.getParent(over.id));
                    return;
                  }
                }
                else {
                  return;
                }
              }
            } else {
              //we at end of the list, check and drop at the end of list
              nextId = store.getIdByIndex(index);
              next = store.getItem(nextId);

              if (allowedLevel(next, item) && next.id != item.id) {
                store.move(item.id, -1, store.getParent(next.id));
                return;
              }
            }
          }
          else if (config.order_branch_free) {
            if (over.id != item.id && allowedLevel(over, item)) {
              if (!store.hasChild(over.id)) {
                over.$open = true;
                store.move(item.id, -1, over.id);
                return;
              }
              if (store.getIndexById(over.id) || config.row_height / 3 < targetY) return;
            }
          }
          //if item is on different level, check the one before it
          var index = store.getIndexById(over.id),
            prevId = store.getIdByIndex(index - 1);

          var prev = store.getItem(prevId);

          var shift = 1;
          while ((!prev || prev.id == over.id) && index - shift >= 0) {

            prevId = store.getIdByIndex(index - shift);
            prev = store.getItem(prevId);
            shift++;
          }

          if (item.id == over.id) return;
          //replacing item under cursor
          if (allowedLevel(over, item) && item.id != over.id) {
            store.move(item.id, 0, 0, over.id);

          } else if (over.$level == item.$level - 1 && !store.getChildren(over.id).length) {
            store.move(item.id, 0, over.id);

          } else if (prev && (allowedLevel(prev, item)) && (item.id != prev.id)) {
            store.move(item.id, -1, store.getParent(prev.id));

          }
        }
        return true;
      }, gantt));

      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var store = getStore();
        var task = store.getItem(dnd.config.id);
        task.$transparent = false;
        task.$open = dnd.config.initial_open_state;

        if (this.callEvent("onBeforeRowDragEnd", [dnd.config.id, dnd.config.parent, dnd.config.index]) === false) {
          store.move(dnd.config.id, dnd.config.index, dnd.config.parent);
          task.$drop_target = null;
        } else {
          this.callEvent("onRowDragEnd", [dnd.config.id, task.$drop_target]);
        }

        this.refreshData();
      }, gantt));
    }

    return {
      init: _init_dnd
    };

    /***/
  }

  dropTargetJs = function () {

    /**
     * The state object for order branch drag and drop
     */

    var utils = this.helperService.utils;

    return {
      createDropTargetObject: function createDropTargetObject(parent) {
        var res = {
          targetParent: null,
          targetIndex: 0,
          targetId: null,
          child: false,
          nextSibling: false,
          prevSibling: false
        };

        if (parent) {
          utils.mixin(res, parent, true);
        }
        return res;
      },
      nextSiblingTarget: function nextSiblingTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.nextSibling = true;
        result.targetParent = store.getParent(result.targetId);
        result.targetIndex = store.getBranchIndex(result.targetId);
        if (store.getParent(dndTaskId) != result.targetParent || result.targetIndex < store.getBranchIndex(dndTaskId)) {
          result.targetIndex += 1;
        }
        return result;
      },
      prevSiblingTarget: function prevSiblingTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.prevSibling = true;
        result.targetParent = store.getParent(result.targetId);
        result.targetIndex = store.getBranchIndex(result.targetId);
        if (store.getParent(dndTaskId) == result.targetParent && result.targetIndex > store.getBranchIndex(dndTaskId)) {
          result.targetIndex -= 1;
        }
        return result;
      },
      firstChildTarget: function firstChildTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.targetParent = result.targetId;
        result.targetIndex = 0;
        result.child = true;
        return result;
      },
      lastChildTarget: function lastChildTarget(dndTaskId, targetTaskId, store) {
        var children = store.getChildren(targetTaskId);
        var result = this.createDropTargetObject();
        result.targetId = children[children.length - 1];
        result.targetParent = targetTaskId;
        result.targetIndex = children.length;
        result.nextSibling = true;
        return result;
      }
    };

    /***/
  }

  getLockedLevelTargetJs = function () {

    /**
     * resolve dnd position of the task when gantt.config.order_branch_free = false
     */

    var dropTarget = this.dropTargetJs;

    function getLast(store) {
      var current = store.getNext();
      while (store.exists(current)) {

        var next = store.getNext(current);
        if (!store.exists(next)) {
          return current;
        } else {
          current = next;
        }
      }
      return null;
    }

    function findClosesTarget(dndTaskId, taskId, allowedLevel, store, up) {
      var prev = taskId;
      while (store.exists(prev)) {
        var targetLevel = store.calculateItemLevel(store.getItem(prev));
        if ((targetLevel === allowedLevel || targetLevel === (allowedLevel - 1)) && store.getBranchIndex(prev) > -1) {
          break;
        } else {
          prev = up ? store.getPrev(prev) : store.getNext(prev);
        }
      }

      if (store.exists(prev)) {
        if (store.calculateItemLevel(store.getItem(prev)) === allowedLevel) {
          return up ? dropTarget.nextSiblingTarget(dndTaskId, prev, store) : dropTarget.prevSiblingTarget(dndTaskId, prev, store);
        } else {
          return dropTarget.firstChildTarget(dndTaskId, prev, store);
        }
      }
      return null;
    }

    function findTargetAbove(dndTaskId, taskId, allowedLevel, store) {
      return findClosesTarget(dndTaskId, taskId, allowedLevel, store, true);
    }
    function findTargetBelow(dndTaskId, taskId, allowedLevel, store) {
      return findClosesTarget(dndTaskId, taskId, allowedLevel, store, false);
    }

    return function getSameLevelDropPosition(dndTaskId, targetTaskId, relTargetPos, eventTop, store, level) {
      var result;
      if (targetTaskId !== store.$getRootId()) {
        if (relTargetPos < 0.5) {
          if (store.calculateItemLevel(store.getItem(targetTaskId)) === level) {
            if (store.getPrevSibling(targetTaskId)) {
              result = dropTarget.nextSiblingTarget(dndTaskId, store.getPrevSibling(targetTaskId), store);
            } else {
              result = dropTarget.prevSiblingTarget(dndTaskId, targetTaskId, store);
            }
          } else {
            result = findTargetAbove(dndTaskId, targetTaskId, level, store);
            if (result) {
              result = findTargetBelow(dndTaskId, targetTaskId, level, store);
            }
          }
        } else {
          if (store.calculateItemLevel(store.getItem(targetTaskId)) === level) {
            result = dropTarget.nextSiblingTarget(dndTaskId, targetTaskId, store);
          } else {
            result = findTargetBelow(dndTaskId, targetTaskId, level, store);
            if (result) {
              result = findTargetAbove(dndTaskId, targetTaskId, level, store);
            }
          }
        }
      } else {
        var rootId = store.$getRootId();
        var rootLevel = store.getChildren(rootId);
        result = dropTarget.createDropTargetObject();
        if (rootLevel.length && eventTop >= 0) {
          result = findTargetAbove(dndTaskId, getLast(store), level, store);
        } else {
          result = findTargetBelow(dndTaskId, rootId, level, store);
        }
      }

      return result;
    };


    /***/
  }

  getMultiLevelTargetJs = function () {

    /**
     * resolve dnd position of the task when gantt.config.order_branch_free = true
     */

    var dropTarget = this.dropTargetJs;

    return function getMultiLevelDropPosition(dndTaskId, targetTaskId, relTargetPos, eventTop, store) {
      var result;

      if (targetTaskId !== store.$getRootId()) {
        if (relTargetPos < 0.25) {
          result = dropTarget.prevSiblingTarget(dndTaskId, targetTaskId, store);
        } else if (relTargetPos > 0.60 && !(store.hasChild(targetTaskId) && store.getItem(targetTaskId).$open)) {
          result = dropTarget.nextSiblingTarget(dndTaskId, targetTaskId, store);
        } else {
          result = dropTarget.firstChildTarget(dndTaskId, targetTaskId, store);
        }
      } else {
        var rootId = store.$getRootId();
        if (store.hasChild(rootId) && eventTop >= 0) {
          result = dropTarget.lastChildTarget(dndTaskId, rootId, store);
        } else {
          result = dropTarget.firstChildTarget(dndTaskId, rootId, store);
        }
      }

      return result;
    };

    /***/
  }

  highighterJs = function () {

    var domHelpers = this.helperService;

    /**
     * methods for highlighting current drag and drop position
     */

    function highlightPosition(target, root, grid) {
      var markerPos = getTaskMarkerPosition(target, grid);
      // setting position of row
      root.marker.style.left = markerPos.x + 9 + "px";
      root.marker.style.top = markerPos.y + "px";
      var markerLine = root.markerLine;
      if (!markerLine) {
        markerLine = document.createElement("div");
        markerLine.className = "gantt_drag_marker gantt_grid_dnd_marker";
        markerLine.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>";
        markerLine.style.pointerEvents = "none";
        document.body.appendChild(markerLine);
        root.markerLine = markerLine;
      }
      if (target.child) {
        highlightFolder(target, markerLine, grid);
      } else {
        highlightRow(target, markerLine, grid);
      }
    }

    function removeLineHighlight(root) {
      if (root.markerLine && root.markerLine.parentNode) {
        root.markerLine.parentNode.removeChild(root.markerLine);
      }
      root.markerLine = null;
    }

    function highlightRow(target, markerLine, grid) {
      var linePos = getLineMarkerPosition(target, grid);

      markerLine.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>";
      markerLine.style.left = linePos.x + "px";
      markerLine.style.height = "4px";

      markerLine.style.top = (linePos.y - 2) + "px";
      markerLine.style.width = linePos.width + "px";

      return markerLine;
    }
    function highlightFolder(target, markerFolder, grid) {
      var id = target.targetParent;
      var pos = gridToPageCoordinates({ x: 0, y: grid.getItemTop(id) }, grid);

      markerFolder.innerHTML = "<div class='gantt_grid_dnd_marker_folder'></div>";
      markerFolder.style.width = grid.$grid_data.offsetWidth + "px";
      markerFolder.style.top = pos.y + "px";
      markerFolder.style.left = pos.x + "px";
      markerFolder.style.height = grid.getItemHeight(id) + "px";
      return markerFolder;
    }

    function getLineMarkerPosition(target, grid) {
      var store = grid.$config.rowStore;
      var pos: any = { x: 0, y: 0 };
      var indentNode = grid.$grid_data.querySelector(".gantt_tree_indent");
      var indent = 15;
      var level = 0;
      if (indentNode) {
        indent = indentNode.offsetWidth;
      }
      var iconWidth = 40;
      if (target.targetId !== store.$getRootId()) {
        var itemTop = grid.getItemTop(target.targetId);
        var itemHeight = grid.getItemHeight(target.targetId);
        level = store.exists(target.targetId) ? store.calculateItemLevel(store.getItem(target.targetId)) : 0;

        if (target.prevSibling) {
          pos.y = itemTop;
        } else if (target.nextSibling) {
          var childCount = 0;
          store.eachItem(function (child) {
            if (store.getIndexById(child.id) !== -1)
              childCount++;
          }, target.targetId);

          pos.y = itemTop + itemHeight + childCount * itemHeight;
        } else {
          pos.y = itemTop + itemHeight;
          level += 1;
        }
      }
      pos.x = iconWidth + level * indent;
      pos.width = Math.max(grid.$grid_data.offsetWidth - pos.x, 0);
      return gridToPageCoordinates(pos, grid);
    }

    function gridToPageCoordinates(pos, grid) {
      var gridPos = domHelpers.getNodePosition(grid.$grid_data);
      pos.x += gridPos.x - grid.$grid.scrollLeft;
      pos.y += gridPos.y - grid.$grid_data.scrollTop;
      return pos;
    }

    function getTaskMarkerPosition(e, grid) {
      var pos = domHelpers.getNodePosition(grid.$grid_data);
      var ePos = domHelpers.getRelativeEventPosition(e, grid.$grid_data);
      var store = grid.$config.rowStore;
      // row offset
      var x = pos.x;
      var y = ePos.y - 10;

      var config = grid.$getConfig();
      // prevent moving row out of grid_data container
      if (y < pos.y) y = pos.y;
      var gridHeight = store.countVisible() * config.row_height;
      if (y > pos.y + gridHeight - config.row_height) y = pos.y + gridHeight - config.row_height;

      pos.x = x;
      pos.y = y;
      return pos;
    }

    return {
      removeLineHighlight: removeLineHighlight,
      highlightPosition: highlightPosition
    };

  }

  rowDndMarkerJs = function () {

    var domHelpers = this.helperService;
    var dropTarget = this.dropTargetJs;
    var getLockedLevelTarget = this.getLockedLevelTargetJs;
    var getMultiLevelTarget = this.getMultiLevelTarget;
    var higlighter = this.highighterJs;

    function _init_dnd(gantt, grid) {
      var DnD = gantt.$services.getService("dnd");

      if (!grid.$config.bind || !gantt.getDatastore(grid.$config.bind)) {
        return;
      }

      function locate(e) {
        return domHelpers.locateAttribute(e, grid.$config.item_attribute);
      }

      var dnd = new DnD(grid.$grid_data, { updates_per_second: 60 });
      if (gantt.defined(grid.$getConfig().dnd_sensitivity))
        dnd.config.sensitivity = grid.$getConfig().dnd_sensitivity;

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        if (!el) return false;
        if (gantt.hideQuickInfo) gantt._hideQuickInfo();
        if (domHelpers.closest(e.target, ".gantt_grid_editor_placeholder")) {
          return false;
        }

        var id = el.getAttribute(grid.$config.item_attribute);
        var datastore = grid.$config.rowStore;
        var task = datastore.getItem(id);

        if (gantt.isReadonly(task))
          return false;

        dnd.config.initial_open_state = task.$open;
        if (!gantt.callEvent("onRowDragStart", [id, e.target || e.srcElement, e])) {
          return false;
        }

      }, gantt));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);

        dnd.config.marker.innerHTML = el.outerHTML;
        var element = dnd.config.marker.firstChild;
        if (element) {
          dnd.config.marker.style.opacity = 0.4;
          element.style.position = "static";
          element.style.pointerEvents = "none";
        }

        dnd.config.id = el.getAttribute(grid.$config.item_attribute);

        var store = grid.$config.rowStore;

        var task = store.getItem(dnd.config.id);
        dnd.config.level = store.calculateItemLevel(task);
        dnd.config.drop_target = dropTarget.createDropTargetObject({
          targetParent: store.getParent(task.id),
          targetIndex: store.getBranchIndex(task.id),
          targetId: task.id,
          nextSibling: true
        });

        task.$open = false;
        task.$transparent = true;
        this.refreshData();
      }, gantt));

      function getTargetTaskId(e) {
        var y = domHelpers.getRelativeEventPosition(e, grid.$grid_data).y;
        var store = grid.$config.rowStore;

        y = y || 0;

        if (y < 0) {
          return store.$getRootId();
        }

        var index = Math.floor(y / grid.getItemHeight());

        if (index > store.countVisible() - 1)
          return store.$getRootId();

        return store.getIdByIndex(index);
      }

      function getDropPosition(e) {
        var targetTaskId = getTargetTaskId(e);
        var relTargetPos = null;
        var store = grid.$config.rowStore;
        var config = grid.$getConfig();
        var lockLevel = !config.order_branch_free;

        var eventTop = domHelpers.getRelativeEventPosition(e, grid.$grid_data).y;

        if (targetTaskId !== store.$getRootId()) {
          var rowTop = grid.getItemTop(targetTaskId);
          var rowHeight = grid.getItemHeight();
          relTargetPos = (eventTop - rowTop) / rowHeight;
        }

        var result;
        if (!lockLevel) {
          result = getMultiLevelTarget(dnd.config.id, targetTaskId, relTargetPos, eventTop, store);
        } else {
          result = getLockedLevelTarget(dnd.config.id, targetTaskId, relTargetPos, eventTop, store, dnd.config.level);
        }

        return result;
      }

      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var target = getDropPosition(e);

        if (!target ||
          gantt.callEvent("onBeforeRowDragMove", [dnd.config.id, target.targetParent, target.targetIndex]) === false) {
          target = dropTarget.createDropTargetObject(dnd.config.drop_target);
        }

        higlighter.highlightPosition(target, dnd.config, grid);
        dnd.config.drop_target = target;

        this.callEvent("onRowDragMove", [dnd.config.id, target.targetParent, target.targetIndex]);
        return true;
      }, gantt));

      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var store = grid.$config.rowStore;
        var task = store.getItem(dnd.config.id);

        higlighter.removeLineHighlight(dnd.config);

        task.$transparent = false;
        task.$open = dnd.config.initial_open_state;
        var target = dnd.config.drop_target;

        if (this.callEvent("onBeforeRowDragEnd", [dnd.config.id, target.targetParent, target.targetIndex]) === false) {
          task.$drop_target = null;
        } else {
          store.move(dnd.config.id, target.targetIndex, target.targetParent);
          this.callEvent("onRowDragEnd", [dnd.config.id, target.targetParent, target.targetIndex]);
        }
        store.refresh(task.id);
      }, gantt));
    }

    return {
      init: _init_dnd
    };

  }
  mainGridInitializerJs = function () {

    var utils = this.helperService.utils;
    var rowDnd = this.rowDndJs;
    var rowDndMarker = this.rowDndMarkerJs;

    var initializer = (function () {
      return function (gantt) {
        return {
          onCreated: function (grid) {
            grid.$config = utils.mixin(grid.$config, {
              bind: "task"
            });
            if (grid.$config.id == "grid") {
              this.extendGantt(grid);
              gantt.ext.inlineEditors = gantt.ext._inlineEditors.createEditors(grid);
              gantt.ext.inlineEditors.init();
            }

            this._mouseDelegates = this.mouseDelegatesJs(gantt);
          },
          onInitialized: function (grid) {
            var config = grid.$getConfig();
            if (config.order_branch) {
              if (config.order_branch == "marker") {
                rowDndMarker.init(grid.$gantt, grid);
              } else {
                rowDnd.init(grid.$gantt, grid);
              }
            }

            this.initEvents(grid, gantt);
            if (grid.$config.id == "grid") {
              this.extendDom(grid);
            }
          },
          onDestroyed: function (grid) {
            if (grid.$config.id == "grid") {
              gantt.ext.inlineEditors.destructor();
            }
            this.clearEvents(grid, gantt);
          },

          initEvents: function (grid, gantt) {
            this._mouseDelegates.delegate("click", "gantt_row", gantt.bind(function (e, id, trg) {
              var config = grid.$getConfig();
              if (id !== null) {
                var task = this.getTask(id);
                if (config.scroll_on_click && !gantt._is_icon_open_click(e))
                  this.showDate(task.start_date);
                gantt.callEvent("onTaskRowClick", [id, trg]);
              }
            }, gantt), grid.$grid);

            this._mouseDelegates.delegate("click", "gantt_grid_head_cell", gantt.bind(function (e, id, trg) {
              var column = trg.getAttribute("data-column-id");

              if (!gantt.callEvent("onGridHeaderClick", [column, e]))
                return;

              var config = grid.$getConfig();

              if (column == "add") {
                var mouseEvents = gantt.$services.getService("mouseEvents");
                mouseEvents.callHandler("click", "gantt_add", grid.$grid, [e, config.root_id]);
                return;
              }

              if (config.sort) {
                var sorting_method = column,
                  conf;

                for (var i = 0; i < config.columns.length; i++) {
                  if (config.columns[i].name == column) {
                    conf = config.columns[i];
                    break;
                  }
                }

                if (conf && conf.sort !== undefined && conf.sort !== true) {
                  sorting_method = conf.sort;

                  if (!sorting_method) { // column sort property 'false', no sorting
                    return;
                  }
                }

                var sort = (this._sort && this._sort.direction && this._sort.name == column) ? this._sort.direction : "desc";
                // invert sort direction
                sort = (sort == "desc") ? "asc" : "desc";
                this._sort = {
                  name: column,
                  direction: sort
                };
                this.sort(sorting_method, sort == "desc");
              }
            }, gantt), grid.$grid);

            this._mouseDelegates.delegate("click", "gantt_add", gantt.bind(function (e, id, trg) {
              var config = grid.$getConfig();
              if (config.readonly) return;

              var item = {};
              this.createTask(item, id ? id : gantt.config.root_id);

              return false;
            }, gantt), grid.$grid);

          },

          clearEvents: function (grid, gantt) {
            this._mouseDelegates.destructor();
            this._mouseDelegates = null;
          },

          extendDom: function (grid) {
            gantt.$grid = grid.$grid;
            gantt.$grid_scale = grid.$grid_scale;
            gantt.$grid_data = grid.$grid_data;
          },
          extendGantt: function (grid) {
            gantt.getGridColumns = gantt.bind(grid.getGridColumns, grid);

            grid.attachEvent("onColumnResizeStart", function () {
              return gantt.callEvent("onColumnResizeStart", arguments);
            });
            grid.attachEvent("onColumnResize", function () {
              return gantt.callEvent("onColumnResize", arguments);
            });
            grid.attachEvent("onColumnResizeEnd", function () {
              return gantt.callEvent("onColumnResizeEnd", arguments);
            });

            grid.attachEvent("onColumnResizeComplete", function (columns, totalWidth) {
              gantt.config.grid_width = totalWidth;
            });
          }
        };
      };
    })();

    return initializer;

  }

  taskDndJs = function () {

    var domHelpers = this.helperService,
      utils = this.helperService;
    var timeout = this.helperService.checkTimeout;

    function createTaskDND(timeline, gantt) {
      var services = gantt.$services;
      return {
        drag: null,
        dragMultiple: {},
        _events: {
          before_start: {},
          before_finish: {},
          after_finish: {}
        },
        _handlers: {},
        init: function () {
          this._domEvents = gantt._createDomEventScope();
          this.clear_drag_state();
          var drag = gantt.config.drag_mode;
          this.set_actions();

          var stateService = services.getService("state");
          stateService.registerProvider("tasksDnd", utils.bind(function () {
            return {
              drag_id: this.drag ? this.drag.id : undefined,
              drag_mode: this.drag ? this.drag.mode : undefined,
              drag_from_start: this.drag ? this.drag.left : undefined
            };
          }, this));

          var evs = {
            "before_start": "onBeforeTaskDrag",
            "before_finish": "onBeforeTaskChanged",
            "after_finish": "onAfterTaskDrag"
          };
          //for now, all drag operations will trigger the same events
          for (var stage in this._events) {
            for (var mode in drag) {
              this._events[stage][mode] = evs[stage];
            }
          }

          this._handlers[drag.move] = this._move;
          this._handlers[drag.resize] = this._resize;
          this._handlers[drag.progress] = this._resize_progress;
        },
        set_actions: function () {
          var data = timeline.$task_data;
          this._domEvents.attach(data, "mousemove", gantt.bind(function (e) {
            this.on_mouse_move(e || event);
          }, this));
          this._domEvents.attach(data, "mousedown", gantt.bind(function (e) {
            this.on_mouse_down(e || event);
          }, this));
          this._domEvents.attach(gantt.$root, "mouseup", gantt.bind(function (e) {
            this.on_mouse_up(e || event);
          }, this));
        },

        clear_drag_state: function () {
          this.drag = {
            id: null,
            mode: null,
            pos: null,
            start_x: null,
            start_y: null,
            obj: null,
            left: null
          };
          this.dragMultiple = {};
        },
        _resize: function (ev, shift, drag) {
          var cfg = timeline.$getConfig();
          var coords_x = this._drag_task_coords(ev, drag);
          if (drag.left) {
            ev.start_date = gantt.dateFromPos(coords_x.start + shift);
            if (!ev.start_date) {
              ev.start_date = new Date(gantt.getState().min_date);
            }
          } else {
            ev.end_date = gantt.dateFromPos(coords_x.end + shift);
            if (!ev.end_date) {
              ev.end_date = new Date(gantt.getState().max_date);
            }
          }

          if (ev.end_date - ev.start_date < cfg.min_duration) {
            if (drag.left)
              ev.start_date = gantt.calculateEndDate({ start_date: ev.end_date, duration: -1, task: ev });
            else
              ev.end_date = gantt.calculateEndDate({ start_date: ev.start_date, duration: 1, task: ev });
          }
          gantt._init_task_timing(ev);
        },
        _resize_progress: function (ev, shift, drag) {
          var coords_x = this._drag_task_coords(ev, drag);

          var config = timeline.$getConfig();
          var diffValue = !config.rtl ? (drag.pos.x - coords_x.start) : (coords_x.start - drag.pos.x);

          var diff = Math.max(0, diffValue);
          ev.progress = Math.min(1, diff / Math.abs(coords_x.end - coords_x.start));
        },

        _find_max_shift: function (dragItems, shift) {
          var correctShift;
          for (var i in dragItems) {
            var drag = dragItems[i];
            var ev = gantt.getTask(drag.id);

            var coords_x = this._drag_task_coords(ev, drag);
            var minX = gantt.posFromDate(new Date(gantt.getState().min_date)),
              maxX = gantt.posFromDate(new Date(gantt.getState().max_date));

            if (coords_x.end + shift > maxX) {
              var maxShift = maxX - coords_x.end;
              if (maxShift < correctShift || correctShift === undefined) {
                correctShift = maxShift;
              }
            } else if (coords_x.start + shift < minX) {
              var minShift = minX - coords_x.start;
              if (minShift < correctShift || correctShift === undefined) {
                correctShift = minShift;
              }
            }
          }
          return correctShift;
        },
        _move: function (ev, shift, drag) {
          var coords_x = this._drag_task_coords(ev, drag);
          var new_start = gantt.dateFromPos(coords_x.start + shift),
            new_end = gantt.dateFromPos(coords_x.end + shift);
          if (!new_start) {
            ev.start_date = new Date(gantt.getState().min_date);
            ev.end_date = gantt.dateFromPos(gantt.posFromDate(ev.start_date) + (coords_x.end - coords_x.start));
          } else if (!new_end) {
            ev.end_date = new Date(gantt.getState().max_date);
            ev.start_date = gantt.dateFromPos(gantt.posFromDate(ev.end_date) - (coords_x.end - coords_x.start));
          } else {
            ev.start_date = new_start;
            ev.end_date = new_end;
          }
        },
        _drag_task_coords: function (t, drag) {
          var start = drag.obj_s_x = drag.obj_s_x || gantt.posFromDate(t.start_date);
          var end = drag.obj_e_x = drag.obj_e_x || gantt.posFromDate(t.end_date);
          return {
            start: start,
            end: end
          };
        },
        _mouse_position_change: function (oldPos, newPos) {
          var dx = oldPos.x - newPos.x,
            dy = oldPos.y - newPos.y;
          return Math.sqrt(dx * dx + dy * dy);
        },
        _is_number: function (n) {
          return !isNaN(parseFloat(n)) && isFinite(n);
        },

        on_mouse_move: function (e) {
          if (this.drag.start_drag) {
            var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);

            var sX = this.drag.start_drag.start_x,
              sY = this.drag.start_drag.start_y;

            if ((Date.now() - this.drag.timestamp > 50) ||
              (this._is_number(sX) && this._is_number(sY) && this._mouse_position_change({
                x: sX,
                y: sY
              }, pos) > 20)) {
              this._start_dnd(e);
            }
          }

          var drag = this.drag;

          if (drag.mode) {
            if (!timeout(this, 40))//limit update frequency
              return;

            this._update_on_move(e);

          }
        },

        _update_item_on_move: function (shift, id, mode, drag, e) {
          var ev = gantt.getTask(id);
          var original = gantt.mixin({}, ev);
          var copy = gantt.mixin({}, ev);
          this._handlers[mode].apply(this, [copy, shift, drag]);
          gantt.mixin(ev, copy, true);
          //gantt._update_parents(drag.id, true);
          gantt.callEvent("onTaskDrag", [ev.id, mode, copy, original, e]);
          gantt.mixin(ev, copy, true);
          gantt.refreshTask(id);
        },

        _update_on_move: function (e) {
          var drag = this.drag;
          var config = timeline.$getConfig();
          if (drag.mode) {
            var pos = domHelpers.getRelativeEventPosition(e, timeline.$task_data);
            if (drag.pos && drag.pos.x == pos.x)
              return;

            drag.pos = pos;

            var curr_date = gantt.dateFromPos(pos.x);
            if (!curr_date || isNaN(curr_date.getTime()))
              return;


            var shift = pos.x - drag.start_x;
            var ev = gantt.getTask(drag.id);

            if (this._handlers[drag.mode]) {

              if (gantt.isSummaryTask(ev) && gantt.config.drag_project && drag.mode == config.drag_mode.move) {

                var initialDrag = {};
                initialDrag[drag.id] = utils.copy(drag);
                var maxShift = this._find_max_shift(utils.mixin(initialDrag, this.dragMultiple), shift);
                if (maxShift !== undefined) {
                  shift = maxShift;
                }

                this._update_item_on_move(shift, drag.id, drag.mode, drag, e);
                for (var i in this.dragMultiple) {
                  var childDrag = this.dragMultiple[i];
                  this._update_item_on_move(shift, childDrag.id, childDrag.mode, childDrag, e);
                }
              } else {
                this._update_item_on_move(shift, drag.id, drag.mode, drag, e);
              }
              gantt._update_parents(drag.id);
            }

          }
        },

        on_mouse_down: function (e, src) {
          // on Mac we do not get onmouseup event when clicking right mouse button leaving us in dnd state
          // let's ignore right mouse button then
          if (e.button == 2 && e.button !== undefined)
            return;

          var config = timeline.$getConfig();
          var id = gantt.locate(e);
          var task = null;
          if (gantt.isTaskExists(id)) {
            task = gantt.getTask(id);
          }

          if (gantt.isReadonly(task) || this.drag.mode) return;

          this.clear_drag_state();

          src = src || (e.target || e.srcElement);

          var className = domHelpers.getClassName(src);
          var drag = this._get_drag_mode(className, src);

          if (!className || !drag) {
            if (src.parentNode)
              return this.on_mouse_down(e, src.parentNode);
            else
              return;
          }

          if (!drag) {
            if (gantt.checkEvent("onMouseDown") && gantt.callEvent("onMouseDown", [className.split(" ")[0]])) {
              if (src.parentNode)
                return this.on_mouse_down(e, src.parentNode);

            }
          } else {
            if (drag.mode && drag.mode != config.drag_mode.ignore && config["drag_" + drag.mode]) {
              id = gantt.locate(src);
              task = gantt.copy(gantt.getTask(id) || {});

              if (gantt.isReadonly(task)) {
                this.clear_drag_state();
                return false;
              }

              if ((gantt.isSummaryTask(task) && !config.drag_project) && drag.mode != config.drag_mode.progress) {//only progress drag is allowed for tasks with flexible duration
                this.clear_drag_state();
                return;
              }

              drag.id = id;
              var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);

              drag.start_x = pos.x;
              drag.start_y = pos.y;
              drag.obj = task;
              this.drag.start_drag = drag;
              this.drag.timestamp = Date.now();

            } else
              this.clear_drag_state();
          }
        },
        _fix_dnd_scale_time: function (task, drag) {
          var config = timeline.$getConfig();
          var unit = gantt.getScale().unit,
            step = gantt.getScale().step;
          if (!config.round_dnd_dates) {
            unit = 'minute';
            step = config.time_step;
          }

          function fixStart(task) {
            if (!gantt.config.correct_work_time)
              return;
            var config = timeline.$getConfig();
            if (!gantt.isWorkTime(task.start_date, undefined, task))
              task.start_date = gantt.calculateEndDate({
                start_date: task.start_date,
                duration: -1,
                unit: config.duration_unit,
                task: task
              });
          }

          function fixEnd(task) {
            if (!gantt.config.correct_work_time)
              return;
            var config = timeline.$getConfig();
            if (!gantt.isWorkTime(new Date(task.end_date - 1), undefined, task))
              task.end_date = gantt.calculateEndDate({
                start_date: task.end_date,
                duration: 1,
                unit: config.duration_unit,
                task: task
              });
          }

          if (drag.mode == config.drag_mode.resize) {
            if (drag.left) {
              task.start_date = gantt.roundDate({ date: task.start_date, unit: unit, step: step });
              fixStart(task);
            } else {
              task.end_date = gantt.roundDate({ date: task.end_date, unit: unit, step: step });
              fixEnd(task);
            }
          } else if (drag.mode == config.drag_mode.move) {
            task.start_date = gantt.roundDate({ date: task.start_date, unit: unit, step: step });
            fixStart(task);
            task.end_date = gantt.calculateEndDate(task);
          }
        },
        _fix_working_times: function (task, drag) {
          var config = timeline.$getConfig();
          var drag = drag || { mode: config.drag_mode.move };

          if (drag.mode == config.drag_mode.resize) {
            if (drag.left) {
              task.start_date = gantt.getClosestWorkTime({ date: task.start_date, dir: 'future', task: task });
            } else {
              task.end_date = gantt.getClosestWorkTime({ date: task.end_date, dir: 'past', task: task });
            }
          } else if (drag.mode == config.drag_mode.move) {
            gantt.correctTaskWorkTime(task);
          }
        },

        _finalize_mouse_up: function (taskId, config, drag, e) {
          var ev = gantt.getTask(taskId);

          if (config.work_time && config.correct_work_time) {
            this._fix_working_times(ev, drag);
          }

          this._fix_dnd_scale_time(ev, drag);

          if (!this._fireEvent("before_finish", drag.mode, [taskId, drag.mode, gantt.copy(drag.obj), e])) {
            //drag.obj._dhx_changed = false;
            this.clear_drag_state();
            if (taskId == drag.id) {
              drag.obj._dhx_changed = false;
              gantt.mixin(ev, drag.obj, true);
            }


            gantt.refreshTask(ev.id);
          } else {
            var drag_id = taskId;

            gantt._init_task_timing(ev);

            this.clear_drag_state();
            gantt.updateTask(ev.id);
            this._fireEvent("after_finish", drag.mode, [drag_id, drag.mode, e]);
          }

        },

        on_mouse_up: function (e) {

          var drag = this.drag;
          if (drag.mode && drag.id) {
            var config = timeline.$getConfig();
            //drop
            var ev = gantt.getTask(drag.id);
            var dragMultiple = this.dragMultiple;

            if (gantt.isSummaryTask(ev) && config.drag_project && drag.mode == config.drag_mode.move) {
              for (var i in dragMultiple) {
                this._finalize_mouse_up(dragMultiple[i].id, config, dragMultiple[i], e);
              }
            }
            this._finalize_mouse_up(drag.id, config, drag, e);
          }
          this.clear_drag_state();
        },
        _get_drag_mode: function (className, el) {
          var config = timeline.$getConfig();
          var modes = config.drag_mode;
          var classes = (className || "").split(" ");
          var classname = classes[0];
          var drag = { mode: null, left: null };
          switch (classname) {
            case "gantt_task_line":
            case "gantt_task_content":
              drag.mode = modes.move;
              break;
            case "gantt_task_drag":
              drag.mode = modes.resize;

              var dragProperty = el.getAttribute("data-bind-property");

              if (dragProperty == "start_date") {
                drag.left = true;
              } else {
                drag.left = false;
              }
              break;
            case "gantt_task_progress_drag":
              drag.mode = modes.progress;
              break;
            case "gantt_link_control":
            case "gantt_link_point":
              drag.mode = modes.ignore;
              break;
            default:
              drag = null;
              break;
          }
          return drag;

        },

        _start_dnd: function (e) {
          var drag = this.drag = this.drag.start_drag;
          delete drag.start_drag;

          var cfg = timeline.$getConfig();
          var id = drag.id;
          if (!cfg["drag_" + drag.mode] || !gantt.callEvent("onBeforeDrag", [id, drag.mode, e]) || !this._fireEvent("before_start", drag.mode, [id, drag.mode, e])) {
            this.clear_drag_state();
          } else {
            delete drag.start_drag;

            var task = gantt.getTask(id);
            if (gantt.isSummaryTask(task) && gantt.config.drag_project && drag.mode == cfg.drag_mode.move) {
              gantt.eachTask(function (child) {
                this.dragMultiple[child.id] = gantt.mixin({
                  id: child.id,
                  obj: child
                }, this.drag);
              }, task.id, this);
            }

            gantt.callEvent("onTaskDragStart", []);
          }

        },
        _fireEvent: function (stage, mode, params) {
          gantt.assert(this._events[stage], "Invalid stage:{" + stage + "}");

          var trigger = this._events[stage][mode];

          gantt.assert(trigger, "Unknown after drop mode:{" + mode + "}");
          gantt.assert(params, "Invalid event arguments");


          if (!gantt.checkEvent(trigger))
            return true;

          return gantt.callEvent(trigger, params);
        },

        round_task_dates: function (task) {
          var drag_state = this.drag;
          var config = timeline.$getConfig();
          if (!drag_state) {
            drag_state = { mode: config.drag_mode.move };
          }
          this._fix_dnd_scale_time(task, drag_state);
        },
        destructor: function () {
          this._domEvents.detachAll();
        }
      };
    }

    function initTaskDND() {
      var _tasks_dnd;
      return {
        extend: function (timeline) {
          timeline.roundTaskDates = function (task) {
            _tasks_dnd.round_task_dates(task);
          };

        },
        init: function (timeline, gantt) {
          _tasks_dnd = createTaskDND(timeline, gantt);
          // TODO: entry point for touch handlers, move touch to timeline
          timeline._tasks_dnd = _tasks_dnd;
          return _tasks_dnd.init(gantt);
        },
        destructor: function () {
          if (_tasks_dnd) {
            _tasks_dnd.destructor();
            _tasks_dnd = null;
          }
        }
      };
    }

    return {
      createTaskDND: initTaskDND
    };


    /***/
  }

  linkDndJs = function () {

    var domHelpers = this.helperService;

    var initLinksDND = function (timeline, gantt) {
      var _link_landing,
        _link_target_task,
        _link_target_task_start,
        _link_source_task,
        _link_source_task_start,
        markerDefaultOffset = 10,
        scrollDefaultSize = 18;


      function getVisibleMilestoneWidth() {
        var origWidth = timeline.getItemHeight();//m-s have square shape
        return Math.round(Math.sqrt(2 * origWidth * origWidth)) - 2;
      }

      function isMilestone(task) {
        return gantt.getTaskType(task.type) == gantt.config.types.milestone;
      }

      function getDndState() {
        return {
          link_source_id: _link_source_task,
          link_target_id: _link_target_task,
          link_from_start: _link_source_task_start,
          link_to_start: _link_target_task_start,
          link_landing_area: _link_landing
        };
      }

      var services = gantt.$services;

      var state = services.getService("state");
      var DnD = services.getService("dnd");

      state.registerProvider("linksDnD", getDndState);

      var dnd = new DnD(timeline.$task_bars, { sensitivity: 0, updates_per_second: 60 }),
        start_marker = "task_start_date",
        end_marker = "task_end_date",
        link_edge_marker = "gantt_link_point",
        link_landing_hover_area = "gantt_link_control";

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var target = (e.target || e.srcElement);
        resetDndState();
        if (gantt.getState().drag_id)
          return false;

        if (domHelpers.locateClassName(target, link_edge_marker)) {
          if (domHelpers.locateClassName(target, start_marker))
            _link_source_task_start = true;

          var sid = gantt.locate(e);
          _link_source_task = sid;

          var t = gantt.getTask(sid);
          if (gantt.isReadonly(t)) {
            resetDndState();
            return false;
          }

          var shift = 0;

          this._dir_start = getLinePos(t, !!_link_source_task_start, shift, timeline.$getConfig(), true);
          return true;
        } else {
          return false;
        }

      }, this));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        if (gantt.config.touch) {
          gantt.refreshData();
        }
        updateMarkedHtml(dnd.config.marker);
      }, this));

      function getLinePos(task, to_start, shift, cfg, isStart?) {
        var taskPos: any = getMilestonePosition(task, function (task) { return gantt.getTaskPosition(task); }, cfg);

        var pos = { x: taskPos.x, y: taskPos.y };
        if (!to_start) {
          pos.x = taskPos.xEnd;
        }

        //var pos = gantt._get_task_pos(task, !!to_start);
        pos.y += gantt.config.row_height / 2;

        var offset = isMilestone(task) && isStart ? 2 : 0;

        shift = shift || 0;
        if (cfg.rtl)
          shift = shift * -1;

        pos.x += (to_start ? -1 : 1) * shift - offset;
        return pos;
      }

      function getMilestonePosition(task, getTaskPosition, cfg) {
        var pos = getTaskPosition(task);

        var res: any = {
          x: pos.left,
          y: pos.top,
          width: pos.width,
          height: pos.height
        };

        if (cfg.rtl) {
          res.xEnd = res.x;
          res.x = res.xEnd + res.width;
        } else {
          res.xEnd = res.x + res.width;
        }
        res.yEnd = res.y + res.height;

        if (gantt.getTaskType(task.type) == gantt.config.types.milestone) {
          var milestoneWidth = getVisibleMilestoneWidth();

          res.x += (!cfg.rtl ? -1 : 1) * (milestoneWidth / 2);
          res.xEnd += (!cfg.rtl ? 1 : -1) * (milestoneWidth / 2);

          //pos.x -= milestoneWidth / 2;
          //pos.xEnd += milestoneWidth / 2;
          res.width = pos.xEnd - pos.x;
        }


        return res;
      }

      function getVieportSize() {
        var root = gantt.$root;
        return { right: root.offsetWidth, bottom: root.offsetHeight };
      }
      function getMarkerSize(marker) {
        var width = 0, height = 0;
        if (marker) {
          width = marker.offsetWidth || 0;
          height = marker.offsetHeight || 0;
        }
        return { width: width, height: height };
      }

      function getPosition(e, marker) {
        var oldPos = dnd.getPosition(e);

        var markerSize = getMarkerSize(marker);
        var viewportSize = getVieportSize();

        var offsetX = gantt.config.tooltip_offset_x || markerDefaultOffset;
        var offsetY = gantt.config.tooltip_offset_y || markerDefaultOffset;

        var scrollSize = gantt.config.scroll_size || scrollDefaultSize;

        var position = {
          y: oldPos.y + offsetY,
          x: oldPos.x + offsetX,
          bottom: oldPos.y + markerSize.height + offsetY + scrollSize,
          right: oldPos.x + markerSize.width + offsetX + scrollSize
        };

        if (position.bottom > viewportSize.bottom) {
          position.y = viewportSize.bottom - markerSize.height - offsetY;
        }

        if (position.right > viewportSize.right) {
          position.x = viewportSize.right - markerSize.width - offsetX;
        }
        return position;
      }

      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var dd = dnd.config;
        var pos = getPosition(e, dd.marker);
        advanceMarker(dd.marker, pos);
        var landing = !!domHelpers.locateClassName(e, link_landing_hover_area);

        var prevTarget = _link_target_task;
        var prevLanding = _link_landing;
        var prevToStart = _link_target_task_start;

        var targ = gantt.locate(e),
          to_start = true;

        // can drag and drop link to another gantt on the page, such links are not supported
        var sameGantt = domHelpers.isChildOf(e.target || e.srcElement, gantt.$root);
        if (!sameGantt) {
          landing = false;
          targ = null;
        }

        if (landing) {
          //refreshTask
          to_start = !domHelpers.locateClassName(e, end_marker);
          landing = !!targ;
        }

        _link_target_task = targ;
        _link_landing = landing;
        _link_target_task_start = to_start;

        if (landing) {
          var t = gantt.getTask(targ);

          var config = timeline.$getConfig();
          var node = domHelpers.locateClassName(e, link_landing_hover_area);
          var shift = 0;
          if (node) {
            shift = Math.floor(node.offsetWidth / 2);
          }

          this._dir_end = getLinePos(t, !!_link_target_task_start, shift, config);
        } else {
          this._dir_end = domHelpers.getRelativeEventPosition(e, timeline.$task_data);
        }

        var targetChanged = !(prevLanding == landing && prevTarget == targ && prevToStart == to_start);
        if (targetChanged) {
          if (prevTarget)
            gantt.refreshTask(prevTarget, false);
          if (targ)
            gantt.refreshTask(targ, false);
        }

        if (targetChanged) {
          updateMarkedHtml(dd.marker);
        }

        showDirectingLine(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y);

        return true;
      }, this));


      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var drag = getDndState();

        if (drag.link_source_id && drag.link_target_id && drag.link_source_id != drag.link_target_id) {
          var type = gantt._get_link_type(drag.link_from_start, drag.link_to_start);

          var link = { source: drag.link_source_id, target: drag.link_target_id, type: type };
          if (link.type && gantt.isLinkAllowed(link)) {
            if (gantt.callEvent("onLinkCreated", [link])) {
              gantt.addLink(link);
            }
          }
        }

        resetDndState();

        if (gantt.config.touch) {
          gantt.refreshData();
        }
        else {
          if (drag.link_source_id)
            gantt.refreshTask(drag.link_source_id, false);
          if (drag.link_target_id)
            gantt.refreshTask(drag.link_target_id, false);
        }
        removeDirectionLine();
      }, this));

      function updateMarkedHtml(marker) {
        var link = getDndState();

        var css = ["gantt_link_tooltip"];
        if (link.link_source_id && link.link_target_id) {
          if (gantt.isLinkAllowed(link.link_source_id, link.link_target_id, link.link_from_start, link.link_to_start)) {
            css.push("gantt_allowed_link");
          } else {
            css.push("gantt_invalid_link");
          }
        }

        var className = gantt.templates.drag_link_class(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start);
        if (className)
          css.push(className);

        var html = "<div class='" + className + "'>" +
          gantt.templates.drag_link(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start) +
          "</div>";
        marker.innerHTML = html;
      }

      function advanceMarker(marker, pos) {
        marker.style.left = pos.x + "px";
        marker.style.top = pos.y + "px";
      }

      function resetDndState() {
        _link_source_task =
          _link_source_task_start =
          _link_target_task = null;
        _link_target_task_start = true;
      }
      function showDirectingLine(s_x, s_y, e_x, e_y) {
        var div = getDirectionLine();

        var link = getDndState();

        var css = ["gantt_link_direction"];
        if (gantt.templates.link_direction_class) {
          css.push(gantt.templates.link_direction_class(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start));
        }

        var dist = Math.sqrt((Math.pow(e_x - s_x, 2)) + (Math.pow(e_y - s_y, 2)));
        dist = Math.max(0, dist - 3);
        if (!dist)
          return;

        div.className = css.join(" ");
        var tan = (e_y - s_y) / (e_x - s_x),
          angle = Math.atan(tan);

        if (coordinateCircleQuarter(s_x, e_x, s_y, e_y) == 2) {
          angle += Math.PI;
        } else if (coordinateCircleQuarter(s_x, e_x, s_y, e_y) == 3) {
          angle -= Math.PI;
        }



        var sin = Math.sin(angle),
          cos = Math.cos(angle),
          top = Math.round(s_y),
          left = Math.round(s_x);


        var style = [
          "-webkit-transform: rotate(" + angle + "rad)",
          "-moz-transform: rotate(" + angle + "rad)",
          "-ms-transform: rotate(" + angle + "rad)",
          "-o-transform: rotate(" + angle + "rad)",
          "transform: rotate(" + angle + "rad)",
          "width:" + Math.round(dist) + "px"
        ];

        if (window.navigator.userAgent.indexOf("MSIE 8.0") != -1) {
          //ms-filter breaks styles in ie9, so add it only for 8th
          style.push("-ms-filter: \"" + ieTransform(sin, cos) + "\"");

          var shiftLeft = Math.abs(Math.round(s_x - e_x)),
            shiftTop = Math.abs(Math.round(e_y - s_y));
          //fix rotation axis
          switch (coordinateCircleQuarter(s_x, e_x, s_y, e_y)) {
            case 1:
              top -= shiftTop;
              break;
            case 2:
              left -= shiftLeft;
              top -= shiftTop;
              break;
            case 3:
              left -= shiftLeft;
              break;
            default:
              break;
          }

        }

        style.push("top:" + top + "px");
        style.push("left:" + left + "px");

        div.style.cssText = style.join(";");
      }

      function ieTransform(sin, cos) {
        return "progid:DXImageTransform.Microsoft.Matrix(" +
          "M11 = " + cos + "," +
          "M12 = -" + sin + "," +
          "M21 = " + sin + "," +
          "M22 = " + cos + "," +
          "SizingMethod = 'auto expand'" +
          ")";
      }
      function coordinateCircleQuarter(sX, eX, sY, eY) {
        if (eX >= sX) {
          if (eY <= sY) {
            return 1;
          } else {
            return 4;
          }
        } else {
          if (eY <= sY) {
            return 2;
          } else {
            return 3;
          }
        }

      }
      function getDirectionLine() {
        if (!dnd._direction || !dnd._direction.parentNode) {
          dnd._direction = document.createElement("div");
          timeline.$task_links.appendChild(dnd._direction);
        }
        return dnd._direction;
      }
      function removeDirectionLine() {
        if (dnd._direction) {
          if (dnd._direction.parentNode)	//the event line can be detached because of data refresh
            dnd._direction.parentNode.removeChild(dnd._direction);

          dnd._direction = null;
        }
      }
      gantt.attachEvent("onGanttRender", gantt.bind(function () {
        if (dnd._direction) {
          showDirectingLine(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y);
        }
      }, this));
    };

    return {
      createLinkDND: function () {
        return {
          init: initLinksDND
        };
      }
    };

    /***/
  }

  mainTimelineInitializerJs = function () {

    var utils = this.helperService.utils,
      taskDnD = this.taskDndJs,
      linkDnD = this.linkDndJs,
      domHelpers = this.helperService;

    var initializer = (function () {
      return function (gantt) {
        var services = gantt.$services;
        return {
          onCreated: function (timeline) {
            var config = timeline.$config;
            config.bind = utils.defined(config.bind) ? config.bind : "task";
            config.bindLinks = utils.defined(config.bindLinks) ? config.bindLinks : "link";

            timeline._linksDnD = linkDnD.createLinkDND();
            timeline._tasksDnD = taskDnD.createTaskDND();
            timeline._tasksDnD.extend(timeline);

            this._mouseDelegates = this.mouseDelegatesJs(gantt);
          },
          onInitialized: function (timeline) {
            this._attachDomEvents(gantt);

            this._attachStateProvider(gantt, timeline);

            timeline._tasksDnD.init(timeline, gantt);
            timeline._linksDnD.init(timeline, gantt);

            if (timeline.$config.id == "timeline") {
              this.extendDom(timeline);
            }

          },
          onDestroyed: function (timeline) {
            this._clearDomEvents(gantt);
            this._clearStateProvider(gantt);
            if (timeline._tasksDnD) {
              timeline._tasksDnD.destructor();
            }
          },
          extendDom: function (timeline) {
            gantt.$task = timeline.$task;
            gantt.$task_scale = timeline.$task_scale;
            gantt.$task_data = timeline.$task_data;
            gantt.$task_bg = timeline.$task_bg;
            gantt.$task_links = timeline.$task_links;
            gantt.$task_bars = timeline.$task_bars;
          },

          _clearDomEvents: function () {
            this._mouseDelegates.destructor();
            this._mouseDelegates = null;
          },

          _attachDomEvents: function (gantt) {
            function _delete_link_handler(id, e) {
              if (id && this.callEvent("onLinkDblClick", [id, e])) {

                var link = this.getLink(id);
                if (this.isReadonly(link)) return;

                var title = "";
                var question = this.locale.labels.link + " " + this.templates.link_description(this.getLink(id)) + " " + this.locale.labels.confirm_link_deleting;

                window.setTimeout(function () {
                  gantt._dhtmlx_confirm(question, title, function () {
                    gantt.deleteLink(id);
                  });
                }, (this.config.touch ? 300 : 1));
              }
            }

            this._mouseDelegates.delegate("click", "gantt_task_link", gantt.bind(function (e, trg) {
              var id = this.locate(e, this.config.link_attribute);
              if (id) {
                this.callEvent("onLinkClick", [id, e]);
              }
            }, gantt), this.$task);

            this._mouseDelegates.delegate("click", "gantt_scale_cell", gantt.bind(function (e, trg) {
              var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);
              var date = gantt.dateFromPos(pos.x);
              var coll = Math.floor(gantt.columnIndexByDate(date));

              var coll_date = gantt.getScale().trace_x[coll];

              gantt.callEvent("onScaleClick", [e, coll_date]);
            }, gantt), this.$task);

            this._mouseDelegates.delegate("doubleclick", "gantt_task_link", gantt.bind(function (e, id, trg) {
              var id = this.locate(e, gantt.config.link_attribute);
              _delete_link_handler.call(this, id, e);
            }, gantt), this.$task);

            this._mouseDelegates.delegate("doubleclick", "gantt_link_point", gantt.bind(function (e, id, trg) {
              var id = this.locate(e),
                task = this.getTask(id);

              var link = null;
              if (trg.parentNode && domHelpers.getClassName(trg.parentNode)) {
                if (domHelpers.getClassName(trg.parentNode).indexOf("_left") > -1) {
                  link = task.$target[0];
                } else {
                  link = task.$source[0];
                }
              }
              if (link)
                _delete_link_handler.call(this, link, e);
              return false;
            }, gantt), this.$task);
          },

          _attachStateProvider: function (gantt, timeline) {
            var self = timeline;
            var state = services.getService("state");
            state.registerProvider("tasksTimeline", function () {
              return {
                scale_unit: self._tasks ? self._tasks.unit : undefined,
                scale_step: self._tasks ? self._tasks.step : undefined
              };
            });
          },

          _clearStateProvider: function () {
            var state = services.getService("state");
            state.unregisterProvider("tasksTimeline");
          }
        };
      };

    })();

    return initializer;

    /***/
  }

  mainLayoutInitializerJs = function () {

    var domHelpers = this.helperService;

    var initializer = (function () {
      return function (gantt) {
        return {

          getVerticalScrollbar: function () {
            return gantt.$ui.getView("scrollVer");
          },
          getHorizontalScrollbar: function () {
            return gantt.$ui.getView("scrollHor");
          },

          _legacyGridResizerClass: function (layout) {
            var resizers = layout.getCellsByType("resizer");
            for (var i = 0; i < resizers.length; i++) {
              var r = resizers[i];
              var gridResizer = false;

              var prev = r.$parent.getPrevSibling(r.$id);
              if (prev && prev.$config && prev.$config.id === "grid") {
                gridResizer = true;
              } else {
                var next = r.$parent.getNextSibling(r.$id);
                if (next && next.$config && next.$config.id === "grid") {
                  gridResizer = true;
                }
              }

              if (gridResizer) {
                r.$config.css = (r.$config.css ? r.$config.css + " " : "") + "gantt_grid_resize_wrap";
              }
            }
          },

          onCreated: function (layout) {
            var first = true;

            this._legacyGridResizerClass(layout);

            layout.attachEvent("onBeforeResize", function () {
              var mainTimeline = gantt.$ui.getView("timeline");
              if (mainTimeline)
                mainTimeline.$config.hidden = mainTimeline.$parent.$config.hidden = !gantt.config.show_chart;

              var mainGrid = gantt.$ui.getView("grid");

              if (!mainGrid)
                return;

              var showGrid = gantt.config.show_grid;
              if (first) {
                var colsWidth = mainGrid._getColsTotalWidth();
                if (colsWidth !== false) {
                  gantt.config.grid_width = colsWidth;
                }
                showGrid = showGrid && !!gantt.config.grid_width;
                gantt.config.show_grid = showGrid;
              }
              mainGrid.$config.hidden = mainGrid.$parent.$config.hidden = !showGrid;

              if (!mainGrid.$config.hidden) {
                /* restrict grid width due to min_width, max_width, min_grid_column_width */
                var grid_limits = mainGrid._getGridWidthLimits();
                if (grid_limits[0] && gantt.config.grid_width < grid_limits[0])
                  gantt.config.grid_width = grid_limits[0];
                if (grid_limits[1] && gantt.config.grid_width > grid_limits[1])
                  gantt.config.grid_width = grid_limits[1];
                if (mainTimeline && gantt.config.show_chart) {

                  mainGrid.$config.width = gantt.config.grid_width - 1;
                  if (!first) {
                    if (mainTimeline && !domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                      // timeline is being displayed after being not visible, reset grid with from full screen
                      if (!mainGrid.$config.original_grid_width) {
                        var skinSettings = gantt.skins[gantt.skin];
                        if (skinSettings && skinSettings.config && skinSettings.config.grid_width) {
                          mainGrid.$config.original_grid_width = skinSettings.config.grid_width;
                        } else {
                          mainGrid.$config.original_grid_width = 0;
                        }
                      }
                      gantt.config.grid_width = mainGrid.$config.original_grid_width;
                      mainGrid.$parent.$config.width = gantt.config.grid_width;
                    } else {
                      mainGrid.$parent._setContentSize(mainGrid.$config.width, mainGrid.$config.height);
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, gantt.config.grid_width);
                    }
                  } else {
                    mainGrid.$parent.$config.width = gantt.config.grid_width;
                    if (mainGrid.$parent.$config.group) {
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, mainGrid.$parent.$config.width);
                    }
                  }
                } else {
                  if (mainTimeline && domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                    // hiding timeline, remember grid with to restore it when timeline is displayed again
                    mainGrid.$config.original_grid_width = gantt.config.grid_width;
                  }
                  if (!first) {
                    mainGrid.$parent.$config.width = 0;
                  }
                }
              }

              first = false;
            });
            this._initScrollStateEvents(layout);
          },

          _initScrollStateEvents: function (layout) {
            gantt._getVerticalScrollbar = this.getVerticalScrollbar;
            gantt._getHorizontalScrollbar = this.getHorizontalScrollbar;

            var vertical = this.getVerticalScrollbar();
            var horizontal = this.getHorizontalScrollbar();
            if (vertical) {
              vertical.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [scrollState.x, oldPos, scrollState.x, newPos]);
              });
            }
            if (horizontal) {
              horizontal.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [oldPos, scrollState.y, newPos, scrollState.y]);
              });
            }

            layout.attachEvent("onResize", function () {
              if (vertical && !gantt.$scroll_ver) {
                gantt.$scroll_ver = vertical.$scroll_ver;
              }

              if (horizontal && !gantt.$scroll_hor) {
                gantt.$scroll_hor = horizontal.$scroll_hor;
              }
            });
          },

          _findGridResizer: function (layout, grid) {
            var resizers = layout.getCellsByType("resizer");

            var gridFirst = true;
            var gridResizer;
            for (var i = 0; i < resizers.length; i++) {
              var res = resizers[i];
              res._getSiblings();
              var prev = res._behind;
              var next = res._front;
              if (prev && prev.$content === grid || (prev.isChild && prev.isChild(grid))) {
                gridResizer = res;
                gridFirst = true;
                break;
              } else if (next && next.$content === grid || (next.isChild && next.isChild(grid))) {
                gridResizer = res;
                gridFirst = false;
                break;
              }
            }
            return {
              resizer: gridResizer,
              gridFirst: gridFirst
            };
          },

          onInitialized: function (layout) {
            var grid = gantt.$ui.getView("grid");

            var resizeInfo = this._findGridResizer(layout, grid);

            // expose grid resize events
            if (resizeInfo.resizer) {
              var gridFirst = resizeInfo.gridFirst,
                next = resizeInfo.resizer;
              var initialWidth;
              next.attachEvent("onResizeStart", function (prevCellWidth, nextCellWidth) {

                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  var limits = grid._getGridWidthLimits();

                  // min grid width is defined by min widths of its columns, unless grid has horizontal scroll
                  if (!grid.$config.scrollable)
                    viewCell.$config.minWidth = limits[0];

                  viewCell.$config.maxWidth = limits[1];
                }
                initialWidth = gridFirst ? prevCellWidth : nextCellWidth;
                return gantt.callEvent("onGridResizeStart", [initialWidth]);
              });
              next.attachEvent("onResize", function (newBehindSize, newFrontSize) {
                var newSize = gridFirst ? newBehindSize : newFrontSize;
                return gantt.callEvent("onGridResize", [initialWidth, newSize]);
              });
              next.attachEvent("onResizeEnd", function (oldBackSize, oldFrontSize, newBackSize, newFrontSize) {

                var oldSize = gridFirst ? oldBackSize : oldFrontSize;
                var newSize = gridFirst ? newBackSize : newFrontSize;
                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  viewCell.$config.minWidth = undefined;
                }
                var res = gantt.callEvent("onGridResizeEnd", [oldSize, newSize]);
                if (res) {
                  gantt.config.grid_width = newSize;
                }

                return res;
              });
            }

          },
          onDestroyed: function (timeline) {

          }
        };

      };
    })();

    return initializer;

  }

}

