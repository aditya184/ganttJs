  calculateTaskLevel(item) {
    return this.$data.tasksStore.calculateItemLevel(item);
  }
  getNext(id) {
    return this.$data.tasksStore.getNext(id);
  }
  getPrev(id) {
    return this.$data.tasksStore.getPrev(id);
  }
  getParent(id) {
    return this.$data.tasksStore.getParent(id);
  }
  setParent(task, new_pid, silent) {
    return this.$data.tasksStore.setParent(task, new_pid, silent);
  }
  getSiblings(id) {
    return this.$data.tasksStore.getSiblings(id).slice();
  }
  getNextSibling(id) {
    return this.$data.tasksStore.getNextSibling(id);
  }
  getPrevSibling(id) {
    return this.$data.tasksStore.getPrevSibling(id);
  }
  getTaskByIndex(index) {
    var id = this.$data.tasksStore.getIdByIndex(index);
    if (this.isTaskExists(id)) {
      return this.getTask(id);
    } else {
      return null;
    }
  }
  getChildren(id) {
    if (!this.hasChild(id)) {
      return [];
    } else {
      return this.$data.tasksStore.getChildren(id).slice();
    }
  }
  hasChild(id) {
    return this.$data.tasksStore.hasChild(id);
  }
  open(id) {
    this.$data.tasksStore.open(id);
  }
  close(id) {
    this.$data.tasksStore.close(id);
  }
  moveTask(sid, tindex, parent) {
    return this.$data.tasksStore.move.apply(this.$data.tasksStore, arguments);
  }
  sort(field, desc, parent, silent) {
    var render = !silent;//4th argument to cancel redraw after sorting

    this.$data.tasksStore.sort(field, desc, parent);
    this.eventableService.callEvent("onAfterSort", [field, desc, parent]);

    if (render) {
      this.render();
    }
  }

  getLinkCount() {
    return this.$data.linksStore.count();
  }

  getLink(id) {
    return this.$data.linksStore.getItem(id);
  }

  getLinks() {
    return this.$data.linksStore.getItems();
  }

  isLinkExists(id) {
    return this.$data.linksStore.exists(id);
  }

  addLink(link) {
    return this.$data.linksStore.addItem(link);
  }

  updateLink(id, data) {
    if (!this.helperService.defined(data))
      data = this.getLink(id);
    this.$data.linksStore.updateItem(id, data);
  }

  deleteLink(id) {
    return this.$data.linksStore.removeItem(id);
  }

  changeLinkId(oldid, newid) {
    return this.$data.linksStore.changeId(oldid, newid);
  }

  $create(array?) {
    return this.helperService.mixin(array || [], this);
  }
  //remove element at specified position
  $removeAt(pos, len) {
    if (pos >= 0) this.splice(pos, (len || 1));
  }
  //find element in collection and remove it
  $remove(value) {
    this.$removeAt(this.$find(value));
  }
  //add element to collection at specific position
  $insertAt(data, pos) {
    if (!pos && pos !== 0) 	//add to the end by default
      this.push(data);
    else {
      var b = this.splice(pos, (this.length - pos));
      this[pos] = data;
      this.push.apply(this, b); //reconstruct array without loosing this pointer
    }
  }
  //return index of element, -1 if it doesn't exists
  $find(data) {
    for (var i = 0; i < this.length; i++)
      if (data == this[i]) return i;
    return -1;
  }
  //execute some method for each element of array
  $each(functor, master) {
    for (var i = 0; i < this.length; i++)
      functor.call((master || this), this[i]);
  }
  //create new array from source, by using results of functor
  $map(functor, master) {
    for (var i = 0; i < this.length; i++)
      this[i] = functor.call((master || this), this[i]);
    return this;
  }
  $filter(functor, master) {
    for (var i = 0; i < this.length; i++)
      if (!functor.call((master || this), this[i])) {
        this.splice(i, 1);
        i--;
      }
    return this;
  }