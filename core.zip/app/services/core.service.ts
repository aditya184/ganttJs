import { Injectable } from '@angular/core';
import { HelpersService } from './helpers.service';
import { EventableService } from './eventable.service';
import { UiService } from './ui.service';
import { ConstantService } from './constant.service';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class CoreService {

  constructor(private helperService: HelpersService, private eventableService: EventableService, private uiService: UiService,
    private constantService: ConstantService, private commonService: CommonService) { }



  dataTaskLayers(gantt) {

    delete gantt.addTaskLayer;
    delete gantt.addLinkLayer;

  };

  getTimeline(gantt) {
    return gantt.$ui.getView("timeline");
  }

  getGrid(gantt) {
    return gantt.$ui.getView("grid");
  }

  getVerticalScrollbar(gantt) {
    return gantt.$ui.getView("scrollVer");
  }

  getHorizontalScrollbar(gantt) {
    return gantt.$ui.getView("scrollHor");
  }

  DEFAULT_VALUE = "DEFAULT_VALUE";

  tryCall(getView, method, args, fallback) {
    var view = getView(this);
    if (!(view && view.isVisible())) {
      if (fallback) {
        return fallback();
      } else {
        return this.DEFAULT_VALUE;
      }
    } else {
      return view[method].apply(view, args);
    }
  }

  getColumnIndex(name) {
    var res = this.tryCall.call(this, this.getGrid, "getColumnIndex", [name]);
    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }

  dateFromPos(x) {
    var res = this.tryCall.call(this, this.getTimeline, "dateFromPos", Array.prototype.slice.call(arguments));
    if (res === this.DEFAULT_VALUE) {
      return this.commonService.getState().min_date;
    } else {
      return res;
    }
  }

  posFromDate(date) {
    var res = this.tryCall.call(this, this.getTimeline, "posFromDate", [date]);
    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }

  getRowTop(index) {
    var self = this;
    var res = this.tryCall.call(self, this.getTimeline, "getRowTop", [index],
      function () { return this.tryCall.call(self, this.getGrid, "getRowTop", [index]); }
    );

    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }

  getTaskTop(id) {
    var self = this;
    var res = this.tryCall.call(self, this.getTimeline, "getItemTop", [id],
      function () { return this.tryCall.call(self, this.getGrid, "getItemTop", [id]); }
    );

    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }


  getTaskPosition(task, start_date, end_date) {
    var res = this.tryCall.call(this, this.getTimeline, "getItemPosition", [task, start_date, end_date]);

    if (res === this.DEFAULT_VALUE) {
      var top = this.getTaskTop(task.id);
      var height = this.getTaskHeight();

      return {
        left: 0,
        top: top,
        height: height,
        width: 0
      };
    } else {
      return res;
    }
  }

  getTaskHeight() {
    var self = this;
    var res = this.tryCall.call(self, this.getTimeline, "getItemHeight", [],
      function () { return this.tryCall.call(self, this.getGrid, "getItemHeight", []); }
    );

    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }


  columnIndexByDate(date) {
    var res = this.tryCall.call(this, this.getTimeline, "columnIndexByDate", [date]);
    if (res === this.DEFAULT_VALUE) {
      return 0;
    } else {
      return res;
    }
  }

  roundTaskDates() {
    this.tryCall.call(this, this.getTimeline, "roundTaskDates", []);
  }

  getScale() {
    var res = this.tryCall.call(this, this.getTimeline, "getScale", []);
    if (res === this.DEFAULT_VALUE) {
      return null;
    } else {
      return res;
    }
  }

  getTaskNode(id) {
    var timeline = this.getTimeline(this);
    if (!timeline || !timeline.isVisible()) {
      return null;
    } else {
      return timeline._taskRenderer.rendered[id];
    }
  }


  getLinkNode(id) {
    var timeline = this.getTimeline(this);
    if (!timeline.isVisible()) {
      return null;
    } else {
      return timeline._linkRenderer.rendered[id];
    }
  }

  scrollTo(left, top) {
    var vertical = this.getVerticalScrollbar(this);
    var horizontal = this.getHorizontalScrollbar(this);

    var oldH = { position: 0 },
      oldV = { position: 0 };

    if (vertical) {
      oldV = vertical.getScrollState();
    }
    if (horizontal) {
      oldH = horizontal.getScrollState();
    }

    if (horizontal && left * 1 == left) {
      horizontal.scroll(left);
    }
    if (vertical && top * 1 == top) {
      vertical.scroll(top);
    }

    var newV = { position: 0 },
      newH = { position: 0 };
    if (vertical) {
      newV = vertical.getScrollState();
    }
    if (horizontal) {
      newH = horizontal.getScrollState();
    }

    this.eventableService.callEvent("onGanttScroll", [oldH.position, oldV.position, newH.position, newV.position]);
  }

  showDate(date) {
    var date_x = this.posFromDate(date);
    var scroll_to = Math.max(date_x - this.commonService.result.task_scroll_offset, 0);
    this.scrollTo(scroll_to, undefined);
  }

  showTask(id) {
    var pos = this.getTaskPosition(this.getTask(id), undefined, undefined);

    var left = Math.max(pos.left - this.commonService.result.task_scroll_offset, 0);

    var dataHeight: any = this._scroll_state().y;
    var top;
    if (!dataHeight) {
      top = pos.top;
    } else {
      top = pos.top - (dataHeight - this.commonService.result.row_height) / 2;
    }

    this.scrollTo(left, top);
  }


  getScrollState() {
    var state = this._scroll_state();
    return { x: state.x_pos, y: state.y_pos, inner_width: state.x, inner_height: state.y, width: state.x_inner, height: state.y_inner };
  }

  _scroll_state() {
    var result = {
      x: false,
      y: false,
      x_pos: 0,
      y_pos: 0,
      scroll_size: this.commonService.result.scroll_size + 1,//1px for inner content
      x_inner: 0,
      y_inner: 0
    };

    var scrollVer = this.getVerticalScrollbar(this),
      scrollHor = this.getHorizontalScrollbar(this);
    if (scrollHor) {
      var horState = scrollHor.getScrollState();
      if (horState.visible) {
        result.x = horState.size;
        result.x_inner = horState.scrollSize;
      }
      result.x_pos = horState.position || 0;
    }

    if (scrollVer) {
      var verState = scrollVer.getScrollState();
      if (verState.visible) {
        result.y = verState.size;

        result.y_inner = verState.scrollSize;
      }
      result.y_pos = verState.position || 0;
    }

    return result;
  }


  assert(check, message) {
    if (!check) {
      if (gantt.config.show_errors && gantt.callEvent("onError", [message]) !== false) {
        gantt.message({ type: "error", text: message, expire: -1 });
      }
    }
  }

  getTask(id) {
    this.assert(id, "Invalid argument for gantt.getTask");
    var task = this.getItem(id);
    this.assert(task, "Task not found id=" + id);
    return task;
  }

  pull = {};
  _skip_refresh = false;


  getItem(id) {
    return this.pull[id];
  }

  getItems() {
    var res = [];
    for (var i in this.pull) {
      res.push(this.pull[i]);
    }
    /*	for(var i = 0; i < this.fullOrder.length; i++){
  
      }*/
    return res;
  }

  getTaskByTime(from, to) {
    var p = this.getItems();

    var res = [];

    if (!(from || to)) {
      res = p;
    } else {
      from = +from || -Infinity;
      to = +to || Infinity;
      for (var t = 0; t < p.length; t++) {
        var task = p[t];
        if (+task.start_date < to && +task.end_date > from)
          res.push(task);
      }
    }
    return res;
  }

  exists(id) {
    return !!(this.pull[id]);
  }

  updateItem(id, item){
    if (!this.helperService.defined(item)) item = this.getItem(id);

    if (!this._skip_refresh) {
      if (this.eventableService.callEvent("onBeforeUpdate", [item.id, item]) === false) return false;
    }
    this.pull[id] = item;
    if (!this._skip_refresh) {
      this.eventableService.callEvent("onAfterUpdate", [item.id, item]);
      this.eventableService.callEvent("onStoreUpdated", [item.id, item, "update"]);
    }
  }

  refreshTask(taskId, refresh_links) {
    var task = this.getTask(taskId);
    if (task && this.isTaskVisible(taskId)) {

      this.refresh(taskId, !!this.commonService.getState().drag_id);// do quick refresh during drag and drop

      if (refresh_links !== undefined && !refresh_links)
        return;
      for (var i = 0; i < task.$source.length; i++) {
        this.refreshLink(task.$source[i]);
      }
      for (var i = 0; i < task.$target.length; i++) {
        this.refreshLink(task.$target[i]);
      }
    } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
      this.refreshTask(this.getParent(taskId), refresh_links);
    }
  }

  getParent(id) {
    var item = null;
    if (id.id !== undefined) {
      item = id;
    } else {
      item = this.getItem(id);
    }

    var parent;
    if (item) {
      parent = item[this.$parentProperty];
    } else {
      parent = this.getRootId();
    }
    return parent;

  }

  getRootId(val?) {
    return function () { return val; };
  }

  refreshLink(linkId) {
    this.refresh(linkId, !!this.commonService.getState().drag_id);// do quick refresh during drag and drop
  }

  filter(rule) {
    this.eventableService.callEvent("onBeforeFilter", []);
    var filteredOrder = powerArray.$create();
    this.eachItem(function (item) {
      if (this.callEvent("onFilterItem", [item.id, item])) {
        filteredOrder.push(item.id);
      }
    });

    this.visibleOrder = filteredOrder;
    this._searchVisibleOrder = {};
    for (var i = 0; i < this.visibleOrder.length; i++) {
      this._searchVisibleOrder[this.visibleOrder[i]] = i;
    }
    this.eventableService.callEvent("onFilter", []);
  }

  refresh(id, quick) {
    if (this._skip_refresh) return;

    var args;
    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    if (this.eventableService.callEvent("onBeforeStoreUpdate", args) === false) {
      return;
    }

    if (id) {
      // if item changes visible order (e.g. expand-collapse branch) - do a complete repaint
      if (!quick) {
        var oldOrder = this.visibleOrder;
        this.filter();
        if (!this.arraysEqual(oldOrder, this.visibleOrder)) {
          id = undefined;
        }
      }

    } else {
      this.filter();
    }

    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    this.eventableService.callEvent("onStoreUpdated", args);
  }

  isTaskVisible(id) {
    if (!this.isTaskExists(id))
      return false;

    var task = this.getTask(id);

    var taskStart = task.start_date ? task.start_date.valueOf() : null;
    var taskEnd = task.end_date ? task.end_date.valueOf() : null;

    if (!(gantt._isAllowedUnscheduledTask(task) || (taskStart && taskEnd && taskStart <= this._max_date.valueOf() && taskEnd >= this._min_date.valueOf()))) {
      return false;
    }

    return !!(gantt.getGlobalTaskIndex(id) >= 0);
  };

  isTaskExists(id) {
    // if (!this.$data || !this.$data.tasksStore) {
    //   return false;
    // }
    return this.exists(id);
  }

  updateTask(id, item) {
    if (!this.helperService.defined(item)) item = this.getTask(id);
    this.updateItem(id, item);
    if (this.isTaskExists(id))
      this.refreshTask(id);
  }
  addTask(item, parent, index) {
    if (!this.helperService.defined(item.id))
      item.id = this.helperService.uid();

    if (!this.helperService.defined(parent)) parent = this.getParent(item) || 0;
    if (!this.isTaskExists(parent)) parent = this.commonService.result.root_id;
    this.setParent(item, parent);

    return this.$data.tasksStore.addItem(item, index, parent);
  }
  deleteTask(id) {
    return this.$data.tasksStore.removeItem(id);
  }
  getTaskCount() {
    return this.$data.tasksStore.count();
  }
  getVisibleTaskCount() {
    return this.$data.tasksStore.countVisible();
  }
  getTaskIndex(id) {
    return this.$data.tasksStore.getBranchIndex(id);
  }
  getGlobalTaskIndex(id) {
    this.assert(id, "Invalid argument");
    return this.$data.tasksStore.getIndexById(id);
  }
  eachTask(code, parent, master) {
    return this.$data.tasksStore.eachItem(this.helperService.bind(code, master || this), parent);
  }
  eachParent(callback, startTask, master) {
    return this.$data.tasksStore.eachParent(this.helperService.bind(callback, master || this), startTask);
  }
  changeTaskId(oldid, newid) {
    this.$data.tasksStore.changeId(oldid, newid);
    var task = this.$data.tasksStore.getItem(newid);

    var links = [];

    if (task.$source) {
      links = links.concat(task.$source);
    }
    if (task.$target) {
      links = links.concat(task.$target);
    }

    for (var i = 0; i < links.length; i++) {
      var link = this.getLink(links[i]);
      if (link.source == oldid) {
        link.source = newid;
      }
      if (link.target == oldid) {
        link.target = newid;
      }
    }
  }

}