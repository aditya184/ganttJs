import { TestBed } from '@angular/core/testing';

import { EventableService } from './eventable.service';

describe('EventableService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EventableService = TestBed.get(EventableService);
    expect(service).toBeTruthy();
  });
});
